# Implementation report

Status: complete within assigned edit scope. No active operations or children. Parent owns behavioral assessment, measurement, records, and acceptance.

Changed canonical paths:

- `plugins/lusona/README.md`: compact shared core; conditional reference lookup; role-specific questions/catalog loading; deduplicated leaf instructions; mandatory correction trigger.
- `plugins/lusona/references/delegation.md`: compact leaf/result/dispatch/reconciliation instructions without changing ownership or completion rules.
- `plugins/lusona/references/corrections.md`: existing correction policy extracted verbatim, with explicit read trigger and TDD-red exclusion.
- `plugins/lusona/references/commits.md`: replace obsolete pointer to the contract's format with pointer to existing format below; no Git policy changes.

Required core section lists (Loading rules itself included):

- Leaf: Loading rules; Work loop; Contract; TDD; Review and communication; Assigned leaves; Context budget.
- Coordinator: leaf list plus Questions and next actions; Personas and subagents.
- References: conditional lookup catalog when an applicable procedure is not already linked from the current skill/assignment. Applicable procedures remain mandatory in full subject to existing role/section guidance. Do not count this as never-loaded text: catalog-driven work includes it.
- Leaves additionally read delegation Assigned leaves and Assignment results. Coordinators performing assignments read all delegation, model routing before dispatch, and lifecycle after results/before closeout/handoff.
- Observed-failure correction/diagnostic paths additionally load the complete corrections reference. Commit/integration paths additionally load the complete commits reference. Batch execution retains its own repair budget. Report these all-needed conditional totals separately.

# Before-to-after invariant map

The rows cover removed/replaced prose in the two rewritten files; every requirement remains at a mandatory location or behind an explicit operational trigger. This is content characterization and loading analysis, not a behavioral test.

| Before requirement(s) | After location and mandatory loading/trigger |
| --- | --- |
| All roles read current core; identify supplied/inherited source, fill gaps, reuse unchanged instructions, installation/other worker is insufficient | Loading rules, required for all; complete applicable procedures remain mandatory; role/operation/source changes load missing/changed text |
| Reference procedure selection; complete procedures, role sections, excerptable optional examples/catalogs, relative bundled paths | Loading rules for all; References catalog on unresolved lookup; Contract for resource/data paths; assignment contract provides leaf loading inputs |
| Meaning of change/task; selected task does not authorize whole change | Loading rules for all |
| Carry accepted intent/authority/TDD/evidence/uncertainty through turns/skills/sessions/handoffs; skills confer neither authority nor required phases | Work loop for all; complete-outcome rule under Review |
| Next bounded useful action, compare intended outcome, evidence versus assumptions, stop unproductive inquiry, expertise affects depth only, answer direct questions/reuse answers | Work loop for all |
| Continue without new command; recommendations/answers do not complete execution; follow-ups steer unless cancelled/replaced/incompatible; preserve progress/scope | Work loop for all |
| User pause; unavailable input/capability/authority; independent work continues; reason/resumption prerequisite; batch deferral through parent | Work loop for all |
| Reopen accepted decisions on contrary evidence; identify conflict/assumptions; reconcile assignments/owning records/handoffs within write authority; useful rationale/history; report other owners' corrections; stale records cannot restore old choice | Work loop for all |
| Concrete goal-related gaps versus blockers/separate proposed outcomes; uncertainty/smallest action; no implied broader completion, invented requirements, or automatic whole-product audit | Work loop for all; retention on saving, read-only reporting preserved |
| Findings/proposals/additions/splits/deferrals/priorities do not authorize scope/batch/priority changes | Work loop for all; additions subsumed under proposals |
| Optional measure/experiment explicit or standing authority with finite scope/resource budget; uncertainty/alternatives alone insufficient; no repeated offers; routine execution within authority needs no repeated approval, ask only missing consequential decisions/commitments, otherwise state uncertainty/continue | Work loop for all |
| Task-local empirical checks need no study/delegate/stage/record; diagnostics remain investigation; ordinary versus retained material evidence/provenance; comparable improvement claims; checks/TDD/acceptance/resource boundaries remain binding | Work loop for all; evidence reference when retaining material evidence |
| Correction definition, initial-attempt exclusion, expected TDD-red exclusion, two cross-worker/handoff counters, retained counts/evidence, material-progress definition, 2-consecutive stop, 4-total stop/user question, evidence-supported changed-approach exception/hypothesis/stopping condition/expected evidence, only progress resets consecutive, total never resets, batch budget | Complete original two paragraphs copied verbatim to corrections reference; Work loop mandates loading before correcting/diagnostically probing an observed check/review failure; expected task-local TDD red excluded; delegation correction field links it and Context retains counts |
| Routine adaptation preserves progress/acceptance; planning belongs to implementation; tasks only when justified; clear small requests stay conversational | Work loop for all |
| Domain skills before substantive work; identify use/report missing; reuse current text | Contract for all |
| User scope/consequential control; ask before unauthorized accepted outcomes/contracts/TDD/dependencies/operational commitments or destructive changes; host prompts/unrelated work; routine methods/order freedom; sequence only when justified | Contract for all |
| Specs/plans/ADRs/queue/discussion/read-only review grant no implementation authority; Ready insufficient; planning-only stops; role transitions do not renew approval | Contract for all |
| Implementation/refactoring local verified commit default unless user/repository override; other work needs commit authority; push/publish/PR/ticket/amend/history rewriting separate | Contract for all |
| Coordinator staging, verified content, Conventional Commits/rationale, linear/no-unrequested-merge history, permitted unpublished agent rebase, no target-history rewrite | Removed duplicate summary from core; Contract mandates complete existing commits procedure before commits/integration, where all mechanics already exist. Updated its format pointer only |
| Consuming-project paths, loaded-resource-relative bundled links, no project data in installed plugin; coordinator alone writes queue/saved handoffs | Contract for all; delegation role instructions remain mandatory |
| Relevant linked-template content, no forced file/save/format; minimal permitted recovery records; no-save/read-only/destination precedence; smallest existing owner, no migration/duplication; recovery creates no spec/ADR/queue/plan/TDD/Specify/implementation authority; requested standalone deliverable separate | Contract for all; retention before saving |
| Native questions permitted purpose/mode with plain-text fallback; no mode-switch; consequential questions/recommendations; optional assumption/timing; silence/preselection not consent; approvals | Questions and next actions for coordinators; leaves never interview users and route questions to coordinator under mandatory Assigned leaves |
| Handoff/boundary result/blocker, evidence/limits, next action/owner/inputs/remaining authority, actual question, continuation directive only when needed, no invented follow-up | Shared Review and communication; coordinator Questions contains actual-question requirement; leaf mandatory result/recovery fields and parent escalation retain relevant questions |
| Explicit none/targeted/strict by user/standing choice; unset allows definition/planning only; TDD reference | TDD for all, unchanged applicable reference |
| Whole authorized outcome/criteria/checks/human acceptance/delivery including conversation; failed/unrun checks block completion; tests not human acceptance | Review and communication for all |
| Self-inspection/checks; independent review thresholds, actual diff/agreement/evidence, persona not independence; unavailable review unmet; repair within authority/verify | Review and communication for all |
| Blocking decision first otherwise result, demonstrated behavior/reasons/evidence/limits/issues; answer status then resume; user-visible try steps/expected results; enduring docs distinguish proposals/current | Review and communication for all |
| Provisional Result/Evidence/Next action default; blocking decision first, None when complete, natural ordinary dialogue; statuses describe response/outcome not queue/subject, glyph-independent words | Review and communication for all |
| Parallel lists/useful tables, status Outcome/State/Remaining work incl blockers/dependencies and recorded queue state; stable comparison columns; preserve schemas/specialized tables/relevant fields; host/requested format override retains content/status words; no cross-host claim | Review and communication for all; Contract template relevant-section rule |
| Leaves assigned scope, result before wait/end; no children without explicit grant, no user interviews or self-assigned skill/phase, no more work without assignment; scoped domain supplementation | Mandatory delegation Assigned leaves; core points to it instead of repeating |
| Parent questions/follow-up/reconciliation and exclusive shared records; shutdown preserves result/stops operations/reports unsafe shutdown | Mandatory delegation Assigned leaves; coordinator outcome selection/reconciliation in Evaluate and reconcile results |
| Final result fields/status/outcome/paths/checks/remaining/recovery/correction counts; blocked attempts/prerequisite; statuses not queue/acceptance/exit/lifecycle; complete review may find defects; unmet implementation check not complete | Mandatory delegation Assignment results, compact table/fields without changed meanings |
| Coordinator responsibility and required substantive delegation (not inspection), local explore/status/orientation, task-local measurement/experiment check exception, sequential sufficient | Personas and subagents, coordinator required |
| Prohibited/unavailable delegation local fallback with explanation, never independent review; occupied capacity wait/reuse/release; capacity/single batch pool; routing/lifecycle triggers | Personas and subagents, coordinator required |
| Assignment persona/outcome/checks/ownership/authority/TDD/source/workflow/domain/core/result contract; actual paths/text/explicit loading; no installation/inheritance/anchor-only assumptions; bounded context and failure/recovery evidence; unprimed review | Mandatory delegation Assignment contract for dispatch; core Loading rules remains source for loading reuse |
| Coordinator verification/acceptance distinct from completion/capacity; complete/blocked/incomplete responses; serialize dependencies/mutable checks; reuse unchanged evidence, rerun changed/failure/unreliable/risk, independently required review/checks | Mandatory delegation Evaluate and reconcile results |
| Malformed/missing report/idle/crash not success; request/reconcile until known; evidence-gated legacy mappings without rewriting history | Mandatory delegation Evaluate and reconcile results |
| Missing context/environment/allowed stronger reasoning/split large separable assignment; user only for coordinator-unresolvable decisions/authority; no unchanged blocked retry | Mandatory delegation Evaluate and reconcile results |
| Stop old writer, explicit ownership transfer, no overlapping writers; preserve edits/evidence and pass state/outcome/authority/TDD | Mandatory delegation Evaluate and reconcile results, single statement instead of repetition |
| Context telemetry ~40% prepare/<50% target, no invented usage/transfer; otherwise task-boundary checkpoints; full surviving handoff fields/counts/ownership; replace prior; no-save permitted-channel fallback/recovery limit; recover tree/records first; no fictitious checkpoint; safely finish/pause operations; authorization persists | Context budget for all |

# Verification and limits

- Existing baseline characterization/evaluator artifacts were not read or modified; parent performs the matched decision assessment. Targeted TDD is carried from this simplification work; this cleanup characterizes existing behavior and does not invent red.
- `mise exec python@3.12.13 -- python3 scripts/package.py --output tmp/instruction-footprint-20261027/implementation/package-final`: passed. Validates existing skill-template links, native manifest identity/version, catalog paths, resource paths, explicit package selection, package generation. Installed mise Python used without changing tool config.
- Both `claude plugin validate plugins/lusona --json` and marketplace validation: passed, no errors/warnings. Plugin validator gives informational advice about an install line in canonical workflow README; installation guidance is outside this core-shortening scope.
- `git diff --check`: passed across working tree.
- `check-anchors.py`: all original README/delegation anchors preserved; 31 inbound links valid; correction paragraphs moved verbatim. This verifies structural preservation only, not agent decisions.
- Exact tool results are in `validation.json` and `final-validation.json`; generated package and snapshots remain under this owned scratch directory. No installation, interactive host behavior, new model trials, commit, push, or publication performed.
- All four changed canonical paths are stable for parent measurement/review. Parent review identified and corrected two fidelity risks before final freeze: an explicit-grant qualifier is limited to child spawning, and the delegation exception remains limited to task-local measurement/experiment checks with empirical checks named. Routine execution without repeated approval is explicit. No additional caller amendments needed because their existing Loading rules links remain authoritative and all anchors survive.
- Main residual risk is instruction interpretation after concise wording/role loading; parent behavioral assessment and independent diff review remain necessary evidence. Host eager full-file loading can reduce realized context savings; counts describe required source text, not actual runtime tokens/latency/cost.

Next action: parent independently measures the stated role/conditional paths, reviews invariant coverage and actual changed diff, then runs the held-out candidate decision assessment before acceptance.
