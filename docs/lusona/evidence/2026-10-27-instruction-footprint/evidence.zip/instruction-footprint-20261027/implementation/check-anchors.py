from pathlib import Path
import re

root = Path('plugins/lusona')
scratch = Path('tmp/instruction-footprint-20261027/implementation')

def anchors(text):
    return {re.sub(r'[^\w\- ]', '', heading.lower()).replace(' ', '-')
            for heading in re.findall(r'^#+ (.+)$', text, re.M)}

changed = (root / 'README.md', root / 'references/delegation.md')
for current, before in zip(changed, ('README.before.md', 'delegation.before.md')):
    missing = anchors((scratch / before).read_text()) - anchors(current.read_text())
    assert not missing, (current, missing)

count = 0
for source in root.rglob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', source.read_text()):
        if '://' in target or '#' not in target:
            continue
        path, anchor = target.split('#', 1)
        destination = (source.parent / path).resolve() if path else source.resolve()
        if destination in {path.resolve() for path in changed}:
            assert anchor in anchors(destination.read_text()), (source, target)
            count += 1

before = (scratch / 'README.before.md').read_text()
correction = before[before.index('Outside a batch, a correction round'):before.index('\nRevise routine approaches')]
assert correction in (root / 'references/corrections.md').read_text()
print(f'All old README/delegation anchors preserved; {count} inbound anchor links valid.')
print('Correction policy moved verbatim; trigger and TDD exclusion reviewed separately in invariant map.')
