from pathlib import Path
import re,json,sys
root=Path(sys.argv[1]);sections={}
for block in re.split(r'(?m)^## ',(root/'README.md').read_text())[1:]:
 title,body=block.split('\n',1);sections[title]='## '+block
words=lambda s:len(s.split())
base=['Loading rules','Work loop','Contract','References','Questions and next actions','TDD','Review and communication','Assigned leaves','Context budget']
# Section lists supplied explicitly for each frozen source; do not infer claimed loading policy.
policy=json.loads(Path(sys.argv[2]).read_text()) if len(sys.argv)>2 else {}
base=policy.get('leaf_core',base)
coordinator=policy.get('coordinator_core',list(sections))
files={str(f.relative_to(root)):words(f.read_text()) for f in sorted(root.rglob('*.md'))}
d=(root/'references/delegation.md').read_text();ds={}
for block in re.split(r'(?m)^## ',d)[1:]:
 title,body=block.split('\n',1);ds[title]='## '+block
leaf_core=sum(words(sections[k]) for k in base)
coord_core=sum(words(sections[k]) for k in coordinator)
leaf_delegation=sum(words(ds[k]) for k in ['Assigned leaves','Assignment results'])
common=files['skills/implement/SKILL.md']+files['references/tdd.md']
leaf=leaf_core+common+leaf_delegation
coord=coord_core+common+sum(files['references/'+n+'.md'] for n in ['delegation','model-routing','worker-lifecycle'])
corrections=files.get('references/corrections.md',0)
out={'method':'Whitespace words; required source text, not actual runtime tokens, latency or total call cost. Roles reuse already loaded content once.','core_file_words':files['README.md'],'plugin_markdown_words':sum(files.values()),'role_core_sections':{'leaf':base,'coordinator':coordinator},'role_core_words':{'leaf':leaf_core,'coordinator':coord_core},'ordinary_implement_words':{'leaf':leaf,'coordinator':coord},'with_correction_procedure_words':{'leaf':leaf+corrections,'coordinator':coord+corrections},'coordinator_with_commit_procedure_words':coord+files['references/commits.md'],'leaf_delegation_words':leaf_delegation,'files':files}
print(json.dumps(out,indent=2))
