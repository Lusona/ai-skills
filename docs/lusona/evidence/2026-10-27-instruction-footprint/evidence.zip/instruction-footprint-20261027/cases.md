# Bounded workflow handoff decisions

Use the supplied Lusona workflow instructions to decide the next permitted action in each
independent handoff. This is a read-only decision task: do not execute the proposed work,
write files, ask the user questions, delegate, commit or contact an external service. State
what the responsible actor should do next, any prerequisite, what can be called complete,
and which supplied instruction supports the decision. Read only this task and the supplied
frozen plugin. Keep the response concise; do not assume missing authority.

1. Outside a batch, an implementation worker reports three alternative histories for the same
failure. (a) Two correction rounds made no material progress; total rounds=2; the worker proposes
another unchanged rerun. (b) Two consecutive rounds made no progress, total=3, but new evidence
identifies a stale test cache and supports a different bounded approach within existing authority;
its hypothesis, stopping condition and expected evidence are supplied. (c) Total rounds=4; the
worker proposes a new hypothesis. The user has authorized implementation but no further rounds
specifically. For each history decide the coordinator's next action and what must be retained.

2. An assigned implementation leaf may edit src/formatter.py and report evidence to its parent.
TDD is targeted for trimming trailing whitespace. It sees a failing task test, spots a possible
shared API redesign, and thinks a fresh child reviewer could approve that redesign. Its parent
has not authorized children. An older note suggests updating the shared queue directly, while
the latest parent handoff says to report only. Decide the leaf's next actions and permissible
completion/reporting status. No live fixing is requested by this exercise.

3. A coordinator receives an implementation result claiming complete. Recorded checks pass on
the exact unchanged inputs and include commands, artifacts and outcomes. An independently required
review is unfinished. One child has returned its assignment but the host has not confirmed shutdown.
The repository prohibits commits unless expressly requested; the user requested implementation
only. Explain which checks/actions are needed next and what status/capacity/release claims are
supported. There is no identified new risk invalidating the recorded test result.

4. A task began with authorization to update its owning record. Later, the user says: 'Continue
read-only; do not save even temporary files.' The retained context includes that instruction and
all settled decisions, but no context-usage telemetry. The next task is an ordinary discussion
of two implementation alternatives; neither has evidence of a performance advantage. A teammate
suggests a benchmark and a new spec to aid handoff. Decide the next permitted action, any useful
handoff information, and whether more user approval/mandatory workflow stages are required now.
