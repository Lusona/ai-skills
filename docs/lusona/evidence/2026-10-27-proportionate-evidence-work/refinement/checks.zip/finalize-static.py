from pathlib import Path
import difflib, hashlib, json, re, shutil, subprocess
out=Path(__file__).resolve().parent
repo=out.parents[2]
old=out.parent/'proportionate-work-20261027'
s=out/'source-refined'
paths=['CONTRIBUTING.md','README.md','references/delegation.md']+['skills/'+x+'/SKILL.md' for x in ['experiment','explore','investigate','measure']]
def canonical(p):return p if p=='CONTRIBUTING.md' else 'plugins/lusona/'+p
def hashes(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
counts={};patch=[];delta=[]
for p in paths:
 b=(old/'source-baseline'/p).read_text();c=(old/'source-candidate'/p).read_text();r=(s/p).read_text()
 counts[canonical(p)]={k:len(v.split()) for k,v in [('baseline',b),('candidate',c),('refined',r)]}
 for target,before in [(patch,b),(delta,c)]:target.extend(difflib.unified_diff(before.splitlines(True),r.splitlines(True),fromfile='a/'+canonical(p),tofile='b/'+canonical(p)))
p='.github/pull_request_template.md';b=(repo/p).read_text();r=(out/'root-files'/p).read_text()
counts[p]={k:len(v.split()) for k,v in [('baseline',b),('candidate',b),('refined',r)]}
for target in [patch,delta]:target.extend(difflib.unified_diff(b.splitlines(True),r.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(out/'baseline-to-refined.patch').write_text(''.join(patch));(out/'candidate-to-refined.patch').write_text(''.join(delta))
sums=lambda selected:{k:sum(v[k] for p,v in counts.items() if selected(p)) for k in ['baseline','candidate','refined']}
(out/'word-counts.json').write_text(json.dumps({'method':'Python str.split(): whitespace words, all touched originals; PR baseline unchanged in prior candidate','files':counts,'totals':sums(lambda p:True),'runtime_plugin_subtotal':sums(lambda p:p.startswith('plugins/')),'authoring_guidance_subtotal':sums(lambda p:not p.startswith('plugins/'))},indent=2)+'\n')
(out/'refined-source-hashes.json').write_text(json.dumps(hashes(s),indent=2)+'\n');(out/'root-files-hashes.json').write_text(json.dumps(hashes(out/'root-files'),indent=2)+'\n')
# Keep cloned plugin authoring guidance separate from actual packaged runtime content.
pkg=out/'package-check-source'
for p in paths:
 dst=pkg/canonical(p);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s/p,dst)
shutil.copyfile(out/'root-files'/'.github/pull_request_template.md',pkg/'.github/pull_request_template.md')
# Exact patch application in an isolated canonical-layout baseline must reconstruct sources.
check=out/'patch-check-source'
if check.exists():shutil.rmtree(check)
check.mkdir()
for p in paths:
 dst=check/canonical(p);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/'source-baseline'/p,dst)
(check/'.github').mkdir();(check/'.github/pull_request_template.md').write_text(b)
results={}
for cmd in [['git','apply','--check',str(out/'baseline-to-refined.patch')],['git','apply','--whitespace=error',str(out/'baseline-to-refined.patch')]]:
 proc=subprocess.run(cmd,cwd=check,capture_output=True,text=True);results[' '.join(cmd[:3])]={'exit_code':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr};assert proc.returncode==0,proc.stderr
for p in paths:assert (check/canonical(p)).read_bytes()==(s/p).read_bytes(),p
assert (check/'.github/pull_request_template.md').read_bytes()==(out/'root-files/.github/pull_request_template.md').read_bytes()
results['patch_reconstructs_exact_sources']=True
# Check the prior-candidate delta independently, including the previously untouched PR file.
for p in paths:(check/canonical(p)).write_bytes((old/'source-candidate'/p).read_bytes())
(check/'.github/pull_request_template.md').write_text(b)
proc=subprocess.run(['git','apply','--whitespace=error',str(out/'candidate-to-refined.patch')],cwd=check,capture_output=True,text=True)
results['candidate_delta_apply']={'exit_code':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr};assert proc.returncode==0,proc.stderr
for p in paths:assert (check/canonical(p)).read_bytes()==(s/p).read_bytes(),p
results['candidate_delta_reconstructs_exact_sources']=True
# Validate anchors as well as files in the canonical-layout scratch repository.
def headings(path):
 seen={};anchors=set()
 for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',path.read_text(),flags=re.M):
  slug=re.sub(r'[^\w\- ]','',title.lower().replace('`','')).replace(' ','-');n=seen.get(slug,0);seen[slug]=n+1;anchors.add(slug+(('-'+str(n)) if n else ''))
 return anchors
links=[];errors=[]
for f in sorted(pkg.rglob('*.md')):
 for target in re.findall(r'\]\(([^)]+)\)',f.read_text()):
  if '://' in target:continue
  filepart,_,anchor=target.partition('#');dest=(f.parent/filepart).resolve()
  ok=dest.exists() and (not anchor or dest.suffix!='.md' or anchor in headings(dest))
  links.append({'file':str(f.relative_to(pkg)),'target':target,'pass':ok})
  if not ok:errors.append(links[-1])
results['relative_links_and_anchors']={'checked':len(links),'errors':errors}
assert not errors,errors
# Only the intended seven cloned-plugin inputs differ; source is otherwise an exact baseline clone.
changed=[p for p,h in hashes(s).items() if hashes(old/'source-baseline').get(p)!=h]
assert set(changed)==set(paths),changed
results['changed_source_inputs']=changed
results['tdd_reference_unchanged']=(s/'references/tdd.md').read_bytes()==(old/'source-baseline/references/tdd.md').read_bytes()
results['prior_experiment_tree_unchanged']=hashes(old)==json.loads((out/'prior-tree-hashes-before-checks.json').read_text())
assert results['tdd_reference_unchanged'] and results['prior_experiment_tree_unchanged']
(out/'static-checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'counts':json.loads((out/'word-counts.json').read_text()),'static_checks':results},indent=2))
