## Change

Describe the problem and resulting behavior. Link a related issue if applicable.

## Verification

Follow [behavioral evidence requirements](../CONTRIBUTING.md#behavioral-evidence).

- TDD policy and source; named test-first behaviors and red/green references, if applicable:
- Selected positive/boundary/multi-turn cases and coverage rationale:
- Baseline/candidate and condition identifiers; exact evidence references and access:
- Independent grader, grades, rationale, and any disagreement:
- Outcome summary, including unfavorable/incomplete results and planned but unrun trials:
- Repository checks performed and results:

For editorial-only changes, explain why behavior is preserved and give content/link
check results; trial fields may be marked not applicable with that rationale.

## Limitations

Note untested hosts, installation paths, interactive behavior, or other remaining gaps.
Write “None” if there are none.
