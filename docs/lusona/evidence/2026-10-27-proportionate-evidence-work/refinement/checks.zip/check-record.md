# Proposed refinement check record

Status: source refinement complete; canonical adoption and behavioral verification remain separate.
Authority: parent assignment to refine only the scratch prototype under this directory. Explicit
user-selected targeted TDD for the larger change is preserved. No source adoption, trial, network
study, commit, publication, dependency install, or additional child assignment occurred here.

## Reviewable inputs and deltas

- `source-refined/`: exact frozen baseline clone with seven scoped source edits. Its extra
  `CONTRIBUTING.md` is root authoring input, not bundled plugin content.
- `root-files/.github/pull_request_template.md`: eighth scoped source edit in canonical root layout.
- `baseline-to-refined.patch`: complete proposal with canonical repository paths.
- `candidate-to-refined.patch`: difference from the prior exact tested candidate.
- `refined-source-hashes.json`, `root-files-hashes.json`: SHA-256 identities of reviewable inputs.
- `word-counts.json`: per-file counts and separate runtime/authoring totals.

| Source | Baseline words | Prior candidate | Refined | Refined minus baseline |
| --- | ---: | ---: | ---: | ---: |
| Core README | 2,503 | 2,625 | 2,551 | +48 |
| Delegation reference | 811 | 811 | 841 | +30 |
| Experiment skill | 468 | 498 | 443 | -25 |
| Explore skill | 450 | 474 | 442 | -8 |
| Investigate skill | 540 | 567 | 521 | -19 |
| Measure skill | 452 | 481 | 442 | -10 |
| Runtime plugin subtotal | 5,224 | 5,456 | 5,240 | +16 |
| Contributor guidance | 1,208 | 1,303 | 1,182 | -26 |
| PR template | 117 | 117 | 117 | 0 |
| Authoring guidance subtotal | 1,325 | 1,420 | 1,299 | -26 |
| All touched sources | 6,549 | 6,876 | 6,539 | -10 |

Whitespace-delimited words use Python `str.split()`. Total reduction is 337 words relative to
prior candidate, but the always-loaded core still grows 48 words and runtime plugin grows 16
relative to baseline. This is a source-size result, not a latency, token, cost, or behavior claim.
No unrelated core cleanup was used to meet the aggregate target.

## Static and source checks

- Both exact patches apply without whitespace errors and reconstruct every intended refined
  byte in canonical-layout scratch files. No extra cloned-plugin inputs differ from baseline.
- All 522 relative Markdown resource links and heading anchors pass in the complete scratch
  canonical-layout repository, including new core links and the PR template.
- Four changed skill frontmatters exactly match baseline; required identifiers and next-action
  sections remain present. All four pass the skill-creator `quick_validate.py` validator.
- Initial validator attempts lacked PyYAML. Existing validation environment's Python symlink
  targeted removed 3.13.17; installed Python 3.13.18 reused its existing PyYAML through PYTHONPATH
  with bytecode writes disabled. No installation or environment repair occurred. Initial failures
  and successful recovery remain in `skill-validation.json`.
- An initial local invariant checker assumed every next-action heading was exactly `Next action`;
  Explore already uses `Outcome and next action`. Corrected the checker, not skill source;
  the successful checks and recovery are recorded in `source-invariants.json`.
- Claude Code 2.1.310 plugin validation passes with the pre-existing advice that the core README
  lacks a one-step marketplace installation line. Local native catalog validation passes.
  Those commands do not perform the directory safety scan or policy review.
- Scratch package build passes manifest identity/version alignment, all three catalog paths,
  template/link/resource and package selection checks. Packaged runtime hashes exactly match
  refined runtime source; contributor guidance matches root input and is absent from plugin root.
- `references/tdd.md` is byte-identical to baseline. The entire retained prior experiment tree
  is byte-identical to the refinement's pre-check snapshot; its trials and grades are unchanged.

Logs: `static-checks.json`, `source-invariants.json`, `skill-validation.json`,
`native-validation.json`, `catalog-validation.json`, `package-validation.json`.
`finalize-static.py` reproduces patches, counts, resource checks, and frozen-tree checks.

## Manual scope and invariant assessment

- AC1: Core alone owns study entry, finite authority/budget, no repeated authorization for
  routine execution, consequential missing questions, and continued work without repeated offers.
  Four task skills link to that owner rather than repeat its rules.
- AC2: Core explicitly preserves applicable checks, selected TDD, empirical acceptance and
  resource/permission boundaries, comparable improvement support, unmet/unsupported evidence,
  and independent work. Existing authority, evidence truthfulness, TDD, and completion rules
  remain binding and unchanged outside the narrow study/delegation paragraphs.
- AC3: Small self-contained available-input checks stay with their task owner, with existing
  evidence ownership. Ordinary diagnostics remain investigation. The narrow measurement/experiment
  delegation exception explicitly preserves independent review and other delegation requirements.
- Coordinator reconciliation now uses adequate worker results for unchanged inputs; changed
  inputs, failures, missing/unreliable evidence and unresolved concrete risks trigger reruns.
  Independently required checks/review, coordinator acceptance, and ownership transfers remain.
- AC4: Candidate-only coverage is allowed for low-risk noncomparative behavior with a rationale;
  named test-first, comparative, and consequential shared-boundary changes retain matched evidence.
  File count does not determine risk. PR metadata applies to chosen verification, including an
  explicit candidate-only comparison-ID exception and editorial static-check rationale.
- AC5: Contribution guidance preserves frozen cases/criteria, raw actor inputs separate from
  evaluator materials, actual actions/artifacts, actor-independent grading and role reuse,
  all unfavorable/unrun results, provenance/access, same-trial-session multi-turn coverage,
  no setup-as-red, characterization, and no retrospective repair of missed test-first sequencing.
- AC6: Existing entry points and contributor/PR guidance align at source level. No new policy
  file, preference interview, configuration, mandatory report, broad delegation redesign, or
  numeric universal budget is introduced. Independent review remains with parent.

These are source inspections, not behavioral acceptance or a declaration that AC1–AC6 are fulfilled
by canonical implementation. The new evidence-ownership wording concerns a consequential boundary;
its actual behavior has not been trialed.

## Limits and recovery

No fresh behavioral trial ran; the old finite trial budget was exhausted. Prior 5/6 baseline and
6/6 candidate outcomes characterize only the exact prior candidate. They do not establish the
refinement's behavior or a red/green cycle for its new reconciliation wording. Existing targeted
TDD remains unchanged; required fresh evidence cannot be replaced by static checks or retrospective
claims. Canonical adoption needs its own authorization and verification decision.

Installation, interactive/native question behavior, safety scans, broad host coverage, and runtime
performance were not tested. The refinement does not prove that duplicate verification stops in
practice. The retained observed duplicate unittest invocation remains adverse characterization
of the prior candidate.

All outputs and package scratch remain under this directory. No active operations or children.
No behavioral correction rounds. Two local verification-tool recoveries made progress: missing
validator dependency/interpreter resolution and overly narrow heading-check correction;
0 consecutive without progress / 2 total tool recoveries. Next action: parent obtains independent
source review, reconciles evidence/limitations, and owns any authorized durable records or next step.
