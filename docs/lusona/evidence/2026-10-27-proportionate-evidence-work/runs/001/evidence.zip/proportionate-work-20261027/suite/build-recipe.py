import json,pathlib
root=pathlib.Path.cwd()
changes=[]
def replace(path,old,new):
 text=(root/path).read_text()
 assert text.count(old)==1,(path,old[:80],text.count(old))
 changes.append({'path':path,'old':old,'new':new})
core='plugins/lusona/README.md'
old='''Use [measure](skills/measure/SKILL.md) when a decision depends on an unknown magnitude,
an unsupported comparison, or stale evidence; use [experiment](skills/experiment/SKILL.md)
when testing an intervention or comparing alternatives. These responsibilities can arise
naturally during authorized work without another command or a mandatory phase. Choose the
smallest study that could change the decision, within current scope and resource authority.
Diagnostic experiments remain with [investigate](skills/investigate/SKILL.md).
Retain material measurements and experiments under the [evidence rules](references/evidence.md);
connect findings to the goal and distinguish current blockers from separate opportunities.'''
new='''Ordinary design alternatives or optional uncertainty do not initiate a study. Optional
[measurements](skills/measure/SKILL.md) and [experiments](skills/experiment/SKILL.md) require an
explicit request or applicable standing authority and finite scope/resource budget. Resolve
routine bounded execution details within that authority; an explicit request needs no repeated
approval. Ask only for missing consequential decisions or commitments. Without optional-study
authority, state relevant uncertainty and continue authorized work without repeated study offers.

Applicable correctness checks, selected TDD, and empirical acceptance criteria remain required;
verified improvement claims need comparable support. When required evidence is unavailable within
authority, identify the unmet requirement or unsupported claim and continue independent work.
Do not waive criteria, invent findings, verify a candidate gain without support, or expand resource
or permission boundaries. Small self-contained empirical checks with available tools and inputs
may stay with the task owner without an extra measurement/experiment delegate, study stage, or
record. Ordinary diagnostic probes remain [investigation](skills/investigate/SKILL.md).
Keep routine check evidence with its task; retain material decision evidence and provenance under
the [evidence rules](references/evidence.md). Connect findings to the goal and distinguish
current blockers from separate opportunities.'''
replace(core,old,new)
replace(core,'''implementation planning/execution, refactoring, investigation, measurement, experimentation,
and review. Delegating only preliminary inspection is insufficient. Explore/status conversation and orientation can remain
local. One sequential worker suffices; parallelism is optional.''','''implementation planning/execution, refactoring, investigation, measurement, experimentation,
and review. Small self-contained task-local checks described in Work loop do not require an
additional measurement or experiment delegate; this exception does not relax independent review
or other delegation requirements. Delegating only preliminary inspection is insufficient.
Explore/status conversation and orientation can remain local. One sequential worker suffices;
parallelism is optional.''')
replace('plugins/lusona/skills/measure/SKILL.md', '''Measurement may arise within any authorized task; it is not a mandatory phase. Reuse the
decision, scope, and evidence already established. A request to measure does not authorize
production changes or consequential data collection beyond that scope.''','''Use the core's study-entry and task-local-check rules. Optional measurement requires an explicit
request or standing authority and finite scope/resource budget; a direct bounded request supplies
ordinary local execution authority without another approval. Reuse settled decisions and evidence.
Required checks and empirical acceptance stay required within existing authority; report missing
evidence and continue independent work. Measurement does not authorize production changes or
consequential data collection beyond scope.''')
replace('plugins/lusona/skills/experiment/SKILL.md', '''An experiment may arise naturally within existing authority; it is not a mandatory phase.
Reuse accepted scope and settled decisions. Diagnostic cause or feasibility questions can use
[investigate](../investigate/SKILL.md); [measure](../measure/SKILL.md) supplies measurement
discipline when magnitude or quality needs evaluation. These responsibilities do not require
separate stages or another approval within the existing scope.''','''Use the core's study-entry and task-local-check rules. Optional experiments require an explicit
request or standing authority and finite scope/resource budget; ordinary alternatives alone do
not launch a study. Reuse accepted scope and decisions. A direct bounded request needs no repeated
approval for routine local execution. Required empirical acceptance remains required within
existing authority; identify missing evidence and continue independent work. Diagnostic cause or
feasibility probes stay with [investigate](../investigate/SKILL.md); [measure](../measure/SKILL.md)
supplies measurement discipline. Small task-local checks need no separate stage or extra delegate.''')
replace('plugins/lusona/skills/explore/SKILL.md', '''Verify material external claims when needed and permitted, citing support. Mark claims you
could not confirm and say where you looked. For an unknown magnitude, use
[measure](../measure/SKILL.md); for testing an intervention or alternatives, use [experiment](../experiment/SKILL.md). Route causal or technical feasibility
uncertainty to [investigate](../investigate/SKILL.md).
Keep research within the request.''','''Verify material external claims when needed and permitted, citing support. Mark claims you
could not confirm and say where you looked. Apply the core's study-entry rules before optional
[measurement](../measure/SKILL.md) or [experimentation](../experiment/SKILL.md): unknown magnitudes
or alternatives alone do not launch a study or block discussion. Without authority, state the
uncertainty and continue the requested discussion without repeated study offers. Route ordinary
causal or technical feasibility probes to [investigate](../investigate/SKILL.md).
Keep research within the request.''')
replace('plugins/lusona/skills/investigate/SKILL.md', '''Material measurements and diagnostic experiments follow the shared
[evidence rules](../../references/evidence.md); link exact runs from the owning investigation
rather than duplicating results in notes. Diagnostic experiments stay with this skill; use
[experiment](../experiment/SKILL.md) when evaluating an intervention is itself the outcome,
and [measure](../measure/SKILL.md) when the question is magnitude rather than cause.''','''Ordinary diagnostic probes remain investigation and do not automatically create a study,
extra delegate, stage, or record. Keep routine check evidence with the existing task; material
decision evidence follows the shared [evidence rules](../../references/evidence.md), linking
exact runs from the owning investigation rather than duplicating results. Apply the core's
study-entry rules before [experiment](../experiment/SKILL.md) for intervention evaluation or
[measure](../measure/SKILL.md) for magnitude. Required checks remain required within authority;
missing evidence does not authorize a wider study or block independent work.''')
contrib='CONTRIBUTING.md'
replace(contrib,'''   Editorial changes that preserve behavior may use content/link checks alone with a
   rationale explaining why behavioral trials are unnecessary.''','''   Low-risk, noncomparative behavior changes may use relevant candidate-only checks with
   an explicit coverage rationale. Matched baseline/candidate evidence remains required for
   named test-first behaviors, comparative improvement claims, and consequential shared
   boundaries such as authority, TDD, completion, trust, persistent data, or cross-worker
   ownership. File count alone does not set risk. Editorial changes preserving behavior
   may use content/link checks with a behavior-preserving rationale.''')
replace(contrib,'''2. **Declare the comparison before trials.** Freeze cases and outcome criteria, exact
   inputs, baseline/candidate revisions or hashes and local modifications, host/version,
   model/reasoning settings, relevant capabilities/permissions, finite run budget, and
   stopping condition. Use an unchanged baseline captured before relevant edits or
   recoverable from a pinned snapshot. Keep relevant conditions matched except for the
   intended change; disclose mismatches and restrict claims they cannot support.''','''2. **Declare verification before trials.** Freeze applicable cases and outcome criteria,
   exact inputs, candidate revisions or hashes and local modifications, host/version,
   model/reasoning settings, relevant capabilities/permissions, finite run budget, and
   stopping condition. When comparison is required under item 1, pin an unchanged baseline
   captured before relevant edits or recoverable from a pinned snapshot; keep relevant
   conditions matched except for the intended change. Disclose mismatches and restrict
   claims they cannot support. Candidate-only checks do not need comparison identifiers.''')
replace(contrib,'''   of the actor grades
   retained conversation''','''   of the actor grades
   retained conversation''') if False else None
replace(contrib,'''   criteria. Judge outcomes and boundaries, not wording, headings, tool order, or question
   counts. Supplement with deterministic state checks where useful.''','''   criteria. Judge outcomes and boundaries, not wording, headings, tool order, or question
   counts. One qualified independent reviewer may assess both the diff and those outcomes;
   do not require another reviewer solely for a role label. Supplement with deterministic
   state checks where useful.''')
replace(contrib,'''A contribution summary should identify TDD policy/source, selected cases and rationale,
condition identifiers, independent grades, outcome totals (including incomplete/unrun
work), exact evidence references, and limitations. For editorial-only changes, provide
the behavior-preserving rationale and static-check results instead of trial metadata.''','''A contribution summary should identify TDD policy/source, chosen verification and coverage
rationale, applicable condition identifiers and independent grades, outcome totals (including
incomplete/unrun work), exact evidence references, and limitations. Comparison identifiers
apply only when comparison is required; their absence is not a candidate-only defect.
For editorial-only changes, provide the behavior-preserving rationale and static-check
results instead of trial metadata.''')
# Reject accidental overlap and verify the recipe applies sequentially to current originals.
texts={}
for c in changes:
 text=texts.setdefault(c['path'],(root/c['path']).read_text())
 assert text.count(c['old'])==1,c['path']
 texts[c['path']]=text.replace(c['old'],c['new'],1)
md='''# Candidate recipe — not applied\n\nApply only after the parent has captured the unchanged baseline and resolved the selected\ntest-first sequence. This recipe authorizes no canonical changes. Each replacement below\nrequires exactly one occurrence of `old`; abort rather than silently drift. Paths name canonical\nsources as provenance; for scratch application map `plugins/lusona/` to the scratch clone root\nand `CONTRIBUTING.md` to its extra read-only contributor file. Preserve all other bytes.\n\nThe Work loop replacement implements AC1–AC3 without weakening required evidence; the\ndelegation exception is only for small task-local checks. Skill replacements align their entry\npoints. Contributor edits implement the AC4 candidate-only path while retaining stronger\ncomparison requirements, sequencing, frozen independent outcomes, and unfavorable evidence\nunder AC5. Existing evidence/TDD references already preserve setup-vs-red and prior records;\nno change is proposed there. No performance gain is claimed.\n\nExact replacements (ordered JSON):\n\n```json\n'''+json.dumps(changes,indent=2)+'''\n```\n\nVerification before scratch captures: every old string matched once, only these six source\nfiles plus the contributor file changed, relative links resolve in the clone, and source/hash\nidentifiers are recorded. Canonical packaging/manifests/install behavior are outside this\nprototype. The independent evaluator may recommend refine/reject; no implementation is authorized.\n'''
p=root/'tmp/evidence-aware-eval/proportionate-work-20261027/candidate-recipe.md'
with p.open('x') as f:f.write(md)
print(f'Prepared {len(changes)} exact replacements across {len(texts)} files; no candidate instructions edited.')
