"""One-off orchestration of the existing capture runner; no grading or retries."""
from pathlib import Path
import importlib.util
import sys
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
spec = importlib.util.spec_from_file_location('existing_capture', ROOT / 'evals/evidence-aware/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.HERE = BASE / 'suite'

if sys.argv[1] == 'freeze':
    arm = sys.argv[2]
    source = BASE / ('source-baseline' if arm == 'arm-a' else 'source-candidate')
    path = runner.freeze(source, BASE / 'conditions' / arm, 'gpt-6.1-sol', 'medium', 300)
    print(path, flush=True)
elif sys.argv[1] == 'capture':
    arm = sys.argv[2]
    condition = BASE / 'conditions' / arm
    cases = json.loads((condition / 'scenarios.json').read_text())
    runs = []
    for case in cases:
        run = runner.prepare(condition, case, 1, BASE / 'runs' / arm / case / '1')
        runs.append((case, run))
    def capture_case(item):
        case, run = item
        outputs = []
        for turn in range(len(cases[case]['turns'])):
            print(json.dumps({'event':'start','arm':arm,'case':case,'turn':turn+1}), flush=True)
            result = runner.capture(run)
            outputs.append(result)
            print(json.dumps({'event':'captured','arm':arm,'case':case,'turn':turn+1,'status':result['status'],'session':result.get('session')}), flush=True)
            if result['status'] != 'captured':
                break
        return {'case':case,'statuses':[r['status'] for r in outputs]}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(capture_case, item) for item in runs]
        results = [f.result() for f in as_completed(futures)]
    runner.save(BASE / f'{arm}-capture-index.json', results)
    print(json.dumps({'event':'condition-complete','arm':arm,'results':results}), flush=True)
else:
    raise SystemExit('Use freeze|capture arm-a|arm-b')
