# Candidate recipe — not applied

Apply only after the parent has captured the unchanged baseline and resolved the selected
test-first sequence. This recipe authorizes no canonical changes. Each replacement below
requires exactly one occurrence of `old`; abort rather than silently drift. Paths name canonical
sources as provenance; for scratch application map `plugins/lusona/` to the scratch clone root
and `CONTRIBUTING.md` to its extra read-only contributor file. Preserve all other bytes.

The Work loop replacement implements AC1–AC3 without weakening required evidence; the
delegation exception is only for small task-local checks. Skill replacements align their entry
points. Contributor edits implement the AC4 candidate-only path while retaining stronger
comparison requirements, sequencing, frozen independent outcomes, and unfavorable evidence
under AC5. Existing evidence/TDD references already preserve setup-vs-red and prior records;
no change is proposed there. No performance gain is claimed.

Exact replacements (ordered JSON):

```json
[
  {
    "path": "plugins/lusona/README.md",
    "old": "Use [measure](skills/measure/SKILL.md) when a decision depends on an unknown magnitude,\nan unsupported comparison, or stale evidence; use [experiment](skills/experiment/SKILL.md)\nwhen testing an intervention or comparing alternatives. These responsibilities can arise\nnaturally during authorized work without another command or a mandatory phase. Choose the\nsmallest study that could change the decision, within current scope and resource authority.\nDiagnostic experiments remain with [investigate](skills/investigate/SKILL.md).\nRetain material measurements and experiments under the [evidence rules](references/evidence.md);\nconnect findings to the goal and distinguish current blockers from separate opportunities.",
    "new": "Ordinary design alternatives or optional uncertainty do not initiate a study. Optional\n[measurements](skills/measure/SKILL.md) and [experiments](skills/experiment/SKILL.md) require an\nexplicit request or applicable standing authority and finite scope/resource budget. Resolve\nroutine bounded execution details within that authority; an explicit request needs no repeated\napproval. Ask only for missing consequential decisions or commitments. Without optional-study\nauthority, state relevant uncertainty and continue authorized work without repeated study offers.\n\nApplicable correctness checks, selected TDD, and empirical acceptance criteria remain required;\nverified improvement claims need comparable support. When required evidence is unavailable within\nauthority, identify the unmet requirement or unsupported claim and continue independent work.\nDo not waive criteria, invent findings, verify a candidate gain without support, or expand resource\nor permission boundaries. Small self-contained empirical checks with available tools and inputs\nmay stay with the task owner without an extra measurement/experiment delegate, study stage, or\nrecord. Ordinary diagnostic probes remain [investigation](skills/investigate/SKILL.md).\nKeep routine check evidence with its task; retain material decision evidence and provenance under\nthe [evidence rules](references/evidence.md). Connect findings to the goal and distinguish\ncurrent blockers from separate opportunities."
  },
  {
    "path": "plugins/lusona/README.md",
    "old": "implementation planning/execution, refactoring, investigation, measurement, experimentation,\nand review. Delegating only preliminary inspection is insufficient. Explore/status conversation and orientation can remain\nlocal. One sequential worker suffices; parallelism is optional.",
    "new": "implementation planning/execution, refactoring, investigation, measurement, experimentation,\nand review. Small self-contained task-local checks described in Work loop do not require an\nadditional measurement or experiment delegate; this exception does not relax independent review\nor other delegation requirements. Delegating only preliminary inspection is insufficient.\nExplore/status conversation and orientation can remain local. One sequential worker suffices;\nparallelism is optional."
  },
  {
    "path": "plugins/lusona/skills/measure/SKILL.md",
    "old": "Measurement may arise within any authorized task; it is not a mandatory phase. Reuse the\ndecision, scope, and evidence already established. A request to measure does not authorize\nproduction changes or consequential data collection beyond that scope.",
    "new": "Use the core's study-entry and task-local-check rules. Optional measurement requires an explicit\nrequest or standing authority and finite scope/resource budget; a direct bounded request supplies\nordinary local execution authority without another approval. Reuse settled decisions and evidence.\nRequired checks and empirical acceptance stay required within existing authority; report missing\nevidence and continue independent work. Measurement does not authorize production changes or\nconsequential data collection beyond scope."
  },
  {
    "path": "plugins/lusona/skills/experiment/SKILL.md",
    "old": "An experiment may arise naturally within existing authority; it is not a mandatory phase.\nReuse accepted scope and settled decisions. Diagnostic cause or feasibility questions can use\n[investigate](../investigate/SKILL.md); [measure](../measure/SKILL.md) supplies measurement\ndiscipline when magnitude or quality needs evaluation. These responsibilities do not require\nseparate stages or another approval within the existing scope.",
    "new": "Use the core's study-entry and task-local-check rules. Optional experiments require an explicit\nrequest or standing authority and finite scope/resource budget; ordinary alternatives alone do\nnot launch a study. Reuse accepted scope and decisions. A direct bounded request needs no repeated\napproval for routine local execution. Required empirical acceptance remains required within\nexisting authority; identify missing evidence and continue independent work. Diagnostic cause or\nfeasibility probes stay with [investigate](../investigate/SKILL.md); [measure](../measure/SKILL.md)\nsupplies measurement discipline. Small task-local checks need no separate stage or extra delegate."
  },
  {
    "path": "plugins/lusona/skills/explore/SKILL.md",
    "old": "Verify material external claims when needed and permitted, citing support. Mark claims you\ncould not confirm and say where you looked. For an unknown magnitude, use\n[measure](../measure/SKILL.md); for testing an intervention or alternatives, use [experiment](../experiment/SKILL.md). Route causal or technical feasibility\nuncertainty to [investigate](../investigate/SKILL.md).\nKeep research within the request.",
    "new": "Verify material external claims when needed and permitted, citing support. Mark claims you\ncould not confirm and say where you looked. Apply the core's study-entry rules before optional\n[measurement](../measure/SKILL.md) or [experimentation](../experiment/SKILL.md): unknown magnitudes\nor alternatives alone do not launch a study or block discussion. Without authority, state the\nuncertainty and continue the requested discussion without repeated study offers. Route ordinary\ncausal or technical feasibility probes to [investigate](../investigate/SKILL.md).\nKeep research within the request."
  },
  {
    "path": "plugins/lusona/skills/investigate/SKILL.md",
    "old": "Material measurements and diagnostic experiments follow the shared\n[evidence rules](../../references/evidence.md); link exact runs from the owning investigation\nrather than duplicating results in notes. Diagnostic experiments stay with this skill; use\n[experiment](../experiment/SKILL.md) when evaluating an intervention is itself the outcome,\nand [measure](../measure/SKILL.md) when the question is magnitude rather than cause.",
    "new": "Ordinary diagnostic probes remain investigation and do not automatically create a study,\nextra delegate, stage, or record. Keep routine check evidence with the existing task; material\ndecision evidence follows the shared [evidence rules](../../references/evidence.md), linking\nexact runs from the owning investigation rather than duplicating results. Apply the core's\nstudy-entry rules before [experiment](../experiment/SKILL.md) for intervention evaluation or\n[measure](../measure/SKILL.md) for magnitude. Required checks remain required within authority;\nmissing evidence does not authorize a wider study or block independent work."
  },
  {
    "path": "CONTRIBUTING.md",
    "old": "   Editorial changes that preserve behavior may use content/link checks alone with a\n   rationale explaining why behavioral trials are unnecessary.",
    "new": "   Low-risk, noncomparative behavior changes may use relevant candidate-only checks with\n   an explicit coverage rationale. Matched baseline/candidate evidence remains required for\n   named test-first behaviors, comparative improvement claims, and consequential shared\n   boundaries such as authority, TDD, completion, trust, persistent data, or cross-worker\n   ownership. File count alone does not set risk. Editorial changes preserving behavior\n   may use content/link checks with a behavior-preserving rationale."
  },
  {
    "path": "CONTRIBUTING.md",
    "old": "2. **Declare the comparison before trials.** Freeze cases and outcome criteria, exact\n   inputs, baseline/candidate revisions or hashes and local modifications, host/version,\n   model/reasoning settings, relevant capabilities/permissions, finite run budget, and\n   stopping condition. Use an unchanged baseline captured before relevant edits or\n   recoverable from a pinned snapshot. Keep relevant conditions matched except for the\n   intended change; disclose mismatches and restrict claims they cannot support.",
    "new": "2. **Declare verification before trials.** Freeze applicable cases and outcome criteria,\n   exact inputs, candidate revisions or hashes and local modifications, host/version,\n   model/reasoning settings, relevant capabilities/permissions, finite run budget, and\n   stopping condition. When comparison is required under item 1, pin an unchanged baseline\n   captured before relevant edits or recoverable from a pinned snapshot; keep relevant\n   conditions matched except for the intended change. Disclose mismatches and restrict\n   claims they cannot support. Candidate-only checks do not need comparison identifiers."
  },
  {
    "path": "CONTRIBUTING.md",
    "old": "   criteria. Judge outcomes and boundaries, not wording, headings, tool order, or question\n   counts. Supplement with deterministic state checks where useful.",
    "new": "   criteria. Judge outcomes and boundaries, not wording, headings, tool order, or question\n   counts. One qualified independent reviewer may assess both the diff and those outcomes;\n   do not require another reviewer solely for a role label. Supplement with deterministic\n   state checks where useful."
  },
  {
    "path": "CONTRIBUTING.md",
    "old": "A contribution summary should identify TDD policy/source, selected cases and rationale,\ncondition identifiers, independent grades, outcome totals (including incomplete/unrun\nwork), exact evidence references, and limitations. For editorial-only changes, provide\nthe behavior-preserving rationale and static-check results instead of trial metadata.",
    "new": "A contribution summary should identify TDD policy/source, chosen verification and coverage\nrationale, applicable condition identifiers and independent grades, outcome totals (including\nincomplete/unrun work), exact evidence references, and limitations. Comparison identifiers\napply only when comparison is required; their absence is not a candidate-only defect.\nFor editorial-only changes, provide the behavior-preserving rationale and static-check\nresults instead of trial metadata."
  }
]
```

Verification before scratch captures: every old string matched once, only these five plugin source
files plus the contributor file changed, relative links resolve in the clone, and source/hash
identifiers are recorded. Canonical packaging/manifests/install behavior are outside this
prototype. The independent evaluator may recommend refine/reject; no implementation is authorized.
