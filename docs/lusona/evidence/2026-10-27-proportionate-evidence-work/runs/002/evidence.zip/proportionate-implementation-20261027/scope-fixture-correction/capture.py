from pathlib import Path
import importlib.util,json,sys
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[3]
spec=importlib.util.spec_from_file_location('runner',ROOT/'evals/evidence-aware/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);r.HERE=BASE/'suite'
if sys.argv[1]=='freeze':
 for arm in ['baseline','candidate']:r.freeze(BASE/('source-'+arm),BASE/'conditions'/arm,'gpt-6.1-sol','medium',300)
elif sys.argv[1]=='capture':
 for arm in ['baseline','candidate']:
  run=r.prepare(BASE/'conditions'/arm,'scope-case',1,BASE/'runs'/arm/'scope-case'/'1')
  print(json.dumps({'event':'start','arm':arm}),flush=True)
  result=r.capture(run)
  print(json.dumps({'event':'captured','arm':arm,'status':result['status'],'session':result.get('session')}),flush=True)
  if result['status']!='captured':raise SystemExit('Stop on incomplete capture; no retry.')
else:raise SystemExit('freeze|capture')
