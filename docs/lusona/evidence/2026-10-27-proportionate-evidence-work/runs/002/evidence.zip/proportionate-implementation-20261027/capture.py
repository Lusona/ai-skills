"""Bounded implementation verification using the existing capture runner, without retries."""
from pathlib import Path
import importlib.util,json,sys
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
spec=importlib.util.spec_from_file_location('capture_runner',ROOT/'evals/evidence-aware/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
runner.HERE=BASE/'suite'
action,arm=sys.argv[1:3]
if action=='freeze':
 print(runner.freeze(BASE/('source-'+arm),BASE/'conditions'/arm,'gpt-6.1-sol','medium',300))
elif action=='capture':
 cases=json.loads((BASE/'conditions'/arm/'scenarios.json').read_text())
 selected=[c for c in cases if arm=='candidate' or c.startswith('verification-reuse-')]
 assert len(selected)==(8 if arm=='candidate' else 2)
 results=[]
 for case in selected:
  run=runner.prepare(BASE/'conditions'/arm,case,1,BASE/'runs'/arm/case/'1')
  statuses=[]
  for turn in range(len(cases[case]['turns'])):
   print(json.dumps({'event':'start','arm':arm,'case':case,'turn':turn+1}),flush=True)
   r=runner.capture(run);statuses.append(r['status'])
   print(json.dumps({'event':'captured','arm':arm,'case':case,'turn':turn+1,'status':r['status'],'session':r.get('session')}),flush=True)
   if r['status']!='captured':break
  results.append({'case':case,'statuses':statuses})
  runner.save(BASE/(arm+'-capture-index.json'),results)
  if any(s!='captured' for s in statuses):
   raise SystemExit('Stopping for incomplete capture; preserve remaining unrun budget.')
 print(json.dumps({'event':'complete','arm':arm,'results':results}),flush=True)
else:raise SystemExit('freeze|capture baseline|candidate')
