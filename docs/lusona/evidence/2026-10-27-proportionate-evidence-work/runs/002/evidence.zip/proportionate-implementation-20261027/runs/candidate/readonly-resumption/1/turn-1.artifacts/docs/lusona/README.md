# Synthetic parser diagnosis
TDD: targeted, user-selected. Named test-first behavior: invalid quantities are rejected; production edits are not authorized. Existing parser is unchanged.
