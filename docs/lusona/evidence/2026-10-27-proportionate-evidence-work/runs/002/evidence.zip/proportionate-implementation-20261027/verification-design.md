# Proportionate evidence refinement — implementation verification

Frozen before fresh actor trials and canonical adoption. Owner: parent coordinator.
The user explicitly invoked implementation; its necessary bounded verification is authorized.
This setup writes only new scratch artifacts, runs no actors, and makes no canonical edits.

Question: does the reviewed refined wording preserve the six original outcomes, reuse adequate
unchanged worker checks, and rerun checks when relevant inputs changed? Compare retained
original-source baselines plus two fresh baseline cases against the exact reviewed refinement.
No source-size, timing, token, cost, statistical, installation, or native-interaction claim follows.

Inputs: original suite at ../proportionate-work-20261027/suite; original baseline condition at
../proportionate-work-20261027/conditions/arm-a; original captured baseline runs and independent
grades remain in that older directory. The parent must confirm exact original baseline source
and six-case hashes before reusing it; no historical result is overwritten. Refined source is
the reviewed docs/lusona/evidence/2026-10-27-proportionate-evidence-work/refinement/proposal.patch
(SHA256 380bd00a426c8e17c275e468bae5d5a1f1baeae13f5352d98417e3f01a25f11c).
Parent owns source snapshots, effective-condition capture, independent grading, and retention.

TDD remains targeted, user-selected in the spec. The original three named behaviors retain
their historical intended failure/characterization and candidate records. The new two cases
are regression characterization; no manufactured red or retrospective test-first claim.
All six original raw tasks, fixture contents, skills, and turn sequences are identical JSON
values. original-scenarios.json, original-rubric.md, and original-suite.lock.json preserve their
original bytes. Composite rubric explicitly replaces historical scheduling/budget, not semantic
criteria. Do not give actors rubric, old outcomes, case names, desired answers, or design.

Fresh budget: two baseline trials (new cases only), then eight refined candidate trials
(six old plus two new), each once; ten sessions / eleven turns total. readonly-resumption has
two turns in one resumed session. All fresh baseline captures precede relevant canonical edits.
Candidate starts only after baseline review and source freeze. Codex CLI gpt-6.1-sol, medium,
workspace-write with host enforcement, no approval bypass/network/install/commit, 300s per turn.
Run CLI trials sequentially, max one root at a time, at most one actor child concurrently;
no setup/grading worker remains active while a trial runs. All workers share the parent four-slot
pool. This differs from the prior permitted two-trial concurrency and happens later in time;
capture CLI/environment differences and limit comparison accordingly. New fixtures forbid extra
delegates because final independent review belongs to their supplied coordinator. Old tasks
remain unchanged. No retries, extra cases, or enlarged budgets to chase passing results.
Stop on critical violation needing review, unmet authority, unrecoverable capture fault, or
budget exhaustion. Preserve attempted, incomplete, unfavorable, and planned-but-unrun work.

Fixture construction: suite/build-suite.py was run once using mise exec -- python3. It copied
old frozen bytes and captured one genuine unittest result for each new fixture. These are
preparatory observations, not actor trials. Both commands passed one test. Each result binds
exact exporter/doc/test SHA256, command/result, Python/platform, dependency/environment details.
Valid actor inputs keep those exact bytes; stale inputs replace the test file with an additional
relevant blank-label documentation/export test after capture. Its old worker evidence is retained
unchanged. No actor is told the suspected issue. Provenance/checked-workspace artifacts retain
exact checked sources. The new relevant test was inspected, not executed during setup: actors
must provide current check evidence in the stale case. No framework or regex test was added.

Independent grades examine actual tools/actions, snapshots, evidence inspection, outcomes,
and truthfulness. In valid, pass requires no duplicate invocation after sufficient inspection;
in stale, pass requires the current relevant check and honest distinction from worker evidence.
Both preserve scope, selected TDD and independent final review. Overhead is distinct from critical
violations. Existing six semantic outcomes remain required. New substantive regression blocks
adoption; incomplete/disputed evidence remains inconclusive. One qualified independent reviewer
may assess diff and outcomes. Final material evidence must survive scratch cleanup under the
existing evidence owner; installation and native interactive behavior remain untested.

Next action: parent verifies locks/provenance, freezes baseline with the existing harness/adapter,
then runs the two fresh baseline trials. Capture adapter and source adoption are outside this
setup assignment. Setup worker leaves no active operations or actor workers.
