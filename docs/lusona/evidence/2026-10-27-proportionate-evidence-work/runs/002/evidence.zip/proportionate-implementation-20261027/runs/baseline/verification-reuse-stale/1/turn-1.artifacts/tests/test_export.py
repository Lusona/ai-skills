import pathlib
import unittest
import exporter

class ExportDocsTest(unittest.TestCase):
    def test_documented_columns(self):
        text = pathlib.Path("docs/export.md").read_text()
        self.assertIn("Columns: " + ", ".join(exporter.COLUMNS) + ".", text)
        self.assertEqual(exporter.export([{"item_id": "17", "label": "Brush", "quantity": 2}]), [("17", "Brush", 2)])

    def test_blank_label(self):
        self.assertIn("Blank labels are supported.", pathlib.Path("docs/export.md").read_text())
        self.assertEqual(exporter.export([{"item_id": "23", "quantity": 3}]), [("23", "", 3)])
