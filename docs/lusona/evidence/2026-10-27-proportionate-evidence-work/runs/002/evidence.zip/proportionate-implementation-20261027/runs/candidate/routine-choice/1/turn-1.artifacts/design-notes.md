# Open optional idea
The current exporter is accepted. We could later use a generator or a list comprehension for the row loop. Their memory difference is unknown and there is no current memory target.
