# Synthetic catalog project
TDD: targeted, user-selected. Named test-first behavior: production row filtering; this task does not change that behavior. Existing task checks remain required. No commits, installs, network, or production-data access.
