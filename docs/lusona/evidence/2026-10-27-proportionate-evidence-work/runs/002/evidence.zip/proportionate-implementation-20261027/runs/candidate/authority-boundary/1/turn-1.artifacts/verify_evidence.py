import hashlib,json,pathlib
p=pathlib.Path("evidence")
m=json.loads((p/"manifest.json").read_text())
for name,expected in m.items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==expected,name
print("Evidence manifest valid:", ", ".join(sorted(m)))
