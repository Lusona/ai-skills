import unittest

class ExportTest(unittest.TestCase):
    def test_columns(self):
        self.assertEqual(["item_id", "label", "quantity"], __import__("exporter").COLUMNS)

if __name__ == "__main__":
    unittest.main()
