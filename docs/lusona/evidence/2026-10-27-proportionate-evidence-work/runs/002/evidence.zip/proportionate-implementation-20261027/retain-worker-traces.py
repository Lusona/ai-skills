"""Retain existing child traces linked by recorded root activity; launches no actors."""
from pathlib import Path
import json,hashlib,sys,time
base=Path(__file__).resolve().parent
sessions=Path.home()/'.codex/sessions'
for run in sorted((base/'runs'/sys.argv[1]).glob('*/1')):
 children=set()
 for f in run.glob('*.session-supplement-*.jsonl'):
  for line in f.read_text().splitlines():
   p=json.loads(line).get('payload',{}); item=p.get('item',{})
   if item.get('type')=='SubAgentActivity' and item.get('agent_thread_id'): children.add(item['agent_thread_id'])
 for child in sorted(children):
  out=run/'workers'/child
  if out.exists(): continue
  out.mkdir(parents=True)
  matches=list(sessions.rglob(f'rollout-*-{child}.jsonl'))
  meta={'session':child,'basis':'Exact child UUID in retained root SubAgentActivity','captured_at_unix':time.time(),'status':'unavailable','scope':'existing cumulative child tool/actions and assistant messages; user/developer/session metadata excluded'}
  if len(matches)==1:
   src=matches[0]; raw=src.read_bytes(); selected=[]
   for n,line in enumerate(raw.splitlines(),1):
    e=json.loads(line); p=e.get('payload',{}); k=p.get('type')
    if e.get('type')=='response_item' and (k in {'function_call','function_call_output','custom_tool_call','custom_tool_call_output'} or (k=='message' and p.get('role')=='assistant')):
     selected.append({'source_line':n,'timestamp':e.get('timestamp'),'type':e['type'],'payload':p})
   trace=out/'trace.jsonl'; trace.write_text(''.join(json.dumps(e,sort_keys=True)+'\n' for e in selected))
   meta.update(status='captured',source_locator=str(src.relative_to(sessions)),source_sha256=hashlib.sha256(raw).hexdigest(),trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),events=len(selected))
  (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
  print(run.parts[-3],child,meta['status'],meta.get('events'))
