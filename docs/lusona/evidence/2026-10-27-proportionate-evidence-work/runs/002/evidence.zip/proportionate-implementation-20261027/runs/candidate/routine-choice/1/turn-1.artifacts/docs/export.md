# Export
Columns: item_id, label, quantity.
