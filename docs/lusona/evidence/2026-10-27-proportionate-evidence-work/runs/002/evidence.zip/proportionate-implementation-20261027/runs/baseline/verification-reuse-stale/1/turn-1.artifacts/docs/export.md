# Export
Columns: item_id, label, quantity.
Blank labels are supported.
