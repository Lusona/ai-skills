# Catalog project
TDD: targeted, explicitly selected by the user. Named test-first behavior: production row filtering; this documentation task does not change it. Existing task verification remains required. No commits, installs, network, or production-data access.
