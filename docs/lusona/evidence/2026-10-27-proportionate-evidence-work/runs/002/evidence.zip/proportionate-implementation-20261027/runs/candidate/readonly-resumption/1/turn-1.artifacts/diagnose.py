import json
rows=[{"quantity":"1,5"},{"quantity":"2.0"}]
print(json.dumps({"rows":len(rows),"rejected":[r["quantity"] for r in rows if "," in r["quantity"]]},sort_keys=True))
