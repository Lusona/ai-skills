import pathlib
import unittest
import exporter

class ExportDocsTest(unittest.TestCase):
    def test_documented_columns(self):
        text = pathlib.Path("docs/export.md").read_text()
        self.assertIn("Columns: " + ", ".join(exporter.COLUMNS) + ".", text)
        self.assertEqual(exporter.export([{"item_id": "17", "label": "Brush", "quantity": 2}]), [("17", "Brush", 2)])
