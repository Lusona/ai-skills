COLUMNS = ["item_id", "label", "quantity"]

def export(rows):
    return [tuple(row.get(key, "") for key in COLUMNS) for row in rows]
