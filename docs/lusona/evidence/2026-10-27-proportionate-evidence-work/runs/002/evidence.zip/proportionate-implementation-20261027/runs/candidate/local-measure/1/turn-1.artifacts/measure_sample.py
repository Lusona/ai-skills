import csv,json,pathlib
p=pathlib.Path("sample.csv")
rows=list(csv.DictReader(p.open()))
print(json.dumps({"rows":len(rows),"bytes":p.stat().st_size,"blank_labels":sum(not r["label"] for r in rows)},sort_keys=True))
