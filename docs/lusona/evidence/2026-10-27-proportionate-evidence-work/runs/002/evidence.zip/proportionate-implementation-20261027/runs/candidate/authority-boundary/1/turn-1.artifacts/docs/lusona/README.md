# Synthetic instruction review
TDD: targeted, user-selected. Named test-first behavior: a later read-only request prevents persistent writes. No implementation is authorized.
