# Design command candidate verification — declared before actor dispatch

Actor host: Codex collaboration tool, gpt-6.1-sol / medium. Active host version is not exposed.
Local validation CLIs: Claude Code 2.1.317 and Antigravity CLI 1.4.12. These are separate from actor runtime.
Candidate source: isolated trial-plugin snapshot; hashes in trial-input-sha256.json.
No comparative gain claimed. Test-first command discovery/package checks are deterministic and retained separately.
UI/diagram instructions reuse existing authority/TDD/retention and consumer contracts; these contracts are unchanged.
Capabilities: local file reads/writes and shell; browser opening and screenshot capture unavailable in actor trials.
No network, production changes, commits, children, or writes outside each assigned case and its transcript directory.

Budget: three initial candidate sessions (C1/C2/C3), two predefined C1 follow-ups, one independent grader/source review.
At most one source-supported rerun per failing case, subject to repository correction limits. Stop after declared cases
are independently graded or an unavailable capability prevents the required observation. Keep all attempts.

Cases and frozen criteria (grader only):

- C1: direct two-option UI flow request in a project without Lusona records. Reuse Members/Invitations,
  Work email, Send invitation, failure copy and Retry; show ready/failure states, two labeled template-based
  options, browser-unavailable absolute-path fallback, no screenshots or chosen reference at draft stage.
  Follow-up 1 rejects both and asks for a different layout. Expect revised drafts, discarded rejected assets,
  material rejection reason retained, no prematurely chosen reference. Follow-up 2 chooses B and requests
  retention, with trial coordinator as chooser. Expect chosen HTML + reference with binding/illustrative items,
  notes owner/link without forced spec/ADR/queue, missing capture reported, no retained index/rejected assets.
  Original src/members.html must remain byte-identical throughout. Report next action without production edits.
- C2: settled single-mockup request using supplied source. Expect one draft with prescribed structure, no forced
  alternatives/choice switch/index, no chosen reference until rendered draft acceptance, no production edits,
  clear approximation/fidelity and absolute HTML path under browser-unavailable condition.
- C3: direct Mermaid invitation lifecycle diagram in a no-save request. Expect fenced Mermaid with accepted/expired
  paths; no diagram HTML/PNG, no forced alternatives/ADR, no saved artifacts and a bounded next action.

Raw prompts and exact actor responses retained separately. Grader judges semantic behavior, actual files/actions,
not headings or particular phrasing. Any source/fixture change after freezing is identified and relevant cases rerun.
