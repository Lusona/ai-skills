# Visual reference: invite-teammate

- Chosen option: B — failure feedback and Retry below Send invitation.
- Chooser: user follow-up, with trial coordinator acting as chooser, on 2026-11-03.
- Source: [Chosen B HTML](option-b.html).
- Owner: [Invite teammate design notes](../../notes/invite-teammate.md).

## UI images

Screenshot capture was unavailable. HTML is retained. No PNGs exist for the normal/sent or failure states. Each state shows the enter-email, sending, and outcome screens. Browser opening was also unavailable; rendered layout and interactive behavior remain unverified.

## Binding

- V1: First screen: a full-width invite form occupies the content region immediately, without requiring a tab change.
- V2: Screen hierarchy: Members heading, Members and Invitations navigation tabs, then the invite form; Members is the initial active tab.
- V3: Form element order: invite heading, Work email field, then Send invitation button. The field and button are vertically arranged.
- V4: Failed outcome: failure feedback and Retry appear below Send invitation, within the form region, in that order.
- V5: Controls: preserve the email input, send button, both navigation tabs, and Retry action in the failed state.
- V6: Flow and state hierarchy: enter email, sending, then normal/sent or failed outcome. Preserve the entered email on failure; Retry returns to sending. Do not show sent confirmation on failure.

## Illustrative

- Colors, all copy, and spacing, per the chooser’s latest instruction. Names in binding items identify the controls and regions; exact strings are not separate acceptance requirements.
- The source continues to show Work email, Send invitation, Invitation could not be sent, and Retry.
- Sample email alex@example.com, proposed sending/sent/pending labels, and wireframe component appearance.
- The reference page’s state switch, captions, and notes are inspection tools rather than product controls.

## Fidelity

- Structural wireframe based on the supplied unstyled src/members.html; final styling and components are approximate.
- This is a visual sequence, not a functioning invitation system. Send and Retry do not submit data.
- Layout and behavior have static markup checks only; no browser rendering or screenshots were available.

## Rejected options

- Initial A (form on Members) and initial B (navigate to Invitations): rejected together; chooser required an immediately visible full-width form with Work email above Send invitation.
- Revised A (failure below Work email): not selected; chooser explicitly selected revised B below Send invitation. No further rejection reason was supplied.
