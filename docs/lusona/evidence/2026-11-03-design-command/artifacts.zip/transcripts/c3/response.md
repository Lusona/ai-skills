```mermaid
stateDiagram-v2
    [*] --> Created
    Created --> Accepted: Accepted before expiry
    Created --> Expired: Expiry reached
    Expired --> Rejected
    Accepted --> [*]
    Rejected --> [*]
```

- Status: complete.
- Outcome: One invitation lifecycle diagram; no files saved.
- Verification: Source checked against the supplied lifecycle. Rendering not tested.
- Remaining work and concerns: none.
- Recovery: Result retained in this reply; no active operations. Next action: none for this request.
- Correction rounds: none.
