# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| [Correct README spelling](specs/20261030-correct-readme.md) | Ready | AC1: spelling corrected; every other byte preserved | Await user authorization to implement the saved plan |

## Icebox

| Item / change | State when parked | Completion condition | Parking reason / revisit condition |
| --- | --- | --- | --- |

No parked work.
