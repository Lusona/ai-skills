# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| [Rename Submit button](specs/20261030-rename-submit-button.md) | Ideas | Selected label displayed; form behavior unchanged | New label undecided; user to select label and accept definition |

## Icebox

| Item / change | State when parked | Completion condition | Parking reason / revisit condition |
| --- | --- | --- | --- |

No parked work.
