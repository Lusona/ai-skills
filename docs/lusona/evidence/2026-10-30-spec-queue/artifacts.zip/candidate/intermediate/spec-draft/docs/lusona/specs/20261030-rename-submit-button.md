# Spec 20261030-rename-submit-button: Rename Submit button

Created: 2026-10-30
Updated: 2026-10-30

Kind: other
Work item: [Queue](../work.md)

## Agreement

- User and problem: The requester wants a different label for the form's Submit button.
- Desired behavior: Replace Submit with a user-selected label; the label is undecided.
- Scope: Only the button label. Excludes changes to form behavior, validation, submission, and other controls.
- Constraints: Preserve all existing form behavior, per user request.
- Completion condition: The selected label is displayed and all form behavior remains unchanged.

### Acceptance criteria

- [ ] AC1: The form's Submit button displays the new label selected by the user (pending decision).
- [ ] AC2: Form behavior is unchanged, including validation and submission.

### Decisions and uncertainty

- User requested a saved draft and explicitly left the new label undecided.
- Blocking definition question: Which new label should replace Submit? Leave open until user supplies it.
- Scope and criteria remain a draft pending acceptance.

### TDD policy

- Level: none
- Selected by user: Initial request, “TDD none.”
- Required verification on later implementation: Inspect the label change and verify existing form behavior; no implementation or tests are authorized now.

## Evidence

- Inline definition check: Criteria are consistent with label-only scope; the only missing decision is the new label.
- No implementation performed or runtime checks run.

## Current handoff

- Authorized work: Save a draft definition, leave label decision open, stop before implementation.
- Completed: Draft saved; queue tracks Ideas. Remaining: New label and accepted definition.
- Next action: User supplies label and accepts scope/criteria; then update this same definition. No implementation authorized.
