# Spec 20261030-correct-readme: Correct README spelling

Created: 2026-10-30
Updated: 2026-10-30

## Agreement

Accepted scope and AC1: change `dependancies` to `dependencies` in README.md; preserve all
other content. User selected TDD `none`. Definition is accepted. Implementation is not yet
authorized; the current request is planning only. No blocking definition questions.

## Execution

Proposed approach: Replace the single occurrence of `dependancies` with `dependencies` in README.md, preserving every other byte. No dependencies or design decisions are needed. TDD none is confirmed by the planning request.

Verification after implementation: Compare README.md bytes against the pre-edit bytes with exactly that replacement; inspect the diff for a one-word change. Expected outcome: no other bytes differ and the misspelling is absent. These execution checks are planned, not run.

## Evidence

Read-only inspection found one occurrence in “Install dependancies before running.” README.md was not modified. Inline plan check found no scope contradictions or missing decisions.

## Current handoff

- Authorized work: Planning only; no implementation or commits authorized.
- Completed: Plan saved in this existing record; missing queue row reconciled as Ready.
- Remaining: Implementation and its verification await user authorization.
- Next action: User authorizes the exact README spelling correction; then implement and compare bytes under AC1.
