# Spec 20261030-rename-submit-button: Rename Submit button

Created: 2026-10-30
Updated: 2026-10-30

Kind: other
Work item: [Queue](../work.md)

## Agreement

- User and problem: The requester wants a different label for the form's Submit button.
- Desired behavior: Replace Submit with Save.
- Scope: Only the button label. Excludes changes to form behavior, validation, submission, and other controls.
- Constraints: Preserve all existing form behavior, per user request.
- Completion condition: Save is displayed and all form behavior remains unchanged.

### Acceptance criteria

- [ ] AC1: The form's Submit button displays Save.
- [ ] AC2: Form behavior is unchanged, including validation and submission.

### Decisions and uncertainty

- User selected Save and accepted the scope and criteria in the follow-up request.
- No unresolved definition questions.

### TDD policy

- Level: none
- Selected by user: Initial request, “TDD none,” confirmed in follow-up.
- Required verification on later implementation: Inspect the label change and verify existing form behavior; no implementation or tests are authorized now.

## Evidence

- Inline definition check: Criteria are consistent with label-only scope; Save resolves the open label decision.
- No implementation performed or runtime checks run.

## Current handoff

- Authorized work: Update the same definition using Save and accepted scope/criteria; do not implement.
- Completed: Accepted definition saved; queue tracks Ready. No work remains for this definition-only request.
- Next action: None for this request. Later implementation requires user authorization.
