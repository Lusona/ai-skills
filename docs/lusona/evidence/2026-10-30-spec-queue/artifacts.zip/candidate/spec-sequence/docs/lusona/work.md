# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| [Rename Submit button](specs/20261030-rename-submit-button.md) | Ready | Save displayed; form behavior unchanged | Await implementation authorization |

## Icebox

| Item / change | State when parked | Completion condition | Parking reason / revisit condition |
| --- | --- | --- | --- |

No parked work.
