from pathlib import Path
import subprocess,json,shutil
cli='/home/jg/.local/share/mise/installs/antigravity-cli/1.4.12/antigravity'
project=Path.cwd();config=Path('/home/jg/.gemini');installed=config/'config/plugins/lusona'
original_records={str(p.relative_to(project/'docs')):p.read_bytes() for p in (project/'docs').rglob('*') if p.is_file()}
unrelated=config/'config/unrelated-verification.txt';unrelated.write_text('preserve unrelated settings\n')
def run(*args):
 r=subprocess.run([cli,'plugin',*args],capture_output=True,text=True,stdin=subprocess.DEVNULL,timeout=30)
 print('COMMAND:',*args,'\nEXIT:',r.returncode,'\n',r.stdout,r.stderr,flush=True)
 assert r.returncode==0,args
 return r.stdout
listed=json.loads(run('list','--json'))
lusona=[p for p in listed if p.get('name')=='lusona'];assert len(lusona)==1,lusona
assert len(list((installed/'skills').glob('*/SKILL.md')))==13
assert original_records=={str(p.relative_to(project/'docs')):p.read_bytes() for p in (project/'docs').rglob('*') if p.is_file()}
# Exercise shipped helper in consuming fixture; this is not model-driven skill invocation.
r=subprocess.run(['bash',str(installed/'scripts/work-record.sh'),'init-change',str(project),'native-helper-smoke','2026-10-31'],capture_output=True,text=True)
print('HELPER:',r.returncode,r.stdout,r.stderr,flush=True);assert r.returncode==0
records={str(p.relative_to(project/'docs')):p.read_bytes() for p in (project/'docs').rglob('*') if p.is_file()}
updated=project/'update-source';shutil.copytree(installed,updated)
p=updated/'.antigravity-plugin/plugin.json';m=json.loads(p.read_text());m['version']='1.3.3';p.write_text(json.dumps(m,indent=2)+'\n')
run('install',str(updated))
assert json.loads((installed/'.antigravity-plugin/plugin.json').read_text())['version']=='1.3.3'
run('uninstall','lusona')
assert not installed.exists()
assert not [p for p in json.loads(run('list','--json')) if p.get('name')=='lusona']
assert records=={str(p.relative_to(project/'docs')):p.read_bytes() for p in (project/'docs').rglob('*') if p.is_file()}
assert unrelated.read_text()=='preserve unrelated settings\n'
print('PASS: install discovery, shipped helper, reinstall update, uninstall, record/config preservation.',flush=True)
