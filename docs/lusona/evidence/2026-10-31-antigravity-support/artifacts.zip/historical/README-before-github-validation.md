# Antigravity support verification

Scope: native metadata, package integrity and documentation for App, CLI and standalone IDE.
User explicitly selected all surfaces and targeted TDD. Implementation worker
`/root/plan_antigravity` wrote tests before metadata/package edits; parent retained its red log.
Documentation worker `/root/antigravity_docs` owned installation guidance and five READMEs.

## Targeted red/green

`python3 scripts/test_package.py` initially failed four tests: canonical metadata absent,
metadata omitted from package, mismatched Antigravity name accepted, mismatched version accepted.
After implementation the same four tests passed. Coverage checks complete resource bytes and
ZIP contents, existing metadata/catalog preservation, identity/display name/version alignment,
and project/scratch-data exclusion. Red failures precede production edits; subsequent display
name assertion supplements the original coverage. No model behavior change is claimed.

[artifacts.zip](artifacts.zip) retains red/green output, baseline revision, candidate hashes,
the exact lifecycle test, its output, and the project-local listing observation.

## Native validation and lifecycle

Antigravity CLI 1.4.12 on Linux: canonical and packaged plugin strict validation passed,
13 skills and no findings. The host binary was resolved from the existing mise installation;
mise alias/shim setup encountered unavailable network/read-only shim paths, no tools installed.

Lifecycle scope was declared by `lifecycle-test.py` before running: native listing, bundled
helper execution, reinstall from an updated fixture, uninstall, and byte comparison of project
records plus an unrelated configuration sentinel. Commands ran with bwrap, all namespaces
unshared, network disabled, host filesystem read-only, real `~/.gemini` masked by repo-local
scratch configuration, and only the disposable project/configuration writable. Initial nested
sandbox setup failed creating a netlink socket; authorized escalated execution of the same
isolating wrapper succeeded. No real host configuration was modified.

Observed: source install registered all 13 skills; native list reported enabled Lusona 1.3.2.
The shipped Bash helper created a spec in the consuming fixture. Reinstall with synthetic fixture
version 1.3.3 replaced the installation; uninstall removed it. Existing project records and
unrelated config sentinel remained unchanged. Synthetic version was never written to canonical
metadata. Installation itself did not create consuming-project records.

Earlier project-local `plugin list --json` returned an empty list despite a manually placed
plugin folder. This check does not establish workspace discovery; documented App/IDE
Customizations checks remain unrun. No inference was made that native list inventories every
project-local component.

## Other verification and limitations

Before review, four package tests, portable build and link checks, native Antigravity strict validation
of source and packaged plugin, and whitespace checks passed. Docs worker checked 295 relative
links/fragments. Pre-review package: `tmp/antigravity-final-package/lusona-1.3.2.zip` (superseded by correction 1).

No model-driven status/specify invocation, App/IDE installation/UI, or Windows/PowerShell
execution was tested. Documentation distinguishes supported formats/instructions from these
unverified runtime behaviors. Before the review correction, source installation lifecycle was exercised and the packaged
plugin was strict-validated/byte-checked only. The later captured repeat below also exercised
packaged-plugin installation through the CLI; no live UI installation was performed. No new version,
commit, push, installation in real user configuration, or publication occurred.

Independent review `/root/review_antigravity` found a low-severity packaging omission:
CONTRIBUTING described the new package test runner but the package omitted it. Correction round 1
added a test, observed its expected failure, then packaged the runner. All five tests now pass
both in the repository and from an extracted ZIP. Correction evidence is retained under
`correction1/` in the archive. Final package is `tmp/antigravity-package-correction1/lusona-1.3.2.zip`.

Review also requested complete initial-install and isolation evidence. A separate capture run
retains the exact bwrap wrapper, strict-validation output, initial install and full lifecycle in
`captured-lifecycle/`. Its first attempt stopped before installation because the scratch config
parent was missing. That failure is retained; adding directory initialization allowed the second
attempt to pass. The repeat installs the extracted packaged plugin. Original evidence is unchanged.
No model-driven invocation is implied by these commands. Existing Claude plugin and marketplace
validation also passed.

Remaining completion gaps under AC2: App and standalone IDE installation/discovery, and
model-driven status/specify/shared-core loading. Keep the work item in Review, not Done.
Parent owns spec/queue; implementation and documentation are uncommitted.

Final focused review by `/root/review_antigravity` confirmed the packaged-runner correction
and complete captured lifecycle evidence; no further implementation defect found. Historical
verification paragraphs were clarified to distinguish initial checks from the subsequent
package-install repeat. App/IDE discovery and model invocation remain outstanding AC2 checks.
Correction counts: one implementation correction with material progress (no consecutive
unproductive rounds); one evidence-capture setup repair with material progress. No active
operations or children reported by workers; host has no explicit termination control.

## Root reference correction

User requested a root Antigravity reference. Added `.antigravity-plugin/plugin.json`
with explicit `./plugins/lusona/skills` discovery and root-relative logo. Name/version
alignment and portable inclusion are tested. Eight tests pass in source and extracted
package after targeted red. Packaged root strict validation finds 13 skills and no findings.
Checkout root normal validation passes with an existing AGENTS.md warning; strict validation
treats that warning as failure. Nested plugin remains the recommended install target to avoid
copying repository project records. Custom marketplace-only metadata is not recognized by
CLI 1.4.12; no unsupported marketplace catalog was added. Logs retained in artifacts.zip.
Final rebuilt package: tmp/antigravity-root-final/lusona-1.3.2.zip.
