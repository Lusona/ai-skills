from pathlib import Path
import subprocess, json, os
root=Path('/home/jg/code/_lusona_/ai-skills/tmp/antigravity-github-verification')
cli='/home/jg/.local/share/mise/installs/antigravity-cli/1.4.12/antigravity'
def run(label,*args):
 result=subprocess.run([cli,'plugin',*args],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=70)
 text='COMMAND: '+repr([cli,'plugin',*args])+'\nEXIT: '+str(result.returncode)+'\n'+result.stdout
 print(text,flush=True); (root/'project'/f'{label}.txt').write_text(text)
 return result
run('github-dot-git','install','https://github.com/lusona/ai-skills.git')
run('dot-git-list','list','--json')
