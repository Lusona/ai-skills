from pathlib import Path
import subprocess, json, hashlib, re
root=Path('/home/jg/code/_lusona_/ai-skills/tmp/antigravity-github-verification')
cli='/home/jg/.local/share/mise/installs/antigravity-cli/1.4.12/antigravity'
installed=Path('/home/jg/.gemini/config/plugins/lusona')
def capture(label,args):
 r=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=70)
 output='COMMAND: '+repr(args)+'\nEXIT: '+str(r.returncode)+'\n'+r.stdout
 (root/'project'/f'{label}.txt').write_text(output);print(output,flush=True)
 assert r.returncode==0
 return r.stdout
capture('public-head',['git','ls-remote','https://github.com/Lusona/ai-skills.git','HEAD','refs/heads/main'])
capture('github-root-confirmed',[cli,'plugin','install','https://github.com/Lusona/ai-skills'])
listing=capture('root-list-confirmed',[cli,'plugin','list','--json'])
files=sorted(p for p in installed.rglob('*') if p.is_file())
inventory='\n'.join(str(p.relative_to(installed)) for p in files)+'\n'
(root/'project/installed-root-inventory.txt').write_text(inventory)
summary={'file_count':len(files),'skills':len(list((installed/'skills').glob('*/SKILL.md'))),'resources':{x:len([p for p in (installed/x).rglob('*') if p.is_file()]) for x in ['references','templates','scripts','assets']},'docs_lusona_present':(installed/'docs/lusona').exists(),'docs_present':(installed/'docs').exists(),'native_manifest_present':(installed/'.antigravity-plugin/plugin.json').exists(),'generated_manifest':json.loads((installed/'plugin.json').read_text()),'claude_manifest':json.loads((installed/'.claude-plugin/plugin.json').read_text()),'sha256':{str(p.relative_to(installed)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(root/'project/installed-root-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert len(json.loads(listing)[0]['skills'])==13
assert not summary['docs_present']
assert summary['resources']=={'references':19,'templates':13,'scripts':2,'assets':1}
assert inventory==(root/'installed-tree-inventory.txt').read_text()
print('PASS: root and tree install same inventory; 13 skills and required resources; no docs directory.',flush=True)
