# Antigravity GitHub installation verification — 2026-10-31

Native CLI: `/home/jg/.local/share/mise/installs/antigravity-cli/1.4.12/antigravity`.
Public source observed: `https://github.com/Lusona/ai-skills`, HEAD/main
`7a339789dab09ec4b5a43ef7d48df9ce9522c529`.

Both commands succeeded with exit 0:

```sh
antigravity plugin install https://github.com/Lusona/ai-skills
antigravity plugin install https://github.com/Lusona/ai-skills/tree/main/plugins/lusona
```

The root command reported `Found bulk plugins directory: .../plugins` and installed
Lusona from that directory. The tree command cloned the repository and directly
installed the selected plugin subdirectory (no bulk-discovery message).

Both resulting inventories match: 55 files; 13 skills; 19 reference files;
13 templates; 2 scripts; 1 asset. Neither installed a `docs` directory or
`docs/lusona` project records. All canonical plugin resources are retained.
The public source installed as enabled version `1.3.2`, source `claude-code`;
Antigravity generated `plugin.json` from its Claude compatibility manifest.
No `.antigravity-plugin/plugin.json` was present in this installed public source.
This does not test publication of the uncommitted native 1.4.0 manifests.

`project/github-root.txt` and `project/github-tree.txt` retain initial successful
public install logs; respective `*-list.txt` files retain discovery details.
`project/github-root-confirmed.txt` and `project/root-list-confirmed.txt` retain a
second root install used to snapshot root content after the tree install.
`project/public-head.txt` records public Git SHA; `installed-tree-inventory.txt`
and `project/installed-root-inventory.txt` are equal.
`project/installed-root-summary.json` records manifests, counts, and every
installed file's SHA-256.

Isolation: `run.sh` / `root-snapshot.sh` run under bubblewrap, bind `/` read-only,
mask real `/home/jg/.gemini` with this scratch `config/`, and permit writes only
to disposable config/project directories. HOME and git config are controlled;
no host credentials are used. TMPDIR points inside this repository scratch.
No production source/configuration or project records were changed. No commit,
push, publication, model-driven skill invocation, App UI, or IDE was tested.

Initial non-escalated network execution failed DNS resolution for github.com;
no installs occurred and list returned `[]`. The same harness succeeded after
network escalation. One diagnostic correction round established the network
restriction as the cause and verified both installs: consecutive no-progress 0,
total 1. No unresolved installation failures remain within this assignment.

Official documentation corroborates repository URL support:
<https://antigravity.google/docs/plugins/#cli-shell-subcommands-agy-plugin>.
The tree URL syntax is observed CLI behavior; the public documentation example
uses the repository-root URL.

Follow-up provenance check: all 54 canonical files under `plugins/lusona/` at
public revision `7a339789dab09ec4b5a43ef7d48df9ce9522c529` match installed SHA-256 hashes.
The only extra installed file is Antigravity-generated root `plugin.json`.
See `public-source-comparison.json`. Initial DNS failure output was recovered
from the original tool result into `initial-dns-failure-transcript.txt`; its
provenance explicitly distinguishes transcription from original on-disk logs.
No commands were rerun to recreate that failure.
