#!/usr/bin/env bash
set -euo pipefail
case_root=/home/jg/code/_lusona_/ai-skills/tmp/antigravity-github-verification
exec bwrap --die-with-parent --unshare-all --share-net --ro-bind / / \
 --bind "$case_root/config" /home/jg/.gemini \
 --bind "$case_root/project" "$case_root/project" \
 --dev /dev --proc /proc --chdir "$case_root/project" \
 --clearenv --setenv HOME /home/jg --setenv PATH /usr/bin:/bin \
 --setenv TMPDIR "$case_root/project/tmp" \
 --setenv GIT_CONFIG_NOSYSTEM 1 --setenv GIT_CONFIG_GLOBAL /dev/null \
 --setenv GIT_TERMINAL_PROMPT 0 \
 /usr/bin/python3 "$case_root/probe.py"
