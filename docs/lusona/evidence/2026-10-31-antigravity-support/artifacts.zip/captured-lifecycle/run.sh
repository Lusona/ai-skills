#!/usr/bin/env bash
set -euo pipefail
project_root=/home/jg/code/_lusona_/ai-skills
case_root="$project_root/tmp/antigravity-runtime/captured"
exec bwrap --die-with-parent --unshare-all --ro-bind / / \
  --bind "$case_root/config" /home/jg/.gemini \
  --bind "$case_root/project" "$case_root/project" \
  --dev /dev --proc /proc --chdir "$case_root/project" \
  /usr/bin/python3 "$case_root/lifecycle.py"
