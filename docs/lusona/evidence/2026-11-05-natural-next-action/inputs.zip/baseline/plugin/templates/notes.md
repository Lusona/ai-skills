# Notes: {{slug}}

Context: <work item or bounded question; link an existing owning record when available>

Save substantive understanding, alternatives, decisions, open questions, or findings without
an existing owner. Notes are the owner for direct implement or refactor work without a spec
and for investigations, measurements, and experiments: retain agreement, decisions, explicit
TDD/source, checks/evidence, and in-session handoffs here without queue tracking. A spec is
required when [retention](../references/retention.md) says so; size and scope do not decide this. Creating a spec requires tracking; existing
tracked work remains tracked.
Use one dated section per
distinct question; update it as evidence changes instead of appending a session diary.
For material measurements and experiments, link exact saved runs;
keep discussion and decisions here.
Omit unused fields. Replace a finding with a link if another document becomes its owner.

## YYYY-MM-DD — <question or finding>

### Question and scope

- Question: <what this investigation or measurement needs to establish>
- Scope: <relevant system, inputs, revision, and constraints>

### Evidence

- Method: <reproduction steps, command, or source; enough to repeat the check>
- Result: <observed facts and evidence references; distinguish reported from verified>
- Limitations: <unmeasured cases or unavailable evidence>

### Conclusion and decisions

- Conclusion: <supported finding; distinguish hypotheses from confirmed causes>
- Decision: <accepted decision and source, proposal, or deferred with reason; when applicable>
- Corrections: <refuted or superseded claims and supporting evidence; when applicable>

## Current handoff

Use only when this record owns the handoff; otherwise link the existing one.
Replace it as work progresses. Do not duplicate evidence or queue state here.

- Authorized work: <outcome, scope and source; TDD and source when applicable; findings alone do not authorize a fix>
- Open questions or blockers:
- Ownership: <current owner when needed for recovery>
- Correction rounds: <failure, consecutive and total counts, last material progress; omit when none>
- Next action: <owner, bounded action, and required inputs>
