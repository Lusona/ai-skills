# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [x] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [x] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Accepted decisions and source: layout option B chosen by the user, 2026-10-28; visual reference [account-settings](../visuals/20261028-account-settings/reference.md).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Verification evidence

Method: markup inspection only (repository rule; no browser or screenshot tool). Script syntax
parsed with `new Function` in node; behavior not executed in a browser.

- AC1 met in markup: Profile (display name, email inputs), Notifications (email digest checkbox),
  Security (Change password link) in `src/settings.html`.
- AC2 met in code: Save has `disabled`; `input`/`change` handlers compare every named field with
  its initial value and set `disabled` accordingly.
- Visual reference binding items: B1 met (fixed 200 px `nav` plus `main`); B2 met (order Profile,
  Notifications, Security); B3 met (hash-driven `show()` hides other sections); B4 met by markup
  (Save absolutely positioned bottom-right of `main`). Visual comparison unrun; human visual
  acceptance required.

## Current handoff

- Implemented `src/settings.html`; not committed (repository rule).
- Next action: human visual and interaction acceptance. Change password link targets
  `#change-password` (placeholder, no backend).
