**Result** ✅ Complete (implementation). I wrote `src/settings.html` and updated the spec with evidence. I did not open it in a browser, so human acceptance is still required. I did not commit, because AGENTS.md forbids it.

- **AC1:** The page has Profile (display name, email), Notifications (email digest checkbox) and Security (Change password link).
- **AC2:** Save starts disabled. It enables when any field differs from its initial value and disables again after a save or when the value is reverted.
- **Visual reference, binding items:**
  - B1 met: a fixed 200 px left nav and a main panel to its right.
  - B2 met: nav order is Profile, Notifications, Security.
  - B3 met: only the selected section shows, switched by the URL hash; an unknown hash falls back to Profile.
  - B4 met in the markup: Save is positioned at the bottom-right of the main panel.
  - Illustrative items (colors, copy, spacing) are not acceptance and were only roughly followed from `layout.html`.

**Evidence**
- Method: markup inspection, as AGENTS.md requires. TDD policy is `none`.
- The inline script parses in node. I did not run it in a browser.
- I did not compare the page visually against `layout.html`.
- I ticked AC1 and AC2 in the spec, added a "Verification evidence" section and replaced the handoff there.
- I did not create a queue row for this small change.

**Next action**
- Open `src/settings.html` in a browser and check: typing enables Save; Notifications shows only the digest checkbox; Security shows the Change password link; Save sits bottom-right.
- Change password link is a placeholder `#change-password`.
- Record your acceptance if the page looks right.
