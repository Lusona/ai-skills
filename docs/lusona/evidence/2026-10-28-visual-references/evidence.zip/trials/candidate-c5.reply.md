None of A/B/C are kept. I wrote three revised wizard options (one section per step, Back and Next buttons). Choose one by letter, or ask for another revision.

Nothing is saved to `docs/lusona/` yet. Per the visuals rules, a rejected set means no spec or visual-reference changes. I wrote only these draft files, and I did not open them in a browser or test them. Open them from these paths:

- **A** (`.../candidate-c5/tmp/options/revised-a.html`): a stepper across the top (1 Profile, 2 Notifications, 3 Security), then the current step's panel, with Back and Next below it.
- **B** (`.../candidate-c5/tmp/options/revised-b.html`): a "Step N of 3" text line and the current step's panel, with Back and Next below it. This is the most minimal option.
- **C** (`.../candidate-c5/tmp/options/revised-c.html`): a vertical step list on the left and the current step's panel on the right, with Back and Next below the panel.

In all three, Back is disabled on step 1 and Next becomes Save on step 3.

Two questions to answer with your pick, since both change the spec:
1. **AC2 (Save disabled until a field changes):** should Save appear only on the last step, as in the mockups? It would stay disabled until any field across all steps has changed. The alternative is a Save on every step.
2. **AC1:** should Next stay enabled on every step with no validation? The mockups assume no validation.

After you choose, I will update the spec (wizard behavior and the AC1 and AC2 wording). I will also ask whether to retain the chosen mockup under `docs/lusona/visuals/20261028-account-settings/`, and I still need the TDD level confirmed (currently `none`, from your request).
