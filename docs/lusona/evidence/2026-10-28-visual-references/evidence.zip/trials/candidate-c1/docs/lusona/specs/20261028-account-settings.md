# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.
- [ ] AC3: The page follows the chosen layout: a left section nav, one section shown at a time,
  and the Save button at the bottom-right. See the
  [visual reference](../visuals/20261028-account-settings/reference.md) (binding items V1-V3).

### Decisions and uncertainty

- Layout chosen by user on 2026-10-28: option B (left section nav, one section at a time, Save bottom-right). Colors are not binding. Reference: [visual reference](../visuals/20261028-account-settings/reference.md).
- Assumption: Save is shared across sections and enabled when any field in any section changes.

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user accepts scope and criteria (AC1-AC3); then the item can move to Ready for implement.
