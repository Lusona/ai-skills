# Visual reference: 20261028-account-settings

- Chosen option: B, section nav + panel, chosen by user on 2026-10-28
- Visual: [option-b.html](option-b.html)
- Owner: [20261028-account-settings spec](../../specs/20261028-account-settings.md)

## Binding

- V1: A left-side navigation lists the sections Profile, Notifications, and Security.
- V2: Only one section is visible at a time; selecting a nav item swaps the panel to that section.
- V3: The Save button is at the bottom-right of the content panel.

## Illustrative

- Colors (user: "Colors don't matter").
- Copy, spacing, nav width, and fonts.
- The mockup shows only the Profile panel; the Notifications and Security panels are not drawn.

## Rejected options

- A: single long page; too long.
- C: tabs; hides the sections behind tabs.
