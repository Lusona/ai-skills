# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| 20261028-account-settings | Ideas | Settings page meets AC1-AC3; human visual acceptance required | User accepts scope and criteria, then move to Ready |

## Icebox

No parked work.
