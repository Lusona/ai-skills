**Result** (❓ Needs input, one question below)

Use TOML, unless your config needs deep nesting or you must match a YAML ecosystem. For a small config that people edit by hand, TOML fails in fewer ways.

| Option | Benefit for hand editing | Tradeoff |
| --- | --- | --- |
| TOML | Values have explicit types: strings are quoted, so a typo is a parse error. Indentation has no meaning. It supports comments. | Deeply nested data is verbose (`[a.b.c]` tables, `[[array]]` of tables). Less familiar to people who only know CI or Kubernetes files. |
| YAML | Compact for nested data and long lists. Most developers have seen it. It supports comments. | The parser guesses types. In YAML 1.1, `no`, `off`, and `y` can parse as booleans, and `1.10` parses as the number 1.1. A wrong indent can change the structure without any error. Several versions and parser behaviors exist. |
| Keep the current format, if you have one | No migration. | I do not know your current format. |

**Evidence**
- These points come from my knowledge of the two formats. I did not run anything or look anything up. There is no web access here.
- The project directory is a static web prototype with no CLI code or config file, so I found nothing there to base this on.
- The YAML 1.1 boolean and `1.10` behaviors depend on the parser and version. Check the one you would use.
- Library support is language-specific and I have not checked it. Tell me your language and I will say what each format needs.

**Next action**
- Question for you: how deep and how large is the config? If it is mostly flat settings with a few sections (about 20 keys, 2 levels deep or less), TOML is a clear fit. If it holds long lists of nested objects, such as pipelines or per-target rules, TOML gets awkward and YAML becomes a closer call.
- Optional after that: if users may add many entries over time, I can sketch the same example config in both formats so you can compare how they read.
