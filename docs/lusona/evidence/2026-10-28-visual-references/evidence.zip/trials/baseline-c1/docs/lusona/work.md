# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| 20261028-account-settings | Ideas | `src/settings.html` meets AC1 to AC4 of the spec; no human acceptance required unless user says so | User accepts criteria and assumptions, then authorizes implementation |

## Icebox

No parked work.
