# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend. Colors and other
  visual styling are not specified (user: "Colors don't matter").
- Accepted constraints and invariants: layout is option B, a left section nav showing one section
  at a time, with the Save button at the bottom-right (user choice, 2026-10-28). Rejected: A
  (single long column) as too long, C (top tabs) as hiding the sections behind tabs.

### Acceptance criteria

- [ ] AC1: The page offers Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections, each reachable from the left nav.
- [ ] AC2: A Save button is disabled until a field changes.
- [ ] AC3: A left-hand nav lists Profile, Notifications, and Security. Only the selected
  section's content is shown at one time; selecting a nav item swaps the content. Profile is
  shown on first load.
- [ ] AC4: The Save button is at the bottom-right of the content area.

### Decisions and uncertainty

- Accepted decisions and source: layout B per user reply, 2026-10-28. Visual reference:
  `tmp/options/b.html` (a throwaway mock; only the layout structure in AC3 and AC4 is binding,
  not its colors, widths, or markup). Options `a.html` and `c.html` are rejected references.
- Assumptions (not yet confirmed by user): one page-level Save covers all sections, so an edit
  made in one section stays pending when switching sections and enables Save; Save has no
  persistence because there is no backend; the nav marks the selected section.
- Unresolved questions: none that block definition. Confirm the assumptions above.

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only (no implementation; TDD level `none` is selected).
- Completed and remaining work: layout chosen and recorded (AC3, AC4). Remaining: user accepts
  scope and criteria AC1 to AC4 and the assumptions above.
- Next action: user (a) accepts or corrects the criteria and assumptions, and (b) authorizes
  implementation of `src/settings.html`. Then the coordinator moves the queue item to Ready.
