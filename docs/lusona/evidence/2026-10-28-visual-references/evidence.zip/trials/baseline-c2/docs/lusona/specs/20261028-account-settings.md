# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [x] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [x] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Accepted decisions and source: layout option B chosen by the user, 2026-10-28; visual reference [account-settings](../visuals/20261028-account-settings/reference.md).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Evidence

- Verified by markup inspection only (repository rule; TDD none; page not opened in a browser).
- AC1: `src/settings.html` has Profile (display name, email), Notifications (email digest checkbox), Security (change password link `#change-password`, placeholder target) sections.
- AC2: Save is `disabled` in markup; script compares each field to its initial value and enables Save only on a difference.
- Visual binding B1-B4: fixed 200px left nav and main panel; nav order Profile, Notifications, Security; only the selected section is shown (hash-driven, default Profile); Save is absolutely positioned bottom-right of the main panel.
- Limitations: Save does nothing on submit (no backend). Change password link has no destination. Human acceptance not given.

## Current handoff

- Authorized work: implementation of AC1-AC2 requested by the user, 2026-10-28; done.
- Next action: user opens `src/settings.html`, clicks each nav item, edits a field and confirms Save enables; reverting it disables Save again.
