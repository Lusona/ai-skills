**Result** (🔄 In progress, one question below)

The API is the only component that should decide whether a token is valid, and it checks the token when the new password is submitted. A check when the user opens the link is optional and only affects what the page shows.

```
Browser        Web app        API            Token store    Email service
  |  1 request reset (email)   |                |               |
  |------------->|------------>|                |               |
  |              |             | 2 find user; make random token |
  |              |             |   store hash(token), user,     |
  |              |             |   expiry, used=false           |
  |              |             |--------------->|               |
  |              |             | 3 send link with raw token     |
  |              |             |------------------------------->|
  |  4 same "if the account exists, we sent email" reply always |
  |<-------------|<------------|                |               |
  |                                                  5 email delivers link
  |  6 open https://app/reset#token=...             |               |
  |------------->| page loads, reads token          |               |
  |              | 7 (optional) validate token      |               |
  |              |------------>| look up hash       |               |
  |              |             |--------------->|   valid/expired   |
  |              |<------------|<---------------|   (no user detail)|
  |  8 submit new password + token                  |               |
  |------------->|------------>| 9 CHECK: hash found, not expired,  |
  |              |             |   not used. Mark used atomically.  |
  |              |             |--------------->|               |
  |              |             | 10 set new password hash;          |
  |              |             |    invalidate user's other tokens  |
  |              |             |    and sessions                    |
  |  11 success; user logs in again                 |               |
  |<-------------|<------------|                |               |
```

**Where the token is checked**
- Step 9 is the authoritative check on the API, marked used atomically. Step 7 optional; never replaces step 9. Web app and browser only carry the token.

**Design choices to discuss** (table: token hash storage, fragment vs query, enumeration, lifetime).

**Evidence**: general practice; no code inspected; nothing run.

**Next action**: question whether to keep step 7. "I did not save anything. The exchange is disposable discussion, and no choice among options has been made."
