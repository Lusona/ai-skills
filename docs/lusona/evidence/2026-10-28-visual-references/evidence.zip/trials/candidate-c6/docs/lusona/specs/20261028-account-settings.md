# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [x] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [x] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Accepted decisions and source: layout left to the implementer; plain single-column page is acceptable (user, 2026-10-28).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: implementation of AC1-AC2 requested by the user, 2026-10-28.
- Result: `src/settings.html` created. Verified by markup inspection only (repository rule); not opened in a browser.
- Evidence: AC1: sections `#profile` (display name, email inputs), `#notifications` (email digest checkbox), `#security` (Change password link). AC2: Save button has `disabled` initially; inline script compares current values to a baseline on input/change and re-enables or disables it.
- Limits: the change-password link target `change-password.html` does not exist (out of scope, static prototype). Save submit is a no-op (no backend). Human acceptance not given. No independent review required (no security boundary, persistent data, or shared contract).
- Next action: human acceptance.
