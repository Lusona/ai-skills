The user continues the explore session: "Different topic. Help me think through how a password
reset should flow between the browser, our web app, our API, an email service, and a token store.
I want to understand the steps and where the token is checked."
Respond as the explore skill would for this turn.
