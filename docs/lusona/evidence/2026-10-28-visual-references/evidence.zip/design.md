# Trial design: visual options and retained references

Frozen 2026-10-28 before canonical edits. Owner: docs/lusona/specs/20261028-visual-options-and-references.md

- TDD: targeted (user, 2026-10-28). Test-first: TF-a = AC2 retention (case C1); TF-b = AC6
  binding acceptance in implement (case C2). Baseline = unchanged canonical plugin at commit
  6bcd4b0 (snapshots/baseline, hashes in snapshots/baseline.sha256). Candidate = canonical
  plugin after edits, snapshotted to snapshots/candidate before candidate trials.
- Regression (candidate-only, low-risk noncomparative): C3 explore diagrams (AC4, AC5),
  C4 review against reference without screenshots (AC7), C5 rejection (AC3, AC1),
  C6 implement without reference (AC8).
- Coverage rationale: one case per new producer/consumer behavior; positive and negative
  (textual-only, rejection, no-reference) boundaries. Not every skill or host is exercised.
- Conditions: Claude Code subagents as actors, model sonnet (both arms), host default reasoning;
  each trial gets a fresh copy of its fixture under trials/<arm>-<case>/; actors receive only the
  task text, the fixture copy, and the instruction snapshot for their arm. No user is available;
  actors put any question in their final reply. Actors must not spawn subagents (local fallback
  per core), must not run browser-opening commands, and have no screenshot tool.
  C3 is two turns in one actor session (second turn sent via SendMessage).
- Budget: 8 trials (2 baseline + 6 candidate), 9 turns, one attempt each, no retries to seek
  passing results. Setup failures recorded as setup-blocked, not red.
- Grading: one independent grader agent (not the implementer or coordinator-author of edits)
  reads evaluator/criteria.md, each trial's final reply, and the resulting trial directory
  (file listing + diff against its fixture). Grades pass / fail / inconclusive / setup-blocked.
- Stop: after all declared trials and grading, or on an environment failure preventing valid trials.
- Limits: one observation per case, one host/model; actor isolation from evaluator files is by
  instruction, not OS enforcement; subagents inherit ambient host instructions.
