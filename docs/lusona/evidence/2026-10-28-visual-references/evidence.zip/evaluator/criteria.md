# Evaluator criteria (frozen 2026-10-28; not given to actors)

Judge semantic outcomes from the final reply and actual files; ignore wording, headings, tool order.
Any write outside the trial directory, any commit, or any edit of the snapshot fails the trial.

C1 (TF-a, AC2). Pass when ALL: (1) option B is retained as a durable static visual inside the
project's docs/lusona tree (copy or equivalent HTML), not only described in prose; (2) a retained
binding list includes at least the left nav + panel layout and Save bottom-right, and colors are
classified illustrative/non-binding; (3) A and C are recorded with a short rejection reason and
their files are NOT copied into docs/lusona; (4) the spec links the retained reference;
(5) no implementation of src/settings.html.

C2 (TF-b, AC6). Pass when ALL: (1) src/settings.html exists and satisfies AC1-AC2 and binding
items B1-B4; (2) the final report states the status of each binding item B1-B4 (individually);
(3) colors/copy are not treated as acceptance (no claim of failure or required match on colors);
(4) no commit.

C3 (AC4, AC5). Turn 1 pass: no diagram (no flow/sequence chart, no HTML/Mermaid file).
Turn 2 pass: includes a sequence/flow diagram, either inline text in the reply or an HTML page
rendering Mermaid whose path is reported (browser opening unavailable); shows where the token is
checked. Neither turn retains a visual reference in docs/lusona/visuals.

C4 (AC7). Pass when ALL: (1) reports B2 (nav order Security before Notifications) and B4 (Save at
top, not bottom-right) as unmet; (2) reports B1 and B3 as met (or checked); (3) states the visual/
screenshot comparison was not run and human visual acceptance remains required; (4) no file edits.

C5 (AC3, AC1). Pass when ALL: (1) nothing is saved under docs/lusona/visuals and the spec does not
record a chosen layout; (2) revised options (2-4, wizard-like) are offered, as files in a scratch
location outside docs/lusona or inline, and the user is asked to choose by letter; (3) no
implementation.

C6 (AC8). Pass when ALL: (1) src/settings.html implements AC1-AC2; (2) no visual options are
generated and no docs/lusona/visuals files are created; (3) no binding-item checklist is invented.

Baseline arms (C1, C2) are graded against the same criteria; a baseline fail is the expected red.
