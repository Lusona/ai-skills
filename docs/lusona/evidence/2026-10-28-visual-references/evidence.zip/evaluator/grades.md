# Grades and review: visual options and retained references

Grader: independent leaf (Lusona `review` responsibility), 2026-10-28. Read-only except this file.

## Status

✅ Complete. All 8 trials graded; source change reviewed. 7 trials pass. baseline-c1 fails, which is the expected red. baseline-c2 passes, so the AC6 test-first case (TF-b) produced no red. Source review found 0 blocking defects, 1 medium and 3 low.

## Outcome

### Trial grades

| Trial | Case | Grade | Key evidence |
| --- | --- | --- | --- |
| baseline-c1 | C1 (TF-a, AC2) | **fail** (expected red) | Nothing written under `docs/lusona/visuals`. The spec points to the scratch mock `tmp/options/b.html` (spec lines 31-33 in the trial), not a retained reference. |
| candidate-c1 | C1 | **pass** | `docs/lusona/visuals/20261028-account-settings/option-b.html` is byte-identical to `tmp/options/b.html`. `reference.md` has V1-V3, colors illustrative, A and C rejected. Spec lines 20-22 and 26 link it. |
| baseline-c2 | C2 (TF-b, AC6) | **pass** (expected red NOT observed) | `src/settings.html` meets AC1-AC2 and B1-B4. The reply names each binding item. B1 and B2 share one bullet but each has its own evidence. |
| candidate-c2 | C2 | **pass** | `src/settings.html` meets AC1-AC2 and B1-B4. The reply lists "B1 met" through "B4 met in the markup" individually and says "Illustrative items ... are not acceptance". |
| candidate-c3 | C3 (AC4, AC5) | **pass** | Turn 1 has a table and no diagram. Turn 2 has an inline ASCII sequence diagram with "9 CHECK: hash found, not expired, not used". No files changed. |
| candidate-c4 | C4 (AC7) | **pass** | B2 and B4 are reported **Unmet**, B1 and B3 Met by markup, and the reply says the visual comparison was not run and human visual acceptance is still required. `diff -r` against the fixture is empty. |
| candidate-c5 | C5 (AC3, AC1) | **pass** | 3 wizard options at `tmp/options/revised-{a,b,c}.html`. The reply says "Choose one by letter". Nothing in `docs/lusona`, and the spec is unchanged. |
| candidate-c6 | C6 (AC8) | **pass** | `src/settings.html` implements AC1-AC2. No `docs/lusona/visuals` directory. The reply says "No visual reference is linked, so the visual-reference rules do not apply". |

No writes outside the trial directories were found (method under Verification). No trial directory contains `.git`, so no commit was possible.

### Per-trial criterion results

#### baseline-c1 (C1): fail

1. Durable static visual inside `docs/lusona`: **fail**. `diff -r fixture/c1-retention trials/baseline-c1` shows only the spec and `work.md` changed. No visual file exists under `docs/lusona`. The spec says: "Visual reference: `tmp/options/b.html` (a throwaway mock; ...)".
2. Binding list and colors classified: **pass in substance**. The new spec AC3 and AC4 cover the left nav, one section at a time, and Save bottom-right. Scope says "Colors and other visual styling are not specified". This is in the spec, not in a retained reference list.
3. A and C recorded with a reason and not copied: **pass**. The spec says: "Rejected: A (single long column) as too long, C (top tabs) as hiding the sections behind tabs." No copies exist.
4. Spec links the retained reference: **fail**. There is no retained reference. The spec refers to the scratch path `tmp/options/b.html`.
5. No implementation: **pass**. There is no `src/settings.html`.

The baseline fails items 1 and 4. TF-a produced the expected red.

#### candidate-c1 (C1): pass

1. **Pass**. `trials/candidate-c1/docs/lusona/visuals/20261028-account-settings/option-b.html` is identical to `fixture/c1-retention/tmp/options/b.html` (`diff` reports no difference).
2. **Pass**. `reference.md` lines 9-11:
   - V1: left nav lists the sections.
   - V2: one section at a time; selecting a nav item swaps the panel.
   - V3: "The Save button is at the bottom-right of the content panel."

   Line 15 classifies colors as illustrative: "Colors (user: "Colors don't matter")".
3. **Pass**. `reference.md` lines 21-22 record A ("too long") and C ("hides the sections behind tabs"). Only `option-b.html` and `reference.md` exist in that directory.
4. **Pass**. Spec lines 20-22 (AC3) and line 26 both link `../visuals/20261028-account-settings/reference.md`.
5. **Pass**. There is no `src/` in the trial directory.

Note: the actor also added AC3 to the spec. The criteria allow this, and the actor's reply asks the user to accept AC1-AC3.

#### baseline-c2 (C2): pass (TF-b red not observed)

1. **Pass**. `trials/baseline-c2/src/settings.html`:
   - AC1: lines 27-39 contain Profile (display name, email), Notifications (digest checkbox), and Security (Change password link).
   - AC2: the button at line 40 is `disabled`, and the script at lines 59-68 enables it when a field differs from its initial value.
   - B1: `nav{width:200px;flex:none}` and `main{flex:1}` (lines 9 and 12).
   - B2: links in the order Profile, Notifications, Security (lines 21-23).
   - B3: sections are `hidden` except the selected one (lines 32, 36, and 50).
   - B4: `.save{position:absolute;right:2rem;bottom:2rem}` with `main{position:relative}`. The form has no positioning, so the button is placed relative to `main`.
2. **Pass, borderline**. The reply says "meets AC1 and AC2 and the binding items B1–B4" and then gives evidence for each item:
   - "B1 and B2: A fixed 200px left nav and a main panel, with nav order Profile, Notifications, Security."
   - "B3: Only the selected section shows."
   - "B4: Save is at the bottom-right of the main panel."

   B1 and B2 share one bullet, but each has its own distinct evidence clause, so I count each as stated.
3. **Pass**. Colors are not mentioned as acceptance.
4. **Pass**. There is no `.git` and the reply says "Nothing was committed."

Consequence: TF-b did not show a baseline failure. The fixture spec already links `reference.md`, which contains a labeled B1-B4 list, so an unchanged actor reads and reports it. The case does not separate the baseline from the candidate. AC6 evidence comes from candidate-only behavior, not from a red-to-green change.

#### candidate-c2 (C2): pass

1. **Pass**. `trials/candidate-c2/src/settings.html`:
   - AC1: lines 27-39.
   - AC2: the button at line 40 is `disabled`, and the dirty check at lines 62-73 enables it.
   - B1: lines 9 and 12.
   - B2: lines 21-23.
   - B3: line 54, `s.hidden = s.id !== id`.
   - B4: line 15, with `main` `position:relative` at line 12.
2. **Pass**. The reply has separate bullets for "B1 met", "B2 met", "B3 met", and "B4 met in the markup". The spec evidence section repeats them.
3. **Pass**. The reply says: "Illustrative items (colors, copy, spacing) are not acceptance".
4. **Pass**. The reply says: "I did not commit". There is no `.git`.

#### candidate-c3 (C3): pass

- Turn 1, **pass**. `candidate-c3.turn1.reply.md` has a comparison table and no flow or sequence diagram. No HTML or Mermaid file was written.
- Turn 2, **pass**. `candidate-c3.turn2.reply.md` has an inline ASCII sequence diagram across Browser, Web app, API, Token store, and Email service. Step "9 CHECK: hash found, not expired, not used. Mark used atomically." shows where the token is checked, and the reply says "Step 9 is the authoritative check on the API".
- Neither turn retained a reference. `diff -r fixture/c3-explore trials/candidate-c3` is empty, and the reply says "I did not save anything."
- Limit: the coordinator condensed the turn 2 table and evidence section, per `REPLY-NOTES.txt`. The diagram is verbatim.

#### candidate-c4 (C4): pass

1. **Pass**. Findings: "Nav order violates B2 (`src/settings.html:3`)" and "Save button position violates B4 (`src/settings.html:4`...)". The status table marks both **Unmet**. This matches the fixture: line 3 has the order Profile, Security, Notifications, and line 4 has Save as the first child of `main`.
2. **Pass**. The table has "B1 ... Met by markup" and "B3 ... Met by markup".
3. **Pass**. The reply says: "the visual comparison against `layout.html` was not run (no screenshot or browser tool). Human visual acceptance is still required."
4. **Pass**. `diff -r fixture/c4-review-ref trials/candidate-c4` is empty.
- Limit: the coordinator condensed this reply. The findings, status table, and limits were kept.

#### candidate-c5 (C5): pass

1. **Pass**. There is no `docs/lusona/visuals` in the trial directory. `diff -r` against `c1-retention` shows only three new files in `tmp/options/`, and the spec is unchanged.
2. **Pass**. There are three wizard options (`revised-a.html` top stepper, `revised-b.html` "Step N of 3", `revised-c.html` side step list). Each has Back/Next buttons and one section per step. They are in `tmp/options/`, outside `docs/lusona`. The reply says "Choose one by letter, or ask for another revision."
3. **Pass**. There is no `src/settings.html`, because `src/` is empty in both the fixture and the trial.
- Observation outside the criteria: `revised-b.html` and `revised-c.html` contain CSS and script left over from the shared template (unused `.crumb` styles, `p` null checks). This has no effect on the grade.

#### candidate-c6 (C6): pass

1. **Pass**. `trials/candidate-c6/src/settings.html`:
   - AC1: lines 18-34.
   - AC2: the button at line 35 is `disabled`, and line 43 sets `save.disabled` from the comparison with the baseline values.
2. **Pass**. No options were generated, and the trial has no `docs/lusona/visuals` directory. The only changes are the spec and `src/settings.html`.
3. **Pass**. No binding checklist was created. The reply says: "No visual reference is linked, so the visual-reference rules do not apply."

### Source review findings

Scope reviewed:
- `git diff` of 12 modified files.
- New files `plugins/lusona/references/visuals.md` and `plugins/lusona/templates/visual-reference.md`.

These were checked against spec `docs/lusona/specs/20261028-visual-options-and-references.md`, `AGENTS.md`, and the core rules in `plugins/lusona/README.md`.

| # | Severity | Location | Defect |
| --- | --- | --- | --- |
| R1 | Medium | `plugins/lusona/skills/specify/SKILL.md:29-32`; `plugins/lusona/references/visuals.md:3` | **AC4 is at risk for specify.** The link to visuals is inside the bullet that starts "For visual work, ...". `visuals.md:3` limits loading to cases "when a choice or explanation is visual". AC4 requires a diagram in spec content that has flow, sequence, state, or component relationships, even when the work is not visual (for example, a password reset or a state machine spec). The specify trigger does not cover non-visual specs with flows, so the diagram rule in `visuals.md:12-13` may never load. Explore (`explore/SKILL.md:47`) names flow, sequence, state, and component explicitly, and architect (`architect/SKILL.md:86`) has no condition. No trial covers specify diagrams; C3 covers explore only. Fix: in specify, make the trigger its own bullet with the explore wording, and widen `visuals.md:3` to "or content has flow, sequence, state, or component relationships". |
| R2 | Low | `README.md:226-229` and the same paragraph in `README.de.md:249`, `README.es.md:248`, `README.ja.md:224`, `README.zh-CN.md:171` | The new paragraph sits directly before "For example, an experienced maintainer who has supplied compatibility constraints...". That example refers to the adaptation paragraph (lines 215-218), but it now reads as an example of visual options. Move the visuals paragraph after the "For example" paragraph in all five READMEs. |
| R3 | Low | `README.md:226-227` (and the translations) | The sentence makes diagrams depend on the visual-choice condition ("When a ... choice is easier to judge visually, the agent offers 2-4 lettered options **and adds diagrams** ..."). `visuals.md:12-13` and AC4 require diagrams for any content with flow or state relationships, regardless of a visual choice. The public description is narrower than the rule. The translations copy this structure exactly, so they are faithful to the English text. |
| R4 | Low | `plugins/lusona/references/visuals.md:23-24` | "Write draft options to ... the host scratch directory" can mean writing outside the repository. The core Contract (`plugins/lusona/README.md:67-69`) lists "changes outside the repository" among the actions that need the user's approval first. Host-provided scratch is probably intended to be allowed, but the rule does not say so. Fix: name the project's ignored `tmp/` first, or state that the host scratch directory is permitted. |

Checks with no defect:
- Constraints and ACs:
  - AC1: `visuals.md:9-11` and `28-31`.
  - AC2: `visuals.md:33-48` and the template.
  - AC3: `visuals.md:30-31` and `35`.
  - AC4: covered for explore and architect; specify is R1.
  - AC5: `visuals.md:17-22`.
  - AC6 and AC7: `visuals.md:55-59`.
  - AC8: `visuals.md:50-51` and `60`, plus `specify/SKILL.md:29-32`, which keeps the existing capture.
  - Constraints 1-11 are covered. Constraint 8 (no host-specific rendering) is covered by `visuals.md:21`.
- Write authority: retention is limited to "the core write authority and no-save restrictions" (`visuals.md:35-36`). Review consumption requires no writes, which is consistent with `review/SKILL.md:71-74`.
- Questions: options are chosen by letter through the native question tool, linked to `README.md#questions-and-next-actions`. The anchor exists.
- Links: a local link and anchor check over all 14 changed or new Markdown files found 0 broken links. The pinned Mermaid URL `https://cdn.jsdelivr.net/npm/mermaid@11.4.1/dist/mermaid.min.js` returned HTTP 200, and `npm view mermaid@11.4.1 version` returned `11.4.1`.
- Translations (de, es, ja, zh-CN) match the English paragraph in meaning, and each links `plugins/lusona/references/visuals.md`.
- Instruction load:
  - Each of the 5 skills gets one trigger sentence.
  - The core References table gets one row.
  - `files.md` gets two rows.
  - The 60-line reference loads only on demand.
  - No skill copies the rules.
- `git diff --check` is clean.
- The candidate snapshot `snapshots/candidate/` is identical to the current `plugins/lusona/` (`diff -r` empty), so the trials ran the reviewed source.
- Not a defect: the fixtures use binding IDs `B1-B4`, while the source and template use `V1, V2, ...`. The trials were not affected.

## Verification

- Read `design.md`, `evaluator/criteria.md`, all `tasks/*.md`, `trials/REPLY-NOTES.txt`, `trials/DIFFS.txt`, and all 9 reply files.
- Ran `diff -r fixture/<case> trials/<arm>-<case>` for all 8 trials. I read every changed or new file in full, including the four `src/settings.html` files line by line against AC1-AC2 and B1-B4.
- Checked integrity:
  - `shasum -a 256 -c frozen.sha256`: 0 mismatches.
  - `snapshots/baseline.sha256` and `snapshots/candidate.sha256`: 0 mismatches.
  - `git status` of the repository shows only the expected implementer changes, and `HEAD` is still `6bcd4b0`.
  - These checks cannot detect writes outside the repository.
- Source review:
  - `git diff`, both new files, the spec, `AGENTS.md`, and the core README sections Contract, References, and Questions and next actions.
  - `references/retention.md` (grep).
  - A Python link and anchor checker, a curl and npm check of the Mermaid URL, and `git diff --check`.
- Not run:
  - `claude plugin validate` and `scripts/package.py` (outside the grader's read-only scope).
  - No browser rendering of any HTML page.
  - Host checks other than Claude Code.

## Remaining work and concerns

- TF-b (AC6) has no red. baseline-c2 passed, so there is no baseline-failure evidence for AC6 as the spec's TDD policy requires ("observe the baseline ... fail before editing"). A discriminating fixture is needed, for example a reference with binding items that are not labeled, or a spec that links the reference only indirectly. The alternative is to record the deviation and get the user's acceptance.
- R1 (specify diagram trigger) needs a fix, or the user must accept the narrower behavior. AC4 for specify and architect has no trial.
- R2-R4 are low-severity documentation and wording fixes.
- Repository checks, the durable evidence directory `docs/lusona/evidence/2026-10-28-visual-references/`, and human acceptance of the skill wording are still outstanding, per the spec's completion condition.
- Limits:
  - One observation per case on one host and model.
  - The C4 reply and part of the C3 turn 2 reply were condensed by the coordinator.
  - Actor isolation from the evaluator files was by instruction only.

## Recovery

This file is the durable record: `/Volumes/code/_lusona_/ai-skills/tmp/visual-references-20261028/evaluator/grades.md`. To resume, read it and the spec handoff.

## Correction rounds

None.
