# Repository instructions

Small static web prototype. Pages live in `src/` as plain HTML with inline CSS.
Do not commit, push, or publish. Verify pages by inspecting the markup.
