# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Assumptions and unresolved questions: page layout not yet chosen (options generated, see session).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user chooses a layout option.
