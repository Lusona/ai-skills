# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Accepted decisions and source: layout option B chosen by the user, 2026-10-28; visual reference [account-settings](../visuals/20261028-account-settings/reference.md).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: implementation of AC1-AC2 requested by the user, 2026-10-28.
- Next action: implement `src/settings.html`.
