# Visual reference: Account settings layout

Chosen: option B, by the user on 2026-10-28. Visual: [layout.html](layout.html)
Owner: [spec 20261028-account-settings](../../specs/20261028-account-settings.md)

## Binding

- B1: Two regions: a fixed-width left section navigation and a main panel to its right.
- B2: Navigation order is Profile, Notifications, Security.
- B3: Only the selected section's fields show in the main panel; selecting a nav item switches it.
- B4: The Save button sits at the bottom-right of the main panel.

## Illustrative

- Colors, fonts, copy text, and exact spacing.

## Rejected options

- A (single column): page too long; all sections at once.
- C (top tabs): hides section names behind tabs.
