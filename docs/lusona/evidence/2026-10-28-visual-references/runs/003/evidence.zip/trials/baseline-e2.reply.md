Layout B is recorded in the spec, but the item is not Ready yet. It needs your answer to one question and your acceptance of the criteria.

Question: Option B shows one section at a time. Is that acceptable, given you objected to C hiding sections behind tabs? If not, a hybrid of A and B.

Spec changes (`docs/lusona/specs/20261028-account-settings.md`): added AC3 (vertical section nav beside one content panel; Profile first); added a "Visual direction" section: Chosen: B (reference `tmp/options/b.html`); Excluded: A's single long stacked page and C's horizontal tabs; Colors: no requirement. Replaced the "layout not yet chosen" note with the open question; updated the handoff.

Queue: added the item as Ideas. TDD stays none. No code written.
