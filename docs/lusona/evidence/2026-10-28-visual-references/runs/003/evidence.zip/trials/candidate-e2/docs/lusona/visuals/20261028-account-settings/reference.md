# Visual reference: 20261028-account-settings

- Chosen option: B, section nav and panel, chosen by user on 2026-10-28
- Source: [option-b.html](option-b.html)
- Owner: [Spec 20261028-account-settings](../../specs/20261028-account-settings.md)

## Images

- [option-b.png](option-b.png): default (Profile selected, Save disabled); one screen

## Binding

- V1: Page layout: a vertical section nav on the left and one content panel on the right.
- V2: Nav order: Profile, Notifications, Security; Profile is selected by default.
- V3: Profile panel: Display name and Email inputs, with Save below the panel.
- V4: Save is disabled in the default state.
- V5: Selecting a nav item swaps the panel to that section.

## Illustrative

- Colors (user: colors do not matter), copy, and spacing.

## Fidelity

- Wireframe only. Only the Profile panel is drawn; the Notifications and Security panels are not drawn.

## Rejected options

- A: single column; too long.
- C: top tabs; hides sections behind tabs.
