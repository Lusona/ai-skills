**Result** ❓ Needs input: pick A, B, or C for the add-item flow. If none fit, say what to change and I will redraw.

Options are wireframes of the Packing tab. A: inline row per section; B: pinned add bar; C: sheet from + button (table with benefit/tradeoff).

Evidence: option pages at `.../baseline-e1/tmp/visuals/20261028-quick-add/index.html` with a/b/c.html; index rendered in headless Chrome (index.png). Pages use the Lusona wireframe template in ignored tmp/. Spec unchanged; TDD none; no queue item.

Next action: reply with A, B, or C; after choice save chosen mockup + reference note under docs/lusona/visuals/20261028-quick-add/ and link from the spec.
