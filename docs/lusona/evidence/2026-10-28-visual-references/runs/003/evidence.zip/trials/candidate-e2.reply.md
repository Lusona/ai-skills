Layout B is recorded in the spec and the specify session is at its boundary: the definition is done and implementation is not authorized. One question: B also shows one section at a time, close to what you rejected in C; I assumed B's side nav is acceptable.

What I saved:
- `docs/lusona/visuals/20261028-account-settings/option-b.html`: chosen option, status "Chosen reference".
- `option-b.png`: headless Chrome screenshot of the default state, inspected; shows only the Profile panel.
- `reference.md`: binding V1 vertical nav left + one panel right; V2 nav order Profile, Notifications, Security, Profile selected; V3 Profile panel Display name + Email, Save below; V4 Save disabled by default; V5 nav swaps the panel. Colors illustrative. Rejected A (too long), C (hides sections behind tabs). Index and rejected files not kept.
- Spec updated with the decision, the assumption, and AC3 "matches V1-V5".
Not done: no queue item; TDD none; nothing committed.
