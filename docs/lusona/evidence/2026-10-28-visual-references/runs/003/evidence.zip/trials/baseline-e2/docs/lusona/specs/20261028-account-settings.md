# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.
- [ ] AC3: Layout follows option B: a vertical section nav (Profile, Notifications, Security)
  beside one content panel; selecting a nav item shows that section's panel, and Profile is
  shown first.

### Visual direction

- Chosen: option B, section nav and panel (reference: `tmp/options/b.html`, session scratch).
- Excluded: a single long page with all sections stacked (option A, rejected as too long);
  a horizontal tab bar (option C, rejected because it hides sections behind tabs).
- Colors: no requirement (user: "colors don't matter"); use neutral defaults.

### Decisions and uncertainty

- Assumptions and unresolved questions: layout chosen by user: option B. Open question: B also shows one section at a time, which
  may conflict with the objection to C ("hides sections behind tabs"); see handoff.

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user confirms B's one-panel-at-a-time behavior and accepts scope and criteria
  AC1-AC3; then the item can move to Ready.
