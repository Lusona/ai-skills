I drew the three entry points as one switchable page; open it and flip between A, B and C: `.../candidate-e3/tmp/quick-add/a.html`. Deep links such as `a.html#option=b&state=failed`. Checked A, B, C screenshots in headless Chrome; spec unchanged.

What the page shows: Screen 1 Packing list with the entry point (A + next to Edit, B "Add item" row per category, C floating button). Screen 2 same Name and Category sheet; "Save failed" switch shows the iCloud sync error with typed text kept and Retry (AC2). Real names ("Lisbon, 4 nights", Clothes, Toiletries, Documents). Tab bar and keyboard placeholders; system components drawn by hand.

Tradeoffs: A nav bar + (standard, small target); B row per category (category implied; repeats, below fold); C floating button (thumb reach; covers rows, less common on iOS). Recommendation A.

Questions: 1. Which entry point, A, B or C? After pick: save chosen page and screenshots under docs/lusona/visuals/20261028-quick-add/ and record the decision. 2. preselected category for A/C. 3. Save disabled while name empty? 4. TDD confirm none.
Nothing queued; no commit.
