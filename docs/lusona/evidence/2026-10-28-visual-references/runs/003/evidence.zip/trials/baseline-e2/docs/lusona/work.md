# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| 20261028-account-settings | Ideas | Static `src/settings.html` matches AC1-AC3; user accepts | Confirm B behavior and accept scope/criteria |

## Icebox

No parked work.
