import re,sys
T="/Volumes/code/_lusona_/ai-skills/tmp/visual-platform-20261028/snapshots/candidate/templates/visual-page.html"
OUT="/Volumes/code/_lusona_/ai-skills/tmp/visual-platform-20261028/trials/candidate-e1/tmp/visuals/quick-add/flow.html"
t=open(T).read()
# strip leading comment
t=re.sub(r'<!--\nLusona visual page.*?-->\n','',t,count=1,flags=re.S)
# remove diagram and index variants
t=re.sub(r'<!-- BEGIN diagram variant.*?<!-- END diagram variant -->\n','',t,flags=re.S)
t=re.sub(r'<!-- BEGIN index variant.*?<!-- END index variant -->\n','',t,flags=re.S)
# remove index-only view switch
t=re.sub(r'<!-- index variant only: view switch -->\n<div class="lv-switch" role="group" aria-label="View">.*?</div>\n','',t,flags=re.S)
# remove state switch
t=re.sub(r'<!-- optional state switch.*?-->\n<div class="lv-switch" role="group" aria-label="State".*?</div>\n','',t,flags=re.S)
t=t.replace('<!-- optional option switch: only when options differ in one part of the flow -->\n','')

css='''
.app-nav{padding:6px 16px 0;display:flex;justify-content:space-between;color:#007aff;font-size:17px}
.app-title{padding:4px 16px 8px;font-size:32px;font-weight:700;letter-spacing:-.5px}
.app-list{background:#f2f2f7;position:absolute;top:54px;left:0;right:0;bottom:0;overflow:hidden}
.app-body{padding-top:62px}
.app-h{padding:14px 20px 6px;font-size:13px;color:#6c6c70;text-transform:uppercase}
.app-h.is-target{color:#007aff;font-weight:600}
.app-card{margin:0 16px;background:#fff;border-radius:12px;overflow:hidden}
.app-row{display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-top:.5px solid #e5e5ea;min-height:44px}
.app-row:first-child{border-top:0}
.app-sw{width:51px;height:31px;border-radius:16px;background:#e5e5ea;position:relative;flex:none}
.app-sw::after{content:"";position:absolute;top:2px;left:2px;width:27px;height:27px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3)}
.app-sw.on{background:#34c759}.app-sw.on::after{left:22px}
.app-add{color:#007aff}
.app-tabs{position:absolute;bottom:0;left:0;right:0;height:83px;padding:8px 0 34px;display:flex;justify-content:space-around;background:rgba(249,249,249,.94);border-top:.5px solid #c6c6c8;font-size:10px;color:#8e8e93;z-index:3}
.app-tabs span{display:flex;flex-direction:column;align-items:center;gap:2px}.app-tabs i{font-style:normal;font-size:22px;line-height:1}
.app-tabs .on{color:#007aff}
.app-kb{position:absolute;bottom:0;left:0;right:0;height:300px;background:#d1d3d9;z-index:6;padding:10px 4px;display:flex;flex-direction:column;gap:10px;align-items:center;font-size:12px;color:#444}
.app-kb b{display:block;height:44px;width:96%;border-radius:6px;background:#fff;box-shadow:0 1px 0 #888;line-height:44px;text-align:center;font-weight:400;letter-spacing:6px}
.app-kb em{margin-top:auto;margin-bottom:34px;font-style:normal}
.app-dim{position:absolute;inset:0;background:rgba(0,0,0,.35);z-index:4}
.app-sheet{position:absolute;left:0;right:0;top:130px;bottom:0;background:#f2f2f7;border-radius:12px 12px 0 0;z-index:5;padding:14px 0}
.app-sheet-bar{display:flex;justify-content:space-between;padding:0 16px 14px;color:#007aff}
.app-sheet-bar strong{color:#000}
.app-in{color:#000}.app-ph{color:#aeaeb2}
.app-err{color:#d70015;font-size:14px;padding:6px 20px}
.app-btn{color:#007aff;font-weight:600}
.app-bar{position:absolute;left:0;right:0;background:#f9f9f9;border-top:.5px solid #c6c6c8;padding:8px 12px;z-index:5;display:flex;gap:8px;align-items:center}
.app-field{flex:1;background:#fff;border:1px solid #d1d1d6;border-radius:18px;padding:7px 14px;min-height:36px}
.app-chip{flex:none;background:#e5f0ff;color:#007aff;border-radius:16px;padding:7px 11px;font-size:15px;font-weight:600}
.app-go{flex:none;width:34px;height:34px;border-radius:50%;background:#007aff;color:#fff;display:grid;place-items:center;font-size:18px}
.app-go.is-off{background:#c7c7cc}
.app-go.is-retry{background:#d70015;width:auto;border-radius:17px;padding:0 12px;font-size:14px}
.app-fab{color:#007aff;font-size:28px;line-height:1}
'''
t=t.replace('/* Option content CSS: target platform or project theme. Prefix classes, e.g. app-. */',css)

def row(name,on=False): return f'<div class="app-row"><span>{name}</span><span class="app-sw{" on" if on else ""}"></span></div>'
def cards(target=None, extra=None, add_rows=False):
    extra=extra or {}
    secs=[("Clothes",["Rain jacket","Walking shoes"],[]),("Toiletries",["Sunscreen"],[]),("Documents",["Passport"],["Passport"])]
    h=""
    for n,items,packed in secs:
        h+=f'<div class="app-h{" is-target" if n==target else ""}">{n}</div><div class="app-card">'
        for i in items: h+=row(i,i in packed)
        h+=extra.get(n,"")
        if add_rows: h+='<div class="app-row app-add">+ Add item</div>'
        h+='</div>'
    return h
def nav(plus=False):
    return f'<div class="app-nav"><span>Edit</span><span>{"<span class=app-fab>+</span>" if plus else ""}</span></div><div class="app-title">Lisbon, 4 nights</div>'
TABS='<div class="app-tabs"><span><i>✈</i>Trips</span><span class="on"><i>☑</i>Packing</span><span><i>⚙</i>Settings</span></div>'
KB='<div class="app-kb"><b>q w e r t y u i o p</b><b>a s d f g h j k l</b><b>z x c v b n m</b><em>System keyboard, drawn by hand</em></div>'
def screen(n,title,note,body):
    return f'''<figure class="lv-screen"><figcaption><span class="lv-step">{n}</span><span>{title}<small>{note}</small></span></figcaption>
<div class="lv-device is-iphone"><div class="lv-device-screen">{body}</div></div></figure>'''
def opt(k,body): return f'<div data-option="{k}">{body}</div>'
def wrap(inner): return f'<div class="app-list"><div class="app-body" style="padding-top:8px">{inner}</div></div>'

# Option A: inline row in each section
a1=wrap(nav()+cards(add_rows=True))+TABS
fld='<div class="app-row"><span class="app-in">Sun hat</span><span class="app-btn">Add</span></div>'
a2=wrap(nav()+cards(target="Clothes",extra={"Clothes":fld}))+KB
fld3='<div class="app-row"><span class="app-in">Sun hat</span><span class="app-btn">Retry</span></div><div class="app-err">Could not sync to iCloud. Your text is kept.</div>'
a3=wrap(nav()+cards(target="Clothes",extra={"Clothes":fld3}))+KB
# Option B: sheet
b1=wrap(nav(plus=True)+cards())+TABS
sheet=lambda err,btn:f'''<div class="app-dim"></div><div class="app-sheet"><div class="app-sheet-bar"><span>Cancel</span><strong>New item</strong><span class="app-btn">{btn}</span></div>
<div class="app-card"><div class="app-row"><span class="app-in">Sun hat</span></div><div class="app-row"><span>Category</span><span style="color:#8e8e93">Clothes ⌃</span></div></div>{err}</div>'''
b2=wrap(nav(plus=True)+cards())+sheet('','Add')+KB.replace('z-index:6','')
b3=wrap(nav(plus=True)+cards())+sheet('<div class="app-err">Could not sync to iCloud. Your text is kept.</div>','Retry')+KB
# Option C: bottom bar
def bar(bottom,txt,go,err=''):
    t=f'<span class="app-in">{txt}</span>' if txt else '<span class="app-ph">Add an item…</span>'
    return f'{err}<div class="app-bar" style="bottom:{bottom}px"><div class="app-field">{t}</div><span class="app-chip">Clothes ▾</span>{go}</div>'
c1=wrap(nav()+cards())+bar(83,'','<span class="app-go is-off">↑</span>')+TABS
c2=wrap(nav()+cards())+bar(300,'Sun hat','<span class="app-go">↑</span>')+KB
c3=wrap(nav()+cards())+f'<div class="app-err" style="position:absolute;left:0;right:0;bottom:352px;background:#fff0f0;z-index:5">Could not sync to iCloud. Your text is kept.</div>'+bar(300,'Sun hat','<span class="app-go is-retry">Retry</span>')+KB

S=[("1","Packing list","Entry point to adding",(a1,b1,c1)),
   ("2","Adding an item","Name typed, category chosen: Clothes",(a2,b2,c2)),
   ("3","Save fails","Sync to iCloud throws; typed text stays",(a3,b3,c3))]
flow='<div class="lv-flow">\n'+"\n".join(screen(n,ti,no,opt("a",x[0])+opt("b",x[1])+opt("c",x[2])) for n,ti,no,x in S)+'\n</div>'

sw='<div class="lv-switch" role="group" aria-label="Option" data-switch="option"><span>Option</span><button type="button" data-value="a" data-tradeoff="Fastest path and category is implied by the section, but each section carries a repeated add row." data-recommended>A · Inline row</button><button type="button" data-value="b" data-tradeoff="Clear category picker and room for later fields, but leaves the list and costs more taps per item." >B · Sheet</button><button type="button" data-value="c" data-tradeoff="Stays in place and supports adding many items in a row, but the bar occupies space above the tab bar at all times.">C · Entry bar</button></div>'
t=re.sub(r'<div class="lv-switch" role="group" aria-label="Option".*?</div>',sw,t,count=1,flags=re.S)
t=re.sub(r'<div class="lv-flow">.*?</div>\n</figure>\n</div>\n',lambda m:flow+'\n',t,count=1,flags=re.S)
t=t.replace('<span class="lv-letter" aria-label="Option {{option_letter}}">{{option_letter}}</span>','<span class="lv-letter" aria-label="Option A">A</span>')
rep={"record_id":"20261028-quick-add","option_title":"Options","status_kind":"draft","status":"Draft option",
"question":"How should a traveler add an item from the Packing tab?",
"question_context":"Compare three add-item flows on the existing Packing list (Lisbon, 4 nights). Out of scope: new tabs, editing and deleting items, Trips and Settings.",
"binding_items":"","illustrative_items":"<li>Colors, copy, and spacing in all options</li><li>Sample item name \"Sun hat\"</li>",
"fidelity":"Approximate: iOS system components (list, keyboard, tab bar, sheet) are drawn by hand; icons are glyphs. Loading state during save is not drawn.",
"open_questions":"<li>ItemStore.add saves locally, then syncs. If the sync throws, is the item already in the list? Retry could create a duplicate.</li><li>Should the category default to the last used one?</li><li>Should the traveler be able to add several items in a row?</li>",
"must_not_happen":"<li>Typed text is lost when saving fails</li><li>The traveler leaves the Packing tab to add an item</li><li>An item is added without a category</li>"}
for k,v in rep.items(): t=t.replace('{{'+k+'}}',v)
assert '{{' not in t, re.findall(r'\{\{\w+\}\}',t)
open(OUT,'w').write(t)
