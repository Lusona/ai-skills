Three add-item options are ready for you to pick from; none is chosen yet. I recommend A. Pick by letter (A, B or C), or ask for revised options.

I could not open a browser here; checked in headless Chrome screenshots. Draft; nothing saved to the spec or docs/lusona/.

Open `.../candidate-e1/tmp/visuals/quick-add/flow.html` and use the A/B/C switch (keys a, b, c).
Each option shows three screens on the existing "Lisbon, 4 nights" list: the list, adding "Sun hat" to Clothes, and the failed-save screen (typed text kept, retry offered). Tab bar, copy and layout come from PackingListView.swift and PacklistApp.swift.
A Inline row (recommended), B Sheet, C Entry bar — each with a tradeoff.
Open questions (also on the page): Retry duplication after local save; default category; several items in a row.
After you pick: save reference under docs/lusona/visuals/20261028-quick-add/, record decision and binding items in the spec. TDD none.
