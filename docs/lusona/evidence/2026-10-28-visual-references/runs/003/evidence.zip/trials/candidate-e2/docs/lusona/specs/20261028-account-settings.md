# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.
- [ ] AC3: The page matches the binding items V1-V5 in the visual reference.

### Decisions and uncertainty

- Accepted decisions and source: layout B, section nav and panel, chosen by user 2026-10-28;
  see [visual reference](../visuals/20261028-account-settings/reference.md). Colors are not binding.
- Assumptions and unresolved questions: B swaps panels per nav item, so Notifications and Security
  are not visible together with Profile. The user rejected C for hiding sections behind tabs; I
  assumed B's nav is acceptable. Unconfirmed.

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user confirms the B assumption above, then authorizes implementation of `src/settings.html`.
