# Run 003 grades and source review

Grader: independent Opus agent (Lusona `review` responsibility). I did not write the change or run the trials.
Date: 2026-10-28. Read-only apart from this file and `evaluator/scratch/`.

## Status

All six trials graded. Both test-first targets go from a failing baseline to a passing candidate: TF-d (AC13) and TF-e (AC11).
Candidate-only checks pass: E1 AC9/AC14/AC15/AC17/AC18, E3 AC16, E4 AC19/AC7.
E4 passes with one deviation in wording: V3 is reported as "partially met", not "unmet".
Source review: 0 blocking, 0 high, 1 medium, 7 low findings.

## Outcome: trial grades

| Trial | Target | Grade | Key evidence |
|---|---|---|---|
| baseline-e1 | TF-d (AC13) | **fail** | Generic grayscale boxes. No iPhone frame, large-title nav bar, or tab bar (`scratch/be1-a.png`, `trials/baseline-e1/tmp/visuals/20261028-quick-add/index.png`). Item 2 fails; items 1, 3, 4 pass. |
| candidate-e1 | TF-d (AC13) | **pass** | iPhone frames, large title "Lisbon, 4 nights", Trips/Packing/Settings tab bar, grouped Clothes/Toiletries/Documents (`scratch/e1-a.png`, `e1-b.png`, `e1-c.png`) |
| candidate-e1 | AC9 | pass | Header shows `20261028-quick-add`, letter A/B/C, "Draft option", and the question. Notes panel. OS theme followed (`scratch/e1-a-dark.png`); Theme button at `flow.html:197` |
| candidate-e1 | AC14 | pass | Each option has 3 numbered screens in sequence: list, adding, save fails |
| candidate-e1 | AC15 | pass | Screen 3 "Save fails" in A, B, and C: "Could not sync to iCloud. Your text is kept." plus Retry |
| candidate-e1 | AC17 | pass | Fidelity: "iOS system components … drawn by hand". 3 open questions and 3 must-not-happen rules |
| candidate-e1 | AC18 | pass | Lede: "Compare three add-item flows on the existing Packing list … Out of scope: …" |
| baseline-e2 | TF-e (AC11) | **fail** | No `docs/lusona/visuals/`, PNG, HTML, or `reference.md`. Spec links the draft `tmp/options/b.html` (baseline spec diff). Items 1, 2, 4, 5 fail. |
| candidate-e2 | TF-e (AC11) | **pass** | `option-b.png` shows the B layout: vertical nav and Profile panel. `option-b.html` differs from the draft only in status "Chosen reference" (line 51). Only B is retained. `reference.md` has V1–V5, illustrative items, rejected A and C with reasons, and an image link. Spec links the reference. No `src/` change. |
| candidate-e3 | AC16 | **pass** | `tmp/quick-add/a.html`: one flow page. The option switch changes screen 1 in place (`scratch/e3-a.png`, `e3-b.png`, `e3-c-failed.png`). One tradeoff line per option; A marked Recommended. Reply asks for a choice by letter. No `docs/lusona/visuals`. |
| candidate-e4 | AC19 / AC7 | **pass (with deviation)** | Reply reports V1 unmet and V2 unmet. V3 is reported as "partially met (error shown, but text cleared and no Retry)", with High finding "failed save clears typed text (QuickAddSheet.swift:23; AC2, V3)" and Low finding "no Retry". States that the screenshot comparison did not run and that human visual acceptance is still required. `diff -r` against the fixture finds no file edits. |

Rationale and caveats:

- **E4 V3.** The criteria require V3 to be reported as unmet. The rule at `visuals.md:95` allows only met, unmet, or unchecked; "partially met" is outside that set.
  - I graded the meaning: both planted parts of V3 (text cleared, no Retry) are named as not satisfied and raised as findings, and the review result is "does not meet the spec".
  - Under a literal reading of criterion 1, E4 fails on V3. The caller should decide which reading applies.
  - My evidence that the PNGs were read is the condensed reply ("binding status and limits verbatim" per REPLY-NOTES). There is no transcript.
- **E1 page form.** Candidate-e1 used one switch page for options that differ on every screen. AC11 asks for one file per option plus an index. AC11 was not a graded E1 item; the cause is listed as finding F2.
- **E2 single state.** Candidate-e2 retained one PNG. The fixture's B page has only one state, so this meets AC11.
- **E4 fixture defects.** These are setup issues, not trial failures:
  - `option-a.html` and its PNGs come from `samples/site/switch.html`. They show record ID `20261028-add-item`, title "Lisbon", tabs "Trips/Lists/Settings", and a still-present option B and option switch under "Chosen reference".
  - The page's notes list different binding text from `reference.md`.
  - `reference.md` governs (`visuals.md:84-85`), and V1–V3 remain visible in the PNGs, so the grade stands. The fixture does not follow the retention rule at `visuals.md:61-63`.
- **Writes outside trial directories.** No plugin file changed after the trials started: the latest mtime is 18:55, and the candidate trials ran from 18:56 to 18:59. `git log` shows no new commit. `frozen.sha256` verifies except `evaluator/criteria.md`, as declared.

## Outcome: source review

Checks:

- `snapshots/candidate` equals `plugins/lusona`: `diff -rq` is clean and `candidate.sha256` verifies.
- The diff against `snapshots/baseline` covers 7 files.
- The Mermaid SRI is correct. `mermaid@11.4.1/dist/mermaid.min.js` downloaded and hashed gives `sha384-rbtjAdnIQE/…H/9I`, the same as `visual-page.html:220`.
- The diagram variant renders in light and dark (`scratch/diag-dark.png`).
- The index renders side by side, and its embedded iframes hide the header and notes (`scratch/index-light.png`).
- Clicking Theme on the index also switches the embedded options. Chrome derives each iframe's color scheme from the parent.
- At 375 px, measured in iframes, `scrollWidth == clientWidth == 375` for the template, E1, E3, and the E2 reference (`scratch/h375.png`).

Rule coverage in `references/visuals.md`:

| Criterion | Holds? | Location |
|---|---|---|
| AC1 | yes | :9, :48-51 |
| AC2 | yes | :55-85 |
| AC3 | yes | :50-51 |
| AC4 | yes | :12-13 |
| AC5 | yes | :34-42 |
| AC6 | yes | :92-94 |
| AC7 | yes | :95-98 |
| AC8 | yes | :87-88, :99 |
| AC9 | yes | :36-38, plus template |
| AC11 | partly | see F2 and F6 |
| AC12 | yes | template :219-227 |
| AC13 | yes | :17-21 |
| AC14 | yes | :24 |
| AC15 | yes | :25-26 |
| AC16 | yes | :27-28 |
| AC17 | yes | :29-30 |
| AC18 | yes | :22-23, :29 |
| AC19 | partly | see F3 |

`visuals.md`, the template comment, `visual-reference.md`, `files.md`, and the five SKILL triggers agree on directory, file names, status values, and per-state PNGs. The only gap is F4.

| ID | Severity | Location | Finding |
|---|---|---|---|
| F1 | Medium | `templates/visual-page.html:231-232` vs `:8`, `:37`, `:188` | The index variant reuses `{{option_title}}` and `{{tradeoff}}` for each option's caption. `{{option_title}}` is also the page-level value, which is "Options" on an index. Replacing each placeholder name once, as the comment at :5 instructs, labels every figure "Options" with the same tradeoff. Reproduced in `scratch/index-light.png`. Fix: use distinct names such as `{{title_a}}` and `{{tradeoff_a}}`, as the option switch at :204 already does. |
| F2 | Low | `references/visuals.md:39-40` | "…or one in-place switch page" drops the condition from constraint 13 and AC16 that options differ in one part. :27-28 states it, but the Presentation rule reads as a free choice. Observed: candidate-e1 used a switch page for three whole-flow alternatives and gave no side-by-side view (AC11). |
| F3 | Low | `references/visuals.md:95-98` | AC19 requires that review read the PNGs and the HTML source. :92 says this for implement only. Review compares screenshots "when the result can be rendered" but is not told to read the retained images and source otherwise. E4 read them anyway. |
| F4 | Low | `skills/explore/SKILL.md:47-49`, `specify/SKILL.md:32-35`, `architect/SKILL.md:86-88` | The triggers say "after a choice, retain the reference under `docs/lusona/visuals/`" with no qualifier. The limit "within the core write authority and no-save restrictions" exists only at `visuals.md:55-56`. In explore, where "disposable discussion needs no document" (`explore/SKILL.md` Outcome), the trigger reads as an unconditional write instruction. Mitigated because the trigger links visuals.md. |
| F5 | Low | `templates/visual-page.html:255`, `:257`, `:260` | `params()` lowercases hash values and :260 lowercases element `data-state`/`data-option`, but button `data-value` and click values are not lowercased. A mixed-case state name such as `saveFailed` never shows by click or hash (reproduced: `scratch/site/b-case.html`, `t-click.html`, result `hidden=true`). The comment at :25-26 does not require lowercase names. |
| F6 | Low | `references/visuals.md:64-66` vs AC11 | AC11 says "each screen and state … saved as a PNG". The rule saves one whole-page PNG per state showing all screens. I accept this as covering every screen and state, but the AC wording and the rule differ. Align one of them. |
| F7 | Low | `templates/visual-page.html:255`, `:266` | A malformed hash throws and aborts `init()` before the `hashchange` and `keydown` listeners register. Examples: `%` makes `decodeURIComponent` throw a URIError; `"` breaks the unescaped `querySelector('[data-value="'+p[k]+'"]')`. This needs a hand-typed URL. |
| F8 | Low | `references/visuals.md:68-71` | The capture command does not set a color scheme, so retained PNGs follow the capturing host's OS theme. Candidate-e2's `option-b.png` is dark. Colors are illustrative by default, so the impact is small. Adding `--blink-settings=preferredColorScheme=1` would make retained PNGs reproducible. |

Not defects, checked:

- Theme follows the OS, and the override persists in browser storage (constraint 20).
- Device frames use `color-scheme:light` and zoom down at 480, 380, and 340 px.
- Embedded mode and the `#full` flag work.
- The Mermaid source stays in `pre.mermaid`.
- The Choice section uses the core native question rule.
- No conflict with README write authority, retention, or questions, apart from F4.

### Instruction load (AGENTS.md "Keep context and process small")

- **Size.** The template grew from 6,800 B to 24,662 B, about 6k tokens. It is read only when a visual page is written; no skill loads it otherwise.
- **Byte breakdown:**

  | Section | Bytes |
  |---|---|
  | Top comment | 2.5 K |
  | Shell CSS | 5.0 K |
  | Flow and device frames | 4.6 K |
  | Index CSS | 1.0 K |
  | Wireframe kit | 2.5 K |
  | Body | 4.2 K |
  | JavaScript | 3.5 K |

- **Why most of it stays.** Pages must be self-contained, so most of the CSS and JS ends up in each page anyway. Observed actor pages are 26–33 KB.
- **Optional bytes.** The parts that are optional per page total about 4.5 KB:
  - wireframe kit (fallback only)
  - Android and browser frames
  - index CSS
- **Verdict.** Not a defect at Medium or above: the load is conditional and proportionate to a feature that was asked for. Advisory (Low, not counted above): `visuals.md:36-37` could say to copy the file and read only the top comment and the body markup (:2-32, :183-243). That cuts the read to about 7 KB without changing output.

## Verification

- I read every trial file, reply, fixture, task, design, and criteria file.
- `diff -r` of each trial against its fixture: trial changes are confined to `tmp/` and, for E2, to `docs/lusona`.
- I rendered every candidate page in headless Chrome, plus baseline-e1:
  - options a/b/c and states, light and dark
  - 375 px in iframes
- I viewed every retained PNG: E2 `option-b.png` and the E4 fixture's `option-a.png` and `option-a-failed.png`.
- Template tests on scratch pages built from the template (`scratch/mk.py`):
  - diagram, index, and option variants
  - theme toggle propagation
  - mixed-case state names
- I hashed the Mermaid SRI and verified the snapshot and frozen hashes.
- Not run:
  - `claude plugin validate`
  - packaging
  - Codex, Cursor, and Xcode hosts
  - Safari and Firefox rendering
  - offline Mermaid rendering in a browser (source readability was checked by inspecting the markup only)

## Remaining work and concerns

- F1 is the one finding worth fixing before acceptance. F2–F8 are optional wording or robustness fixes. After any template or rule edit, re-render the template variants. A trial re-run is needed only if F2 or F3 wording changes.
- The E4 fixture does not follow the retention rule: wrong record ID and content, and B still present under "Chosen reference". A future review trial should rebuild it from a correctly retained page.
- The spec record is stale and should be updated by the owner:
  - "Current handoff" still says revised AC9/AC11/AC13-AC19 are "not implemented" (`docs/lusona/specs/20261028-visual-options-and-references.md:217-221`).
  - The AC boxes are unchecked.
- Evidence is one observation per case with Sonnet actors on Claude Code. Replies were condensed by the coordinator.
- Human acceptance of the skill wording is still required (spec :65-66).

## Recovery

This file is the complete result. Scratch renders and test pages are in `evaluator/scratch/`, regenerable with `shot.sh` and `mk.py`. Nothing outside `evaluator/` was modified.

## Correction rounds

None.
