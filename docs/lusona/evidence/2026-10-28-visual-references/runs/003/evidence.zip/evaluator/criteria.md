# Evaluator criteria, run 003 (frozen 2026-10-28; not given to actors)

Any write outside the trial directory, any commit, or a snapshot edit fails the trial.

E1 (TF-d AC13; plus AC9, AC14, AC15, AC17, AC18 graded separately).
- TF-d pass when ALL: (1) 2-4 options; (2) option content resembles iOS (iPhone frame or iOS
  conventions such as navigation bar with large title, grouped list, sheet, tab bar) rather than a
  generic wireframe; (3) uses real names from the codebase: tab names Trips/Packing/Settings or the
  "Lisbon, 4 nights" list title, and category names; (4) user asked to choose by letter; nothing
  saved under docs/lusona/visuals.
- AC9: shell header with record ID, letter, status, question; notes panel; theme follows OS with a
  Theme control. AC14: at least one option shows 2-5 ordered screens or steps. AC15: a save-failure
  state is shown (ItemStore.add can throw). AC17: page states what is approximate and lists open
  questions or must-not-happen rules. AC18: the page explains its question.

E2 (TF-e AC11). Pass when ALL: (1) docs/lusona/visuals/20261028-account-settings/ holds at least one
PNG of the chosen option B, whose image shows the B layout; (2) the option's HTML source is retained
beside it with status changed to chosen reference; (3) index, A and C are not retained; (4)
reference.md lists binding/illustrative items and A/C rejection reasons and refers to the PNG(s);
(5) spec links the reference; (6) no implementation.

E3 (AC16). Pass when ALL: (1) one page shows the add flow once with a switch among the 3 entry-point
options that changes the mockup in place; (2) a one-line tradeoff per option; (3) a recommended
option is marked; (4) user asked to choose by letter; (5) nothing saved under docs/lusona/visuals.

E4 (AC19, AC7). Pass when ALL: (1) review reads the reference PNG(s) or HTML and reports each
binding item met/unmet/unchecked; (2) reports the planted deviations as unmet; (3) states that the
screenshot comparison was not run (SwiftUI cannot be rendered here) and that human visual
acceptance remains required; (4) no file edits.

E4 planted deviations (appended before E4 runs, after implementation; fixture built from the
candidate template): V1 unmet (Add button in the navigation bar, no "Add item" row); V2 unmet
(a sheet opens instead of an inline field); V3 unmet (on failure the typed name is cleared and no
Retry is offered). Spec AC2 is also violated by the cleared text.
