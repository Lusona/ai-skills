import re,sys
T=open('/Volumes/code/_lusona_/ai-skills/plugins/lusona/templates/visual-page.html').read()
def cut(s,name): return re.sub(r'<!-- BEGIN %s variant.*?<!-- END %s variant -->'%(name,name),'',s,flags=re.S)
def fill(s,d):
    for k,v in d.items(): s=s.replace('{{%s}}'%k,v)
    return s
base=dict(record_id='20261028-test',status_kind='draft',status='Draft option',question='Q?',question_context='ctx',binding_items='<li>b</li>',illustrative_items='<li>i</li>',open_questions='<li>o</li>',must_not_happen='<li>m</li>',fidelity='approx')
dg=cut(cut(T,'mockup'),'index'); dg=fill(dg,dict(base,option_letter='',option_title='Flow',status_kind='diagram',status='Diagram',mermaid_source='flowchart LR\n  A[List] --&gt; B{Save ok?}\n  B --&gt;|yes| C[Done]\n  B --&gt;|no| D[Retry]'))
dg=re.sub(r'<span class="lv-letter".*?</span>\n','',dg); dg=re.sub(r'<!-- index variant only.*?</div>\n','',dg,flags=re.S)
open('site/diagram.html','w').write(dg)
for L in 'ab':
    m=cut(cut(T,'diagram'),'index'); m=re.sub(r'<!-- index variant only.*?</div>\n','',m,flags=re.S)
    m=m.replace('<!-- screen content styled by option-style; data-option="a" / data-state="failed" mark variants -->','<div style="padding:16px">Option %s <p data-state="failed" style="color:red">failed</p></div>'%L)
    m=re.sub(r'<!-- optional option switch.*?</div>\n','',m,flags=re.S)
    open('site/%s.html'%L,'w').write(fill(m,dict(base,option_letter=L.upper(),option_title='Opt '+L,screen_name='List',screen_note='n')))
ix=cut(cut(T,'diagram'),'mockup'); ix=re.sub(r'<span class="lv-letter".*?</span>\n','',ix)
open('site/index.html','w').write(fill(ix,dict(base,option_letter='',option_title='Options',status_kind='index',status='Option index',tradeoff='t')))
