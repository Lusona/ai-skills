#!/bin/bash
# usage: shot.sh <page> <hash> <out.png> [scheme 0|1 dark=0? ] [w,h]
C="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
B=/Volumes/code/_lusona_/ai-skills/tmp/visual-platform-20261028/evaluator/scratch
"$C" --headless=new --user-data-dir=$B/chrome --hide-scrollbars --window-size=${5:-1800,1250} --blink-settings=preferredColorScheme=${4:-1} --virtual-time-budget=3000 --screenshot="$B/$3" "file://$1#$2" 2>/dev/null >/dev/null
