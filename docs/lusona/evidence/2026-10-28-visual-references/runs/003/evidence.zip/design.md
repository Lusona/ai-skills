# Trial design: platform-styled options, flows, states, PNG retention (run 003)

Frozen 2026-10-28 before plugin edits. Owner: docs/lusona/specs/20261028-visual-options-and-references.md

- TDD targeted (user). Test-first: TF-d = E1, iOS fixture gets iPhone-styled options using the
  app's real screen names (AC13); TF-e = E2, a choice retains PNGs per screen/state plus HTML
  source (AC11 revised). Baseline: plugins/lusona working tree before run-003 edits
  (snapshots/baseline.sha256). Candidate: after edits (snapshots/candidate.sha256).
- Candidate-only: E1 also graded for AC9 shell, AC14, AC15, AC17, AC18; E3 in-place switch (AC16);
  E4 review with PNG reference (AC19, AC7 fallback).
- E2 uses the same fixture in both arms (options built with the earlier template), so inputs match.
- E4 fixture is built after implementation from the candidate template (reference PNGs + HTML +
  a deviating SwiftUI implementation); its hashes are added to frozen.sha256 before E4 runs.
- Conditions: Claude Code subagents, Sonnet actors in both arms; fresh fixture copies; no
  delegation; no browser-opening commands; headless Chrome is available to actors at
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" for screenshots; no Xcode use;
  no user mid-turn. Budget: 6 trials (baseline E1, E2; candidate E1-E4), one attempt each, no
  retries. Independent Opus grader. Stop after grading or on environment failure.
