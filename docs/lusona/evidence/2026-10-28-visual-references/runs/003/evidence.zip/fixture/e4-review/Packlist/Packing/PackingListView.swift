import SwiftUI

struct PackingListView: View {
    let store: ItemStore
    @State private var isAdding = false
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.categories) { category in
                    Section(category.name) {
                        ForEach(category.items) { item in
                            Toggle(item.name, isOn: .constant(item.isPacked))
                        }
                    }
                }
            }
            .navigationTitle("Lisbon, 4 nights")
            .toolbar {
                EditButton()
                Button("Add", systemImage: "plus") { isAdding = true }
            }
            .sheet(isPresented: $isAdding) { QuickAddSheet(store: store) }
        }
    }
}
