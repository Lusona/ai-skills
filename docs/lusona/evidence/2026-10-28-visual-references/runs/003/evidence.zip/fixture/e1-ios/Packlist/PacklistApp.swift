import SwiftUI

@main
struct PacklistApp: App {
    @State private var store = ItemStore()
    var body: some Scene {
        WindowGroup {
            TabView {
                TripsView().tabItem { Label("Trips", systemImage: "airplane") }
                PackingListView(store: store).tabItem { Label("Packing", systemImage: "checklist") }
                SettingsView().tabItem { Label("Settings", systemImage: "gear") }
            }
        }
    }
}
