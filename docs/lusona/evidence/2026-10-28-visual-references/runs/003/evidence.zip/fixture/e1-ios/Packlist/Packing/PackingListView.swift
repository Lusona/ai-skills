import SwiftUI

struct PackingListView: View {
    let store: ItemStore
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.categories) { category in
                    Section(category.name) {
                        ForEach(category.items) { item in
                            Toggle(item.name, isOn: .constant(item.isPacked))
                        }
                    }
                }
            }
            .navigationTitle("Lisbon, 4 nights")
            .toolbar { EditButton() }
        }
    }
}
