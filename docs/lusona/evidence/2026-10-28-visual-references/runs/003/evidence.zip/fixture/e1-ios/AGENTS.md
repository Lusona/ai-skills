# Repository instructions

Packlist is a SwiftUI iPhone app (iOS 18). Sources are in `Packlist/`.
Do not commit, push, or publish.
