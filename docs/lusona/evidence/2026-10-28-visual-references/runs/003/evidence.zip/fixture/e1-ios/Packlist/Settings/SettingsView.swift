import SwiftUI
struct SettingsView: View { var body: some View { NavigationStack { Form { Toggle("iCloud sync", isOn: .constant(true)) }.navigationTitle("Settings") } } }
