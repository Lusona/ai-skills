import SwiftUI
struct TripsView: View { var body: some View { NavigationStack { List { Text("Lisbon, 4 nights") }.navigationTitle("Trips") } } }
