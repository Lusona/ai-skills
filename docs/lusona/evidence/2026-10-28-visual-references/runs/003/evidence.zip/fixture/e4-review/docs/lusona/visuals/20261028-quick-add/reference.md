# Visual reference: 20261028-quick-add

- Chosen option: A, Inline row, chosen by the user on 2026-10-28
- Source: [option-a.html](option-a.html)
- Owner: [spec 20261028-quick-add](../../specs/20261028-quick-add.md)

## Images

- [option-a.png](option-a.png): Packing list and Add an item, editing state
- [option-a-failed.png](option-a-failed.png): Add an item, save failed state

## Binding

- V1: Packing list screen: each category ends with an "Add item" row; there is no add button in the navigation bar.
- V2: Add an item screen, editing state: tapping "Add item" shows an inline text field inside that category; no sheet opens.
- V3: Save failed state: the typed text stays in the field and an error with Retry is shown.

## Illustrative

- Colors, spacing, and icon shapes.

## Fidelity

- Approximates iOS 18 grouped lists; production uses system components.

## Rejected options

- B: Floating button; covers list content and is far from the category.
