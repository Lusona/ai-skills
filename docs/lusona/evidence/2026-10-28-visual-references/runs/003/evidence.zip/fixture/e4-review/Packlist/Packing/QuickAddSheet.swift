import SwiftUI

struct QuickAddSheet: View {
    let store: ItemStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var category: Category.ID?
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                TextField("Item name", text: $name)
                Picker("Category", selection: $category) {
                    ForEach(store.categories) { Text($0.name).tag(Optional($0.id)) }
                }
                if let error { Text(error).foregroundStyle(.red) }
            }
            .navigationTitle("Add item")
            .toolbar {
                Button("Save") {
                    Task {
                        do { try await store.add(name, to: category!); dismiss() }
                        catch { self.error = "Couldn't save item."; name = "" }
                    }
                }
            }
        }
    }
}
