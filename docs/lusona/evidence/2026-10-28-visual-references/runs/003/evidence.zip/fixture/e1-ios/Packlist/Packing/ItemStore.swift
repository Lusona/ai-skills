import Foundation
import Observation

@Observable
final class ItemStore {
    var categories: [Category] = Category.samples
    /// Saves locally, then syncs to iCloud. Throws when the sync fails.
    func add(_ name: String, to category: Category.ID) async throws { }
}

struct Category: Identifiable { let id = UUID(); var name: String; var items: [Item]
    static let samples = [
        Category(name: "Clothes", items: [Item(name: "Rain jacket"), Item(name: "Walking shoes")]),
        Category(name: "Toiletries", items: [Item(name: "Sunscreen")]),
        Category(name: "Documents", items: [Item(name: "Passport", isPacked: true)])
    ]
}
struct Item: Identifiable { let id = UUID(); var name: String; var isPacked = false }
