import re, sys
from pathlib import Path
src = Path(sys.argv[1]).read_text(); out = Path(sys.argv[2])
def variant(keep):
    s = src
    for v in ('mockup', 'diagram', 'index'):
        if v != keep:
            s = re.sub(r'<!-- BEGIN %s variant.*?<!-- END %s variant -->\n' % (v, v), '', s, flags=re.S)
    if keep != 'mockup':
        s = re.sub(r' <span class="lv-option">.*?</span>', '', s)
    return s
def fill(s, **kw):
    for k, v in kw.items(): s = s.replace('{{%s}}' % k, v)
    assert '{{' not in s.split('-->', 1)[1], re.findall(r'{{\w+}}', s.split('-->', 1)[1])
    return s
base = dict(record_id='20261028-settings', question='Which settings layout?', binding_summary='V1 nav regions; V2 save after cancel', illustrative_summary='colors, copy, spacing')
a = variant('mockup')
(out/'a.html').write_text(fill(a, option_letter='A', option_title='Sidebar', status='Draft option', **base))
b = a.replace('<div class="wf-row"><div class="wf-nav">', '<div class="wf-tabs"><div class="wf-nav">')
(out/'b.html').write_text(fill(b, option_letter='B', option_title='Tabs', status='Draft option', **base))
i = variant('index').replace('A: {{option_title}}', 'A: Sidebar').replace('B: {{option_title}}', 'B: Tabs')
(out/'index.html').write_text(fill(i, status='Draft option', option_letter='', option_title='Options', **base))
d = variant('diagram')
(out/'diagram.html').write_text(fill(d, status='Diagram', option_letter='', option_title='Save flow', mermaid_source='flowchart LR\n  A[Edit] --> B{Valid?}\n  B -->|yes| C[Save]\n  B -->|no| A', **base))
