import sys, re
from html.parser import HTMLParser
VOID = {'meta','link','br','img','input','hr','source','area','base','col','embed','track','wbr'}
class P(HTMLParser):
    def __init__(s): super().__init__(); s.stack=[]; s.err=[]; s.classes=set(); s.ext=[]; s.inbody=False; s.mock=False
    def handle_starttag(s, t, a):
        a=dict(a)
        for c in (a.get('class') or '').split(): s.classes.add(c)
        for k in ('src','href'):
            if a.get(k,'').startswith(('http:','https:','//')): s.ext.append(a[k])
        if t=='style' and s.stack and 'body' in s.stack: s.err.append('style in body')
        if 'style' in a: s.err.append('inline style attr on '+t)
        if t not in VOID: s.stack.append(t)
    def handle_endtag(s, t):
        if t in VOID: return
        if not s.stack or s.stack[-1]!=t: s.err.append(f'mismatch </{t}> stack={s.stack[-3:]}')
        else: s.stack.pop()
for f in sys.argv[1:]:
    p=P(); p.feed(open(f).read()); p.close()
    if p.stack: p.err.append(f'unclosed {p.stack}')
    bad=[c for c in p.classes if not (c.startswith(('wf-','lv-','is-')) or c=='mermaid')]
    print(f, 'OK' if not p.err and not bad else 'FAIL', p.err, 'non-kit classes:', bad, 'external:', p.ext)
