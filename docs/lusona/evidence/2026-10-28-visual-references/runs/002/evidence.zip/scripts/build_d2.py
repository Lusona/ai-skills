import re, sys
from pathlib import Path
src = Path(sys.argv[1]).read_text(); out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
def variant(keep):
    s = src
    for v in ('mockup', 'diagram', 'index'):
        if v != keep:
            s = re.sub(r'<!-- BEGIN %s variant.*?<!-- END %s variant -->\n' % (v, v), '', s, flags=re.S)
    if keep != 'mockup':
        s = re.sub(r' <span class="lv-option">.*?</span>', '', s)
    return s
def body(s, html):
    return re.sub(r'(<!-- BEGIN mockup variant.*?-->\n).*?(<!-- END mockup variant -->)', lambda m: m.group(1)+html+'\n'+m.group(2), s, flags=re.S)
def fill(s, **kw):
    for k, v in kw.items(): s = s.replace('{{%s}}' % k, v)
    return s
base = dict(record_id='20261028-account-settings', question='Which layout fits the account settings page?', binding_summary='to be set after a choice', illustrative_summary='colors, copy, spacing')
profile = '<h2 class="wf-heading">Profile</h2><span class="wf-input">Display name</span><span class="wf-input">Email</span>'
notif = '<h2 class="wf-heading">Notifications</h2><p class="wf-text">Email digest</p><span class="wf-toggle"></span>'
sec = '<h2 class="wf-heading">Security</h2><p class="wf-text">Change password</p>'
save = '<div class="wf-row"><span class="wf-button is-primary is-disabled">Save</span></div>'
A = '<div class="wf-page">\n<div class="wf-panel">'+profile+'</div>\n<div class="wf-panel">'+notif+'</div>\n<div class="wf-panel">'+sec+'</div>\n'+save+'\n</div>'
B = '<div class="wf-page">\n<div class="wf-row">\n<div class="wf-nav is-vertical"><span class="wf-nav-item is-active">Profile</span><span class="wf-nav-item">Notifications</span><span class="wf-nav-item">Security</span></div>\n<div class="wf-col"><div class="wf-panel">'+profile+'</div>'+save+'</div>\n</div>\n<p class="wf-note">Selecting a nav item swaps the panel to that section.</p>\n</div>'
C = '<div class="wf-page">\n<div class="wf-tabs"><span class="wf-tab is-active">Profile</span><span class="wf-tab">Notifications</span><span class="wf-tab">Security</span></div>\n<div class="wf-panel">'+profile+'</div>\n'+save+'\n</div>'
m = variant('mockup')
for letter, title, html in (('A','Single column',A),('B','Section nav and panel',B),('C','Top tabs',C)):
    (out/(letter.lower()+'.html')).write_text(fill(body(m, html), option_letter=letter, option_title=title, status='Draft option', **base))
i = variant('index')
fig = re.search(r'<figure>.*?</figure>\n', i, flags=re.S).group(0)
figs = ''.join(fig.replace('A: {{option_title}}', f'{L}: {t}').replace('a.html', f'{L.lower()}.html').replace('Option A', f'Option {L}') for L, t in (('A','Single column'),('B','Section nav and panel'),('C','Top tabs')))
i = re.sub(r'<figure>.*</figure>\n', figs, i, flags=re.S)
(out/'index.html').write_text(fill(i, option_letter='', option_title='Layout options', status='Draft option', **base))
