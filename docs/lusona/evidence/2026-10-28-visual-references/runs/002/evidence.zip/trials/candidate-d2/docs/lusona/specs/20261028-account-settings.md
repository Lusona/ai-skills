# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.
- Visual reference: option B, section nav and panel, chosen 2026-10-28; see
  [reference](../visuals/20261028-account-settings/reference.md). Binding V1-V3 there; colors, copy,
  and spacing are illustrative.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.
- [ ] AC3: The page matches binding items V1-V3 of the visual reference.

### Decisions and uncertainty

- Assumptions and unresolved questions: layout chosen (B). Open: in B, selecting a nav item shows
  one section at a time, which hides the other sections; the user rejected C for hiding sections
  behind tabs. Confirm whether one-section-at-a-time is acceptable, or whether all sections should
  stay visible with the nav scrolling to them.

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user confirms the section-visibility question and accepts scope, criteria AC1-AC3,
  and the TDD level `none`; then the item can move to Ready.
