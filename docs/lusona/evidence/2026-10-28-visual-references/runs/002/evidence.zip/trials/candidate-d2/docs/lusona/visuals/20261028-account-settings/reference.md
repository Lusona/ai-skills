# Visual reference: 20261028-account-settings

- Chosen option: B (section nav and panel), chosen by user on 2026-10-28
- Visual: [b.html](b.html)
- Owner: [20261028-account-settings](../../specs/20261028-account-settings.md)

## Binding

- V1: A vertical section navigation sits left of a content panel.
- V2: Navigation items are ordered Profile, Notifications, Security; Profile is active initially.
- V3: The Save button sits below the content panel and is disabled initially.

## Illustrative

- Colors (user: "colors don't matter"), copy, spacing, and wireframe styling.

## Rejected options

- A: Single column; rejected as too long.
- C: Top tabs; rejected because it hides sections behind tabs.
