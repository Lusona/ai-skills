Pick a layout for the settings page: A, B, or C. Nothing is saved yet. The spec and queue are unchanged, and no visual reference is retained until you choose. I did not open the HTML mockup in a browser (not permitted here).

Mockup file with all three options: `/Volumes/code/_lusona_/ai-skills/tmp/visual-template-20261028/trials/baseline-d1/tmp/settings-layout-options.html`. It sits in the ignored `tmp/` directory.

[A: single column stacked cards; B: left nav one section at a time; C: top tabs — each with an inline ASCII sketch]

Recommendation: A. Question: which layout do you choose, A, B, or C? You can also reject all three and I will offer revised options.

Once you choose, I will save the chosen mockup and a reference.md under docs/lusona/visuals/20261028-account-settings/ and link it from the spec.
