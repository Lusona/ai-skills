# Visual reference: 20261028-account-settings

- Chosen option: B (Section nav and panel), chosen by user on 2026-10-28
- Visual: [option-b.html](option-b.html)
- Owner: [20261028-account-settings](../../specs/20261028-account-settings.md)

## Binding

- V1: A vertical section nav lists Profile, Notifications, and Security in that order, with Profile active initially.
- V2: A single content panel beside the nav shows the active section; selecting a nav item swaps the panel.
- V3: The Profile panel contains display name and email inputs.
- V4: A Save button sits below the panel and starts disabled.

## Illustrative

- Colors (user: "Colors don't matter"), copy, and spacing.
- Notifications and Security panel contents beyond the controls in AC1.

## Rejected options

- A: Single column; too long.
- C: Top tabs; hides sections behind tabs.
