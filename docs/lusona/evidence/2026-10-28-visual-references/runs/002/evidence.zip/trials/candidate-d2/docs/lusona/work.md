# Work queue

## Active queue

| Item / change | State | Completion condition | Current blocker or next action |
| --- | --- | --- | --- |
| [20261028-account-settings](specs/20261028-account-settings.md) | Ideas | Settings page built per spec and accepted by user | User confirms section-visibility question and accepts spec |

No active work.

## Icebox

No parked work.
