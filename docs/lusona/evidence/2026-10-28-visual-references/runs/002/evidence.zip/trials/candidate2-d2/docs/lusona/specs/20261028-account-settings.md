# Spec 20261028-account-settings: Account settings page

Created: 2026-10-28
Updated: 2026-10-28

Kind: feature

## Agreement

- User and problem: signed-in users cannot change their profile, notification, or security
  settings without contacting support.
- Desired behavior: one settings page with Profile, Notifications, and Security sections.
- Scope and exclusions: static prototype page `src/settings.html`; no backend.

### Acceptance criteria

- [ ] AC1: The page shows Profile (display name, email), Notifications (email digest toggle),
  and Security (change password link) sections.
- [ ] AC2: A Save button is disabled until a field changes.

### Decisions and uncertainty

- Layout: option B (section nav and panel), chosen by user 2026-10-28; binding items in
  [visual reference](../visuals/20261028-account-settings/reference.md).
- Open question: B shows one section at a time, as C did; the user rejected C for hiding sections
  behind tabs. Confirm that B's nav-swapped panel is acceptable (V2).

### TDD policy

- Level: none
- Selected by user: request, 2026-10-28

## Current handoff

- Authorized work: definition only.
- Next action: user confirms scope, criteria, and the V2 question; then implement `src/settings.html`
  (TDD none).
