Pick a layout: A, B, or C. Browser opening is unavailable here, so I wrote the pages to disk but have not viewed them.

Open this file to compare all three side by side: `.../candidate-d1/tmp/visual-options/index.html`
The options are in the same folder as `a.html`, `b.html` and `c.html`. They are wireframes built from the Lusona visual page template. They differ only in structure.

| Option | Layout | Save behavior |
|---|---|---|
| A: Single page | One scrolling column, sections stacked | One Save/Cancel at bottom, disabled until change |
| B: Sidebar | Left nav, one section at a time | Save/Cancel for visible section |
| C: Tabs | Tabs across top, one section at a time | Save/Cancel for visible section |

Recommends A. Open decision: reply with the letter; if none fits, ask for revision.
Not yet decided: Save scope for B/C; TDD none already.
Spec unchanged; nothing saved under docs/lusona/visuals; after a choice will save the chosen page and reference.md, not the rejected options or the index. Queue unchanged. Draft pages in tmp/; no .gitignore so ignored status not confirmed.
