**Result** (❓ Needs input): I wrote a checkout-flow sequence diagram, but it is a hypothesis, not a map of your system. I have not rendered the page or opened it in a browser.

Open: `/Volumes/code/_lusona_/ai-skills/tmp/visual-template-20261028/trials/candidate-d3/tmp/checkout-flow/diagram.html`

The page is in the project's ignored `tmp/` and nothing is saved to `docs/`. It uses the Lusona visual page template. The Mermaid script loads from a CDN; without network, the page shows the readable Mermaid source.

Assumed flow: (1) place order, get cart; (2) reserve stock; (3) out of stock: reject, message, update cart, restart, no payment; (4) all reserved: authorize/charge; (5) declined: release reservation, show reason, keep cart, no order, no confirmation email (optional payment-failed email); (6) approved: commit reservation, mark cart converted, confirmation email, confirmation page.

Evidence: read AGENTS.md, empty queue, empty src/ and specs/. Next action: four questions (reserve before payment? authorize-then-capture? browser to cart direct? decline email?).
