# Trial design: standard HTML template (AC9-AC12)

Frozen 2026-10-28 before template edits. Owner: docs/lusona/specs/20261028-visual-options-and-references.md

- TDD targeted (user). Test-first TF-c: D1 option generation produces templated files + index.html
  (AC9, AC11). Baseline: plugins/lusona working tree at 1.3.0 before template edits
  (snapshots/baseline.sha256). Candidate: after template edits (snapshots/candidate.sha256).
- Candidate-only: D1 also grades AC10; D2 retention of a chosen templated option (AC11); D3 diagram
  page (AC9, AC12).
- D2 fixture is created from the candidate template after implementation and before candidate
  trials, because it depends on the template; its hash is added to frozen.sha256 at that time.
- Conditions as in tmp/visual-references-20261028/design.md: Claude Code subagents, Sonnet actors in
  both arms, fresh fixture copies, no delegation, no browser opening, no screenshot tool, no user
  mid-turn. Budget: 4 trials (baseline D1, candidate D1-D3), one attempt each, no retries.
  Independent Opus grader. Stop after grading or on environment failure.

## Run 2 addendum (declared 2026-10-28 before run-2 trials)

Run 1 graded candidate D1 fail on AC10 (inline style attributes for a sidebar) and D2 fail on
AC11 (footer binding changed on retention); grader traced both to source defects F1 (visuals.md
permitted a footer change) and F2 (no kit column width). Correction round 1 fixed F1-F5. Run 2
re-runs candidate D1 and D2 once each on snapshots/candidate-2 with unchanged tasks and criteria.
D2 fixture is rebuilt as fixture/d2-retain-2 from the corrected template (template change).
D3 is not re-run (its template parts changed only in the instruction comment and title).
Run 1 results are preserved unchanged.
