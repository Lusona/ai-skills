import sys,re
from html.parser import HTMLParser
tpl=open(sys.argv[1]).read()
tstyle=re.search(r'<style>(.*?)</style>',tpl,re.S).group(1)
kit=set(re.findall(r'\.([a-z][a-z0-9-]*)',tstyle))
for f in sys.argv[2:]:
    s=open(f).read()
    styles=re.findall(r'<style[^>]*>(.*?)</style>',s,re.S)
    class P(HTMLParser):
        def __init__(s2):
            super().__init__(); s2.cls=set(); s2.styleattr=[]; s2.stack=[]; s2.errs=[]; s2.ext=[]
        def handle_starttag(s2,t,a):
            d=dict(a)
            for c in (d.get('class') or '').split(): s2.cls.add(c)
            if 'style' in d: s2.styleattr.append((s2.getpos(),t,d['style']))
            for k in ('src','href'):
                if d.get(k) and re.match(r'https?:',d[k]): s2.ext.append(d[k])
            if t not in ('meta','link','br','img','input','hr'): s2.stack.append(t)
        def handle_endtag(s2,t):
            if s2.stack and s2.stack[-1]==t: s2.stack.pop()
            else: s2.errs.append((s2.getpos(),t))
    p=P(); p.feed(s)
    body=re.sub(r'<style.*?</style>','',s,flags=re.S)
    print('==',f,'| style==tpl:',[st==tstyle for st in styles],'| nonkit:',sorted(p.cls-kit),'| styleattr:',p.styleattr,'| ext:',p.ext,'| nest:',p.errs,p.stack,'| placeholders:',re.findall(r'\{\{\w+\}\}',s),'| colors:',re.findall(r'#[0-9a-fA-F]{3,6}\b|rgb\(|hsl\(',body),'| comment:', '<!--\nLusona' in s)
