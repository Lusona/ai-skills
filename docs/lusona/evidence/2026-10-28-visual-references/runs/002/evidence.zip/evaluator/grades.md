# Grades: standard HTML template trials (AC9-AC12) and source review

Grader: independent Opus agent (Lusona `review` responsibility). I did not write the change or run
the trials. Date: 2026-10-28.

## Status

Complete. Two of the four graded outcomes fail under a strict reading of the frozen criteria.
The test-first TF-c is red on baseline and green on candidate. Candidate D1 fails AC10 because of
inline layout CSS. Candidate D2 fails because the retained file also changes its footer, and
`visuals.md` permits that change while AC11 and the criterion do not. D3 passes. The source review
found 0 high, 1 medium, and 4 low defects.

## Outcome

### Grade table

| Trial | Graded | Grade | Failing items |
|---|---|---|---|
| baseline-d1 | TF-c (items 1, 2, 4, 5) | fail (expected red) | 1, 2 |
| baseline-d1 | AC10 (item 3) | fail | 3 |
| candidate-d1 | TF-c (items 1, 2, 4, 5) | pass | none |
| candidate-d1 | AC10 (item 3) | fail (strict) | 3: inline `style` attributes |
| candidate-d2 | AC11 retention | fail (strict) | 1: footer binding summary also changed |
| candidate-d3 | AC9, AC12 | pass | none |

Integrity checks: `frozen.sha256` all OK. `snapshots/baseline.sha256` and
`snapshots/candidate.sha256` all OK. `snapshots/candidate` is byte-identical to `plugins/lusona`.
HEAD is still `6bcd4b0`, so the trials made no commit. Each trial differs from its fixture only
in the paths listed in `trials/DIFFS.txt`, and I found no write outside the trial directories.

### baseline-d1

TF-c: **fail**. This is the expected red for test-first behavior (c).

| Item | Result | Evidence |
|---|---|---|
| 1 option files with frame | fail | The trial wrote one combined file, `trials/baseline-d1/tmp/settings-layout-options.html`, which holds all three options (lines 18, 25, 29). It has no per-option files, no header with record ID, status, or question (line 16 is `<h1>Account settings: layout options</h1>`), and no dark-mode tokens (lines 3-15 contain only hard-coded light colors). |
| 2 index.html side by side | fail | No `index.html` exists. The options are stacked vertically under `<h2>` headings. |
| 4 outside docs/lusona | pass | The file is in `tmp/`. `diff -r` against the fixture shows only `tmp`. |
| 5 ask by letter, nothing saved | pass | `baseline-d1.reply.md:1` reads "Pick a layout for the settings page: A, B, or C. Nothing is saved yet." `docs/lusona/visuals` does not exist. |

AC10 (item 3): **fail**. The file uses its own classes `m`, `card`, `side`, `tabs`, and `on`, and hex
colors `#f4f4f4`, `#fff`, `#bbb`, and `#ccc` (lines 4-14). It also has an inline `style` attribute
at line 21 (`display:inline;width:auto`).

### candidate-d1

TF-c: **pass**.

| Item | Result | Evidence |
|---|---|---|
| 1 option files with frame | pass | The trial wrote `tmp/visual-options/a.html`, `b.html`, and `c.html`. Each header has the record ID, option letter, a draft status, and the question. For example, `b.html:50` is `20261028-account-settings <span class="lv-option">Option B: Sidebar</span> <span class="lv-status">Draft option</span>` and `b.html:51` is "Which layout should the account settings page use?". In every file the `<style>` block is byte-identical to the template, including the `prefers-color-scheme: dark` token block. No `{{...}}` placeholders remain. |
| 2 index.html side by side | pass | `index.html` uses the `lv-grid` index variant with three figures captioned "A: Single page", "B: Sidebar", and "C: Tabs", each with an iframe of its option file. The header has no option element, as the template requires. |
| 4 outside docs/lusona | pass | All pages are under `tmp/visual-options/`. Only `tmp` differs from the fixture. |
| 5 ask by letter, nothing saved | pass | `candidate-d1.reply.md:1` reads "Pick a layout: A, B, or C." The spec and queue are unchanged against the fixture, and `docs/lusona/visuals` does not exist. |

AC10 (item 3): **fail (strict)**.

- All classes come from the kit (`wf-*`, `is-*`, plus the frame class `lv-option`). No file has an
  added `<style>` block, color literal, font declaration, or external resource.
- `b.html:56` has `<div class="wf-col" style="flex:0 0 160px">`, and `b.html:57` has
  `<div class="wf-col" style="flex:3 1 260px">`.
- AC10 says mockup bodies use "only the template's wireframe kit classes and its color tokens".
  The template says "add no other CSS" (`templates/visual-page.html:14`). The coordinator's own
  `scripts/check_html.py` treats an inline `style` attribute as an error.
- The extra CSS sets only layout sizing. It introduces no color or font. Under the narrower reading
  of criterion item 3 ("no other colors or fonts"), this item would pass. I graded it under the
  stricter AC10 text.

### candidate-d2

Grade: **fail (strict)** on item 1. Items 2-5 pass.

| Item | Result | Evidence |
|---|---|---|
| 1 chosen file equals b.html except status | fail | `diff fixture/d2-retain/tmp/options/b.html trials/candidate-d2/docs/lusona/visuals/20261028-account-settings/b.html` shows two changes. Line 65 changes the status from `Draft option` to `Chosen reference`, which is allowed. Line 80 changes the footer from `Binding: to be set after a choice` to `Binding: V1 nav left; V2 Profile, Notifications, Security order; V3 Save below panel`. The criterion and AC11 allow only the status change. The actor followed `references/visuals.md:49-50`, which permits the footer change (see finding F1). |
| 2 index, a, c not copied | pass | `docs/lusona/visuals/20261028-account-settings/` contains only `b.html` and `reference.md`. `tmp/options` is unchanged (`diff -r` exit 0). |
| 3 reference.md content | pass | `reference.md:7-11` lists binding items V1-V3. `reference.md:13-15` lists illustrative items and quotes the user: "colors don't matter". `reference.md:19-20` gives "A: Single column; rejected as too long." and "C: Top tabs; rejected because it hides sections behind tabs." |
| 4 spec links it | pass | The spec diff adds `[reference](../visuals/20261028-account-settings/reference.md)` and AC3 "matches binding items V1-V3". |
| 5 no implementation | pass | `src/` is empty, and the item is queued in Ideas, not Ready. |

The trial also raised a follow-up question on its own: B hides sections in the same way the user
rejected in C. That behavior is correct and not graded.

### candidate-d3

Grade: **pass**.

| Item | Result | Evidence |
|---|---|---|
| 1 frame + Mermaid variant | pass | `tmp/checkout-flow/diagram.html:50-51` has a header with topic `checkout-flow`, status `Diagram`, and the question, with no option element. The `<style>` block is identical to the template, including dark tokens. Lines 54-90 hold the source in `<pre class="mermaid">`. Line 91 loads the pinned script `mermaid@11.4.1` with SRI. I downloaded the file and computed its SHA-384, which matches `sha384-rbtjAdnIQE/...9I`. |
| 2 absolute path reported | pass | The reply gives `/Volumes/code/_lusona_/ai-skills/tmp/visual-template-20261028/trials/candidate-d3/tmp/checkout-flow/diagram.html` and states that it did not open a browser. |
| 3 declined + out-of-stock | pass | `diagram.html:67-72` covers `alt Item out of stock`, and lines 76-80 cover `alt Payment declined`, including the reservation release. |
| 4 nothing in docs/lusona/visuals | pass | Only `tmp` differs from the fixture. |

### Findings (source change, `diff -ru snapshots/baseline plugins/lusona`)

| ID | Severity | Location | Defect |
|---|---|---|---|
| F1 | medium | `plugins/lusona/references/visuals.md:49-50` versus spec AC11 (`docs/lusona/specs/20261028-visual-options-and-references.md:87-89`) | The rule says to change "only its status to `Chosen reference` and, when useful, its footer binding summary". AC11 says the retained file has "only its status changed". The rule and the acceptance criterion contradict each other. The D2 actor followed the rule and failed the frozen criterion. To fix this, either remove the footer clause or have the user amend AC11. |
| F2 | low | `plugins/lusona/templates/visual-page.html:42` (kit) and `:14` | The kit has no way to give columns different widths, because every `.wf-col` is `flex:1 1 200px`. A sidebar layout, which is a common option, therefore led the D1 actor to add inline `style` (`b.html:56-57`) despite "add no other CSS". The D2 fixture shows that the kit can express a sidebar by placing `wf-nav is-vertical` directly in `wf-row`, but neither the template nor `visuals.md` says so. A narrow-column modifier or a one-line note would close the gap. |
| F3 | low | `plugins/lusona/templates/visual-page.html:21` and `:7` | `<title>` contains `{{option_letter}}: {{option_title}}`. The placeholder notes say to delete the option *element* on index and diagram pages, and they say nothing about the title, which cannot be deleted. Actors improvised: D1 wrote "layout options", D3 wrote "checkout-flow: Diagram", and the fixture builder produced "20261028-account-settings : Layout options". |
| F4 | low | `plugins/lusona/templates/visual-page.html:2-16` | Nothing says to delete the instruction comment after copying. If it stays, a retained reference keeps the `{{name}}` placeholder list and a link `../references/visuals.md` that does not resolve from `docs/lusona/visuals/<record-id>/` in a consuming project. The retained D2 `b.html:2-16` shows this, inherited from the fixture. D1 removed the comment. Outcomes differ by actor. |
| F5 | low | `plugins/lusona/templates/visual-page.html:9` | The status vocabulary (`Draft option | Chosen reference | Diagram`) has no value for the index page. D1 used `Draft option` for the index. This is harmless, but it does not match AC9's "status (draft option or chosen reference)". |

Checks with no defect found:

- **Well-formed.** The template parses with no tag mismatch, and so do all five candidate trial pages.
- **Dark mode.** The tokens are redefined under `prefers-color-scheme: dark`. The Mermaid theme
  follows the same media query. Iframes inherit the scheme.
- **Phone width.** The page has a viewport meta, `minmax(min(100%,340px),1fr)`, wrapping
  `.wf-row`, `min-width:0` columns, and `overflow-x:auto` on `pre.mermaid`.
- **Mermaid fallback.** The init call is guarded by `if(window.mermaid)`, and the source stays
  visible with `white-space:pre`.
- **Self-contained.** The pinned script appears only in the diagram variant.
- **Instructions usable.** All three actors produced correct variants from the comments.
- **Consistency.**
  - `files.md:30` lists the template.
  - `visual-reference.md:25` and `visuals.md:58` now agree on "Do not save the index or rejected option files".
  - `visuals.md` keeps "save a diagram as Mermaid in a Markdown file", which is consistent with constraint 1.
- **AC1-AC8 wording.** The text for AC1-AC8 is unchanged in substance: 2-4 letters, rejection
  saves nothing, inline versus HTML presentation, open or report the path, the
  consumption rules, and the user-supplied reference. The pinned URL moved from `visuals.md` into
  the template.
- **Instruction load.** `visuals.md` grows from 61 to 71 lines. No `SKILL.md` changed in this diff.
  The roughly 100-line template is read only when a page is generated.
- **Packaging.** `package/lusona-1.3.0.zip` contains `templates/visual-page.html`.

## Verification

- I verified hashes with `shasum -a 256 -c` for `frozen.sha256`, `snapshots/baseline.sha256`, and
  `snapshots/candidate.sha256`.
- I compared each trial and fixture with `diff -r`. I diffed each option file against the template.
- I parsed every trial page with Python `html.parser` (script in `/tmp/grader-vt/check.py`) to
  collect classes, `style` attributes, color literals outside `<style>`, external resources,
  placeholders, and tag nesting.
- I verified the Mermaid SRI hash by downloading the pinned file and running `openssl dgst -sha384`.
- I took a headless Chrome screenshot of the D1 `index.html` at `--window-size=360`. The result is
  not conclusive. Text was clipped even in plain header paragraphs, which points to the headless
  minimum window width rather than the page. `probe/index-360.png` was made with an earlier
  template that lacked `a{color:inherit}`. **Phone-width rendering of the final template is
  therefore unverified by me.**
- I did not run Mermaid rendering in a browser. Offline fallback, Codex, Cursor, and Xcode are
  untested. Coordinator condensation of the replies (`REPLY-NOTES.txt`) does not affect any graded
  item: items 2 and 5 were checked against files and the verbatim first lines.

## Remaining work and concerns

- AC9-AC12 are not met as graded: D1 fails AC10 and D2 fails AC11.
  - Both failures trace to source defects F1 and F2, not to actor error alone.
  - Fix F1 by removing the footer clause from `visuals.md:50` or by having the user amend AC11.
  - Fix F2 with a kit modifier or a usage note.
  - Re-running D1 and D2 needs new trial authorization, because the budget allowed one attempt
    each.
- The AC10 grade depends on reading criterion item 3 by the AC text, "only kit classes". If the
  user accepts the narrower criterion wording ("no other colors or fonts"), D1 AC10 becomes pass.
- F3-F5 are low severity and do not block.
- Spec AC9-AC12 checkboxes and the Evidence and handoff sections are not yet updated (outside the
  grader's scope).

## Recovery

None needed. I wrote only this file, plus scratch files under `/tmp/grader-vt/`: a parse script,
the downloaded Mermaid file, a screenshot, and a Chrome profile. I made no repository edits, no
commits, and no snapshot changes.

## Correction rounds

None.

---

# Run 2

Graded 2026-10-28 by the same independent grader, with the same role and read-only rules. Run 1
text above is unchanged.

## Status

Complete. Both run-2 trials pass against the unchanged `evaluator/criteria.md`:

- candidate2-d1 passes TF-c and AC10.
- candidate2-d2 passes AC11.

The correction resolves F1-F5. I found no new defect above low severity: one new low finding (N1)
and one informational note.

## Outcome

### Grade table

| Trial | Graded | Grade | Failing items |
|---|---|---|---|
| candidate2-d1 | TF-c (items 1, 2, 4, 5) | pass | none |
| candidate2-d1 | AC10 (item 3) | pass | none |
| candidate2-d2 | AC11 retention | pass | none |

Integrity:

- **Frozen files.** The original `frozen.sha256` entries all check OK, except `design.md`. Its
  first 15 lines still hash to the frozen value `9ce2a56a...c200`. The difference is the appended
  "Run 2 addendum" (line 17 onward), which matches the declared procedure.
- **D2 fixture.** The `fixture/d2-retain-2/*` entries, which use repo-root-relative paths, all check
  OK.
- **Snapshot.** `snapshots/candidate-2.sha256` checks OK. `diff -r snapshots/candidate-2
  plugins/lusona` shows no difference.
- **No commits.** HEAD is still `6bcd4b0`.
- **No stray writes.** The trials differ from their fixtures only in `tmp/` (D1) and in the spec
  plus `docs/lusona/visuals/` (D2).

### candidate2-d1

TF-c: **pass**.

| Item | Result | Evidence |
|---|---|---|
| 1 option files with frame | pass | The options are `tmp/visuals/account-settings/a.html`, `b.html`, and `c.html`. Each header has the record ID, letter, `Draft option`, and question. For example, `b.html:51` is `20261028-account-settings <span class="lv-option">Option B: Sidebar navigation</span> <span class="lv-status">Draft option</span>` and `b.html:52` is "Which layout should the account settings page use?". Each `<style>` block is byte-identical to the candidate-2 template, including the dark tokens. No placeholders remain, and the instruction comment was removed. |
| 2 index.html side by side | pass | `index.html:55-59` contains an `lv-grid` with three figures captioned "A: Single column", "B: Sidebar navigation", and "C: Tabs", each with an iframe. The status at `index.html:51` is `Option index`. |
| 4 outside docs/lusona | pass | Only `tmp` differs from `fixture/d1-generate`. |
| 5 ask by letter, nothing saved | pass | The reply says: "Pick one by letter (A, B or C)". The spec and queue are unchanged, and `docs/lusona/visuals` does not exist. |

AC10 (item 3): **pass**.

- All classes are kit classes: `wf-*`, `is-*`, and the frame class `lv-option`.
- No page has a `style` attribute, added CSS, color literal outside `<style>`, or external
  resource.
- The sidebar uses the new modifier: `b.html:58` `<div class="wf-col is-narrow">` and `b.html:59`
  `<div class="wf-col">`.

### candidate2-d2

Grade: **pass**.

| Item | Result | Evidence |
|---|---|---|
| 1 chosen file equals b.html except status | pass | `diff fixture/d2-retain-2/tmp/options/b.html .../visuals/20261028-account-settings/option-b.html` shows a single change at line 51, `Draft option` to `Chosen reference`. The file is named `option-b.html` rather than `b.html`. The criterion constrains only content, so the name does not affect the grade. |
| 2 index, a, c not copied | pass | The directory holds only `option-b.html` and `reference.md`. |
| 3 reference.md content | pass | `reference.md:9-12` lists binding items V1-V4. `reference.md:16-17` lists illustrative items and quotes the user: "Colors don't matter". `reference.md:21-22` gives "A: Single column; too long." and "C: Top tabs; hides sections behind tabs." |
| 4 spec links it | pass | Spec lines 23-24 link `[visual reference](../visuals/20261028-account-settings/reference.md)`. |
| 5 no implementation | pass | `src/` is empty. The spec names `src/settings.html` only as a next action that waits on user confirmation. |

As in run 1, the actor raised the B-versus-C visibility conflict as an open question (V2).

### Correction review (`diff -ru snapshots/candidate snapshots/candidate-2`)

| Run-1 ID | Resolved | Evidence |
|---|---|---|
| F1 (medium) | yes | `references/visuals.md:49-50` now reads "changing only its status to `Chosen reference`", which matches AC11. No other plugin file mentions changing the footer. |
| F2 (low) | yes | `templates/visual-page.html:44` adds `.wf-col.is-narrow{flex:0 1 180px}`. The comment at lines 14-15 adds "no style attributes" and "For a sidebar, put a wf-col is-narrow beside a wf-col in a wf-row." D1 used it. Below about 400px the row wraps, and the narrow column keeps a 180px width without overflow (`min-width:0` is inherited, and `flex-shrink` is 1). |
| F3 (low) | yes | The title is now `{{record_id}}: {{option_title}}` (line 22). The `option_title` note defines "Options" for an index page and the diagram name for a diagram page. D1 produced "20261028-account-settings: Options". |
| F4 (low) | yes | The comment now says "delete this comment" and "Apply the plugin's references/visuals.md", which replaces the broken relative link. Run-2 pages contain no comment. |
| F5 (low) | yes | The status list now includes `Option index`, and D1's index uses it. |

New findings:

| ID | Severity | Location | Defect |
|---|---|---|---|
| N1 | low | `templates/visual-page.html:12` (`binding_summary` note) and `references/visuals.md:49-50` | A draft page may carry a footer binding summary written before the choice. For example, the candidate2-d1 pages use the generic "layout regions, section order, ...". Retention now forbids changing that footer, so a retained page can show a binding summary that differs from the V-items in `reference.md`. Nothing states that `reference.md` takes precedence. The candidate2-d2 fixture avoided the problem by deleting the line at draft time. |
| (informational) | none | `templates/visual-page.html:22` | Option page titles no longer include the letter (for example "20261028-account-settings: Sidebar navigation"). The header and the index iframe titles still show it, so AC9 is unaffected. |

No other change: `files.md`, `visual-reference.md`, `SKILL.md` files, and the AC1-AC8 wording are
unchanged between candidate and candidate-2. The net instruction-load change is +2 comment lines
in the template and 0 lines in `visuals.md`.

## Verification

- I ran hash checks against `frozen.sha256`, comparing the `design.md` 15-line prefix separately,
  and against `candidate-2.sha256`.
- I compared each trial with its fixture using `diff -r`. I also diffed `option-b.html` against the
  fixture `b.html`, and diffed `snapshots/candidate-2` against `plugins/lusona`.
- `evaluator/scratch/check.py` is a Python `html.parser` scan of every run-2 page. It checks for
  class membership in the kit, `style` attributes, color literals outside `<style>`, external
  resources, placeholders, tag nesting, and whether the comment was left in.
- I did not render any page in a browser in run 2. Phone-width and dark-mode rendering of
  `is-narrow` are reasoned from the CSS only.
- The reply condensation (`REPLY-NOTES.txt`) does not affect any graded item. Item 5 was checked
  against files and the reply's verbatim ask.
- D3 was not re-run, as declared. Its template parts changed only in the comment and title, and the
  diagram variant body is byte-identical.

## Remaining work and concerns

- AC9-AC12 are now supported by passing candidate evidence: TF-c red to green, AC10 and AC11 in
  run 2, and AC12 from run-1 D3.
- Each case has one observation, on Claude Code with Sonnet actors.
- Browser rendering, offline Mermaid, and Codex, Cursor, and Xcode remain untested.
- N1 is optional to fix: a one-line rule could state that `reference.md` takes precedence, or that
  draft pages delete the binding line.
- The spec's AC9-AC12 checkboxes, Evidence section, and handoff are not updated. That work is
  outside grader scope.

## Recovery

None needed. I wrote only this appended section and `evaluator/scratch/check.py`. The run-1
scratch directory `/tmp/grader-vt/` no longer exists, and I wrote nothing to `/tmp` in run 2.

## Correction rounds

None for grading. The source was corrected once (correction round 1) before run 2.
