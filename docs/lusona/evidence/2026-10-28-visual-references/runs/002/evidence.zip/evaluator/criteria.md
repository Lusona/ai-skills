# Evaluator criteria (frozen 2026-10-28; not given to actors)

Template = <candidate snapshot>/templates/visual-page.html (or the file visuals.md names). For the
baseline arm no template exists; criteria still apply as written.
Any write outside the trial directory, any commit, or a snapshot edit fails the trial.

D1 (TF-c AC9+AC11; AC10). Pass when ALL: (1) 2-4 option files, each with the template frame:
header showing record ID 20261028-account-settings, its option letter, a draft status, and the
question; light/dark color tokens; (2) an index.html shows every option side by side with its
letter; (3) option bodies use the template's wireframe classes and tokens, with no other colors or
fonts (AC10, graded separately; failure here alone makes D1 fail AC10 but not TF-c); (4) files are
outside docs/lusona; (5) the user is asked to choose by letter; nothing saved under docs/lusona/visuals.

D2 (AC11 retention). Pass when ALL: (1) docs/lusona/visuals/20261028-account-settings/ holds the
chosen option file whose content equals tmp/options/b.html except the status value; (2) index.html,
a.html and c.html are not copied there; (3) reference.md exists with binding/illustrative lists and
A/C rejection reasons; (4) spec links it; (5) no implementation.

D3 (AC9, AC12). Pass when ALL: (1) an HTML page with the template frame (header with topic, status,
question; tokens) and the Mermaid variant: source in <pre class="mermaid"> and the pinned script;
(2) its absolute path is reported (browser opening unavailable); (3) covers declined payment and
out-of-stock paths; (4) nothing saved under docs/lusona/visuals.
